# Data and software rights

This repository distributes research code and derived numerical records. It does
not redistribute third-party vulnerability reports, contract source code, model
checkpoints, or raw generated responses. Acquire these from the original providers
and follow their licenses, access rules, and responsible-disclosure requirements.

The OSP-style comparator is a text-domain adaptation, not a reproduction of the
original image model. The StruQ comparator requires the official external checkpoint
and implements its published structured-query interface; consult the upstream
repository and checkpoint license before use. Python dependencies retain their
respective licenses. No license for third-party material is granted here.

The authors have not yet selected a license for the research code. Publication
of the repository should not be interpreted as an unrestricted license grant.
