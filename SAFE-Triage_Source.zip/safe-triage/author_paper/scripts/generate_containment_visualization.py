#!/usr/bin/env python3
"""Generate the raster result visualization used as Figure 3."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "tables" / "risk_control_head_to_head.csv"
OUTPUT = ROOT / "figures" / "containment_results.png"

ORDER = [
    "Supervised, no abstention",
    "MaxProb selective prediction",
    "OSP-style linear adaptation",
    "StruQ Mistral-7B",
    "Agreement risk control",
    "SAFE-Triage",
]

DISPLAY = {
    "Supervised, no abstention": "Supervised",
    "MaxProb selective prediction": "MaxProb",
    "OSP-style linear adaptation": "OSP-style",
    "StruQ Mistral-7B": "StruQ 7B",
    "Agreement risk control": "Agreement",
    "SAFE-Triage": "SAFE-Triage",
}


def load_rows() -> list[dict[str, str]]:
    with SOURCE.open(newline="", encoding="utf-8") as handle:
        indexed = {row["policy"]: row for row in csv.DictReader(handle)}
    missing = [name for name in ORDER if name not in indexed]
    if missing:
        raise ValueError(f"Missing policies in {SOURCE}: {missing}")
    return [indexed[name] for name in ORDER]


def main() -> None:
    rows = load_rows()
    labels = [DISPLAY[row["policy"]] for row in rows]
    correct = np.array([int(row["clean_correct"]) for row in rows])
    wrong = np.array([int(row["clean_wrong"]) for row in rows])
    review = 85 - correct - wrong
    exposures = np.array(
        [
            int(row["provenance_exposures"]) + int(row["direct_marker_actions"])
            for row in rows
        ]
    )

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10.8,
            "axes.titlesize": 11.4,
            "axes.labelsize": 10.2,
            "xtick.labelsize": 9.2,
            "ytick.labelsize": 9.8,
        }
    )

    fig, (ax_clean, ax_attack) = plt.subplots(
        1,
        2,
        figsize=(7.35, 3.55),
        gridspec_kw={"width_ratios": [1.06, 1.0], "wspace": 0.30},
    )
    fig.patch.set_facecolor("white")
    y = np.arange(len(rows))

    # A light row band creates one visual reading path across both panels.
    for axis in (ax_clean, ax_attack):
        axis.axhspan(4.52, 5.48, color="#E8F5F1", zorder=0)
        axis.set_axisbelow(True)
        axis.grid(axis="x", color="#D8DEE8", linewidth=0.55, alpha=0.75)
        axis.spines[["top", "right", "left"]].set_visible(False)
        axis.spines["bottom"].set_color("#667085")
        axis.tick_params(axis="y", length=0)
        axis.tick_params(axis="x", colors="#475467", length=3)

    # Panel A: every clean report is accounted for as correct, wrong, or reviewed.
    ax_clean.barh(
        y,
        correct,
        height=0.62,
        color="#2A9D8F",
        label="Correct auto-route",
        zorder=2,
    )
    ax_clean.barh(
        y,
        wrong,
        left=correct,
        height=0.62,
        color="#D55E00",
        hatch="////",
        label="Wrong auto-route",
        zorder=2,
    )
    ax_clean.barh(
        y,
        review,
        left=correct + wrong,
        height=0.62,
        color="#D9DEE7",
        label="Human review",
        zorder=2,
    )
    for i, (c, w, h) in enumerate(zip(correct, wrong, review)):
        if c >= 8:
            ax_clean.text(c / 2, i, f"{c}", ha="center", va="center", color="white", fontweight="bold")
        if w >= 8:
            ax_clean.text(c + w / 2, i, f"{w}", ha="center", va="center", color="white", fontweight="bold")
        if h >= 8:
            ax_clean.text(c + w + h / 2, i, f"{h}", ha="center", va="center", color="#344054")
    ax_clean.set_xlim(0, 85)
    ax_clean.set_xticks([0, 20, 40, 60, 80])
    ax_clean.set_yticks(y, labels)
    ax_clean.invert_yaxis()
    ax_clean.set_xlabel("Clean reports (count; total = 85)")
    ax_clean.set_title("(a) Utility retained on clean reports", loc="left", fontweight="bold")
    ax_clean.legend(
        loc="upper left",
        bbox_to_anchor=(-0.02, -0.24),
        ncol=3,
        frameon=False,
        fontsize=8.6,
        handlelength=1.5,
        columnspacing=0.9,
    )

    # Panel B: exposures are comparable because every method sees the same 247 attacks.
    attack_colors = ["#98A2B3"] * 5 + ["#007A5E"]
    bars = ax_attack.barh(y, exposures, height=0.62, color=attack_colors, zorder=2)
    for i, (bar, value) in enumerate(zip(bars, exposures)):
        if value > 0:
            ax_attack.text(
                value + 4,
                bar.get_y() + bar.get_height() / 2,
                f"{value}",
                va="center",
                ha="left",
                color="#344054",
                fontweight="bold" if i == 4 else "normal",
            )
        else:
            ax_attack.plot([0], [i], marker="|", markersize=13, markeredgewidth=2,
                           color="#007A5E", clip_on=False, zorder=4)
            ax_attack.text(9, i, "0", va="center", ha="left", color="#007A5E", fontweight="bold")

    ax_attack.set_xlim(0, 260)
    ax_attack.set_xticks([0, 50, 100, 150, 200, 250])
    ax_attack.set_yticks(y, labels)
    ax_attack.invert_yaxis()
    ax_attack.set_xlabel("Automatic actions on 247 targeted attacks")
    ax_attack.set_title("(b) Known-condition exposure", loc="left", fontweight="bold")

    # The paired annotation states the main incremental contribution without
    # implying protection against unrestricted adaptive attacks.
    ax_attack.text(
        250,
        5.02,
        "Compared with agreement:\n75 fewer targeted exposures\n5 fewer correct clean auto-routes",
        ha="right",
        va="center",
        fontsize=8.0,
        fontweight="bold",
        color="#006B55",
    )

    fig.subplots_adjust(left=0.13, right=0.985, top=0.88, bottom=0.29)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUTPUT, dpi=360, facecolor="white", bbox_inches="tight", pad_inches=0.035)
    plt.close(fig)

    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    main()
