#!/usr/bin/env python3
"""Rebuild manuscript CSV inputs from saved observations and checked outputs.

Run from any directory with Python 3.11+; no external dependencies required.
The surrounding study supplies the original saved decision records.
"""
import csv
import json
import sys
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
STUDY = PAPER.parent
sys.path.insert(0, str(STUDY / "scripts"))
from submission_analysis import compare, read, summarise, paired_counts


def write(name, rows):
    target = PAPER / "tables" / name
    target.parent.mkdir(exist_ok=True)
    with target.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    data = STUDY / "artifacts/submission"
    ledger = read(data / "decisions.jsonl")
    verified = summarise(ledger)
    saved = json.loads((data / "uncertainty.json").read_text())
    assert json.loads(json.dumps(verified)) == saved, "The saved analysis does not match the observations."
    groups = ["Code4rena/calibration", "Code4rena/test", "Sherlock/external"]
    for kind in ("competition", "linked_code"):
        rows = []
        for y, group in zip((3, 2, 1), groups):
            estimate = verified[group]["point"][2] * 100
            lo, hi = [v*100 for v in verified[group][kind+"_bootstrap"]["difference_interval"]]
            rows.append({"partition": group, "y": y + (.12 if kind == "competition" else -.12), "difference": estimate,
                         "lower": lo, "upper": hi, "minus": estimate-lo, "plus": hi-estimate})
        write(kind + "_intervals.csv", rows)
    rows = []
    for group in groups:
        records = [r for r in ledger if r["partition"] == group]
        hybrid, supervised, difference = compare(records)
        k = sum(r["hybrid"] is not None for r in records)
        rows.append({"partition": group, "n": len(records), "automated": k,
                     "hybrid_errors": round(hybrid*k), "supervised_errors": round(supervised*k),
                     "hybrid_risk": hybrid, "supervised_risk": supervised, "coverage": k/len(records)})
    write("routing_results.csv", rows)

    interface_rows = []
    for y, group in zip((3, 2, 1), groups):
        records = [r for r in ledger if r["partition"] == group]
        parsed = sum(r["retrieval"] is not None for r in records)
        interface_rows.append({
            "partition": group,
            "y": y,
            "parser_validity": 100 * parsed / len(records),
            "routing_error": 100 * verified[group]["systems"]["retrieval"]["risk"],
        })
    write("interface_decision_gap.csv", interface_rows)

    ablation_rows = []
    for group in groups:
        for label, key in (("Full gate", "hybrid"),
                           ("Without agreement", "without_agreement"),
                           ("Without quote", "without_quote"),
                           ("Without support", "without_support")):
            result = verified[group]["systems"][key]
            ablation_rows.append({
                "partition": group,
                "condition": label,
                "automated": result["automated"],
                "coverage": result["automated"] / verified[group]["n"],
                "risk": result["risk"],
            })
    write("gate_ablation.csv", ablation_rows)

    # Compact, auditable view of every completed model--prompt configuration
    # in the 52-case pilot.  The larger Qwen model was run in retrieval mode
    # only.  Error is conditioned on parser-valid outputs; quote rate uses all
    # 52 cases because quote matching is an observable serving property.
    diagnostic_counts = json.loads((data / "diagnostic_counts.json").read_text())
    pilot_rows = []
    for model in ("llama3.1:8b", "phi4-mini:3.8b", "qwen3:8b", "qwen3:32b"):
        modes = ("plain", "structured", "retrieval") if model != "qwen3:32b" else ("retrieval",)
        source = "capacity_pilot" if model == "qwen3:32b" else "pilot_runs"
        for mode in modes:
            counts = []
            for split in ("calibration", "test"):
                key = f"{source}/{model}/{mode}/Code4rena/{split}/original"
                counts.append(diagnostic_counts[key])
            n = sum(row["n"] for row in counts)
            parsed = sum(row["parsed"] for row in counts)
            errors = sum(row["errors"] for row in counts)
            quotes = sum(row["quote_pass"] for row in counts)
            pilot_rows.append({
                "model": model,
                "mode": mode,
                "n": n,
                "parsed": parsed,
                "parse_rate": parsed / n,
                "errors": errors,
                "routing_error": errors / parsed if parsed else "",
                "quote_pass": quotes,
                "quote_rate": quotes / n,
            })
    capacity70 = json.loads((data / "capacity70_prompt_counts.json").read_text())
    assert capacity70["n"] == 52
    pilot_rows.append({key: capacity70[key] for key in pilot_rows[0]})
    write("pilot_model_modes.csv", pilot_rows)

    paired = paired_counts(read(data / "diagnostics.jsonl"))
    assert paired == json.loads((data / "paired_counts.json").read_text())
    write("paired_effects.csv", [{"condition": k, **v} for k,v in sorted(paired.items())])

    # M1 tables are generated from the pre-specified analysis, never transcribed
    # by hand. Refuse to build the paper table until all five locked LLM runs
    # are complete.
    m1 = json.loads((STUDY / "artifacts/m1/analysis/summary.json").read_text())
    expected_models = [
        "phi4-mini:3.8b", "llama3.1:8b", "qwen3:8b", "qwen3:32b",
        "llama3.3:70b",
    ]
    expected_groups = [
        "code4rena_calibration", "code4rena_test",
        "sherlock_external", "codehawks_original_six",
    ]
    assert sorted(m1["llm"]) == sorted(expected_models), "Locked full-scale LLM runs are incomplete."
    llm_rows = []
    for model_index, model in enumerate(expected_models):
        assert set(expected_groups).issubset(m1["llm"][model])
        for partition_index, group in enumerate(expected_groups):
            row = m1["llm"][model][group]
            hybrid = m1["hybrid"][model][group]
            matched = hybrid["matched_supervised"]["tfidf_logistic"]
            llm_rows.append({
                "model": model, "model_index": model_index,
                "partition": group, "partition_index": partition_index,
                "n": row["n"],
                "parsed": row["parser_valid"], "errors": row["errors"],
                "parse_rate": row["parser_valid"] / row["n"],
                "routing_error": row["error_rate"], "under": row["under_prioritised"],
                "over": row["over_prioritised"], "quotes": row["quote_match"],
                "latency_median_s": row["latency_median_s"],
                "hybrid_actions": hybrid["decisions"], "hybrid_errors": hybrid["errors"],
                "matched_logistic_errors": matched["errors"],
                "conditional_coverage": hybrid["conditional_coverage"],
                "end_to_end_coverage": hybrid["end_to_end_coverage"],
            })
    write("m1_llm_results.csv", llm_rows)

    pooled_rows = []
    for model in expected_models:
        rows = [row for row in llm_rows if row["model"] == model]
        decisions = sum(row["parsed"] for row in rows)
        n = sum(row["n"] for row in rows)
        errors = sum(row["errors"] for row in rows)
        under = sum(row["under"] for row in rows)
        over = sum(row["over"] for row in rows)
        pooled_rows.append({
            "model": model, "n": n, "parsed": decisions,
            "parse_rate": decisions / n, "errors": errors,
            "routing_error": errors / decisions, "under": under, "over": over,
            "cost_1": (under + over) / decisions,
            "cost_10": (10 * under + over) / decisions,
        })
    write("m1_llm_pooled.csv", pooled_rows)

    supervised_rows = []
    for model, groups_by_name in sorted(m1["strong_supervised"].items()):
        for group, row in sorted(groups_by_name.items()):
            supervised_rows.append({
                "model": model, "partition": group, "n": row["decisions"],
                "errors": row["errors"], "routing_error": row["error_rate"],
                "priority_precision": row["priority_precision"],
                "priority_recall": row["priority_recall"],
                "under": row["under_prioritised"], "over": row["over_prioritised"],
                "cost_1": row["cost_per_decision"]["under_1_over_1"],
                "cost_10": row["cost_per_decision"]["under_10_over_1"],
            })
    write("m1_supervised_results.csv", supervised_rows)

    bias_rows = []
    for cohort, row in sorted(m1["codehawks_resolved_selection"].items()):
        comparison = row["comparisons"]["priority_prevalence_fisher"]
        bias_rows.append({
            "cohort": cohort, "resolved_n": row["resolved"]["n"],
            "unresolved_n": row["unresolved"]["n"],
            "resolved_priority": row["resolved"]["priority_prevalence"],
            "unresolved_priority": row["unresolved"]["priority_prevalence"],
            "odds_ratio": comparison["odds_ratio_resolved_vs_unresolved"],
            "p_value": comparison["p_value"],
        })
    write("m1_selection_bias.csv", bias_rows)

    assurance = json.loads((STUDY / "artifacts/assurance_method_evaluation/summary.json").read_text())
    common_transfer = ["Code4rena/test", "Sherlock/external", "CodeHawks/CH-6"]
    policy_rows = []
    collections = {
        "Supervised risk control": [assurance["supervised_reference"]],
        "LLM self-confidence": [
            row["llm_confidence_control"] for row in assurance["models"].values()
        ],
        "Agreement risk control": [
            row["agreement_risk_control"] for row in assurance["models"].values()
        ],
        "SAFE-Triage": [row["safe_triage"] for row in assurance["models"].values()],
    }
    for label, policies in collections.items():
        feasible = [row for row in policies if row["calibration"]["status"] == "validated"]
        transfers = [
            row["evaluation"][partition]
            for row in feasible for partition in common_transfer
        ]
        active = [row for row in transfers if row["actions"]]
        policy_rows.append({
            "policy": label,
            "calibration_feasible": len(feasible),
            "calibration_total": len(policies),
            "active_transfers": len(active),
            "transfer_total": len(transfers),
            "point_target_met": sum(row["risk"] is not None and row["risk"] <= 0.15 for row in active),
            "upper_target_met": sum(row["report_cp_upper"] is not None and row["report_cp_upper"] <= 0.15 for row in active),
        })
    write("risk_control_summary.csv", policy_rows)

    challenge = assurance["qwen3_8b_challenges"]
    challenge_rows = []
    for condition in ("clean", "cross_project_mismatch", "within_repo_mismatch", "prompt_injection_direct", "prompt_injection_indirect", "prompt_injection_delimited"):
        row = challenge[condition]
        challenge_rows.append({
            "condition": condition,
            "n": row["n"],
            "agreement_actions": row["agreement_risk_control"]["actions"],
            "agreement_wrong": row["agreement_risk_control"]["wrong_actions"],
            "safe_actions": row["safe_triage"]["actions"],
            "safe_wrong": row["safe_triage"]["wrong_actions"],
        })
    write("risk_control_challenges.csv", challenge_rows)

    clean = challenge["clean"]
    cross = challenge["cross_project_mismatch"]
    within = challenge["within_repo_mismatch"]
    direct = challenge["prompt_injection_direct"]
    indirect = challenge["prompt_injection_indirect"]
    delimited = challenge["prompt_injection_delimited"]
    qwen = assurance["models"]["qwen3:8b"]
    osp = json.loads((STUDY / "artifacts/published_baselines/osp_linear/summary.json").read_text())
    head_to_head_rows = []
    comparison_methods = (
        ("Supervised, no abstention", "supervised_no_abstention", None),
        ("MaxProb selective prediction", "maxprob_selective_prediction", assurance["supervised_reference"]),
        ("Agreement risk control", "agreement_risk_control", qwen["agreement_risk_control"]),
        ("SAFE-Triage", "safe_triage", qwen["safe_triage"]),
    )
    for label, key, policy in comparison_methods:
        clean_actions = clean[key]["actions"]
        clean_wrong = clean[key]["wrong_actions"]
        calibration = policy["calibration"] if policy else None
        selected = calibration["selected"] if calibration else None
        head_to_head_rows.append({
            "policy": label,
            "validation_15pct": calibration["status"] if calibration else "not_applicable",
            "threshold": selected["threshold"] if selected else "",
            "clean_correct": clean_actions - clean_wrong,
            "clean_wrong": clean_wrong,
            "provenance_exposures": cross[key]["actions"] + within[key]["actions"],
            "direct_marker_actions": direct[key]["actions"],
            "adaptive_new_errors": (
                indirect[key]["new_wrong_vs_clean"]
                + delimited[key]["new_wrong_vs_clean"]
            ),
        })
    osp_challenge = osp["challenges"]
    osp_clean = osp_challenge["clean"]
    head_to_head_rows.insert(2, {
        "policy": "OSP-style linear adaptation",
        "validation_15pct": osp["status"],
        "threshold": osp["selected"]["threshold"] if osp["selected"] else "",
        "clean_correct": osp_clean["actions"] - osp_clean["wrong_actions"],
        "clean_wrong": osp_clean["wrong_actions"],
        "provenance_exposures": (
            osp_challenge["cross_project_mismatch"]["actions"]
            + osp_challenge["within_repo_mismatch"]["actions"]
        ),
        "direct_marker_actions": osp_challenge["prompt_injection_direct"]["actions"],
        "adaptive_new_errors": (
            osp_challenge["prompt_injection_indirect"]["new_wrong_vs_clean"]
            + osp_challenge["prompt_injection_delimited"]["new_wrong_vs_clean"]
        ),
    })
    struq_path = STUDY / "artifacts/published_baselines/struq_mistral7b/summary.json"
    if struq_path.exists():
        struq = json.loads(struq_path.read_text())
        if struq.get("status") == "complete":
            struq_challenge = struq["challenges"]
            struq_clean = struq_challenge["clean"]
            head_to_head_rows.insert(3, {
                "policy": "StruQ Mistral-7B",
                "validation_15pct": "not_applicable",
                "threshold": "",
                "clean_correct": struq_clean["actions"] - struq_clean["wrong_actions"],
                "clean_wrong": struq_clean["wrong_actions"],
                "provenance_exposures": (
                    struq_challenge["cross_project_mismatch"]["actions"]
                    + struq_challenge["within_repo_mismatch"]["actions"]
                ),
                "direct_marker_actions": struq_challenge["prompt_injection_direct"]["actions"],
                "adaptive_new_errors": (
                    struq_challenge["prompt_injection_indirect"]["new_wrong_vs_clean"]
                    + struq_challenge["prompt_injection_delimited"]["new_wrong_vs_clean"]
                ),
            })
    write("risk_control_head_to_head.csv", head_to_head_rows)
    print("Verified and generated fourteen manuscript CSV files.")


if __name__ == "__main__":
    main()
