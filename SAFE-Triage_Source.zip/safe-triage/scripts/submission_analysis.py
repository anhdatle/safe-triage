#!/usr/bin/env python3
"""Dependency-free analysis of pseudonymous decision records.

Percentile cluster resampling is exploratory, conditional on observed data and
fixed models. It does not correct development selection or establish safety.
"""
import argparse
import json
import random
from collections import defaultdict
from pathlib import Path


def read(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s]


def risk(rows, field):
    chosen = [r for r in rows if r[field] is not None]
    return sum(r[field] != r["gold"] for r in chosen) / len(chosen) if chosen else None


def compare(rows):
    k = sum(r["hybrid"] is not None for r in rows)
    if not k:
        return None
    ranked = sorted(rows, key=lambda r: (-r["score"], r["id"]))[:k]
    sup = sum(r["supervised"] != r["gold"] for r in ranked) / k
    return risk(rows, "hybrid"), sup, risk(rows, "hybrid") - sup


def interval(values):
    values = sorted(values)
    if not values:
        return None
    return [values[int((len(values)-1)*p)] for p in (0.025, 0.975)]


def clustered(rows, field, draws=5000):
    by = defaultdict(list)
    for r in rows:
        by[r[field]].append(r)
    units = sorted(by)
    rng = random.Random(20260905)
    samples = [[], [], []]
    for _ in range(draws):
        sample = [r for unit in rng.choices(units, k=len(units)) for r in by[unit]]
        result = compare(sample)
        if result is not None:
            for arr, value in zip(samples, result):
                arr.append(value)
    return {"units": len(units), "draws": draws, "defined_draws": len(samples[0]),
            "hybrid_risk_interval": interval(samples[0]),
            "matched_supervised_risk_interval": interval(samples[1]),
            "difference_interval": interval(samples[2])}


def summarise(rows):
    result = {}
    for group in sorted({r["partition"] for r in rows}):
        selected = [r for r in rows if r["partition"] == group]
        result[group] = {
            "n": len(selected), "point": compare(selected),
            "competition_bootstrap": clustered(selected, "project"),
            "linked_code_bootstrap": clustered(selected, "cluster"),
            "without_training_linked_code": compare([r for r in selected if not r["training_link"]]),
            "training_linked_reports": sum(r["training_link"] for r in selected),
            "legacy_label_reports": sum(r["legacy_label"] for r in selected),
            "retrieval_risk_without_legacy": risk([r for r in selected if not r["legacy_label"]], "retrieval"),
            "matched_without_legacy": compare([r for r in selected if not r["legacy_label"]]),
            "snippet_lines_median": sorted(r["snippet_lines"] for r in selected)[len(selected)//2],
            "systems": {field: {"automated": sum(r[field] is not None for r in selected),
                                "risk": risk(selected, field)}
                        for field in ("hybrid", "retrieval", "supervised", "without_quote", "without_support", "without_agreement", "without_integrity")},
        }
    return result


def diagnostic_counts(rows):
    groups = defaultdict(list)
    for r in rows:
        groups["/".join([r["experiment"], r["model"], r["mode"], r["partition"], r.get("condition", "original")])].append(r)
    return {key: {"n": len(rs), "parsed": sum(r["parsed"] for r in rs),
                  "errors": sum(r["parsed"] and r["route"] != r["gold"] for r in rs),
                  "quote_pass": sum(r["quote_pass"] for r in rs),
                  "support": sum(r["support"] for r in rs),
                  "hybrid_automated": sum(r.get("hybrid") is not None for r in rs)}
            for key, rs in sorted(groups.items())}


def paired_counts(rows):
    by_base = defaultdict(dict)
    for r in rows:
        if r["experiment"] == "challenge_runs_v2":
            by_base[r["base"]][r["condition"]] = r
    counts = defaultdict(lambda: defaultdict(int))
    for conditions in by_base.values():
        clean = conditions["clean"]
        for condition, r in conditions.items():
            out = counts[condition]
            opened, old_open = r["hybrid"] is not None, clean["hybrid"] is not None
            wrong = opened and r["hybrid"] != r["gold"]
            old_wrong = old_open and clean["hybrid"] != clean["gold"]
            out["n"] += 1
            out["automated"] += opened
            out["wrong"] += wrong
            out["new_wrong"] += wrong and not old_wrong
            out["newly_automated"] += opened and not old_open
            out["lost_automation"] += old_open and not opened
    return counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ledger", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--diagnostics", type=Path)
    args = parser.parse_args()
    result = summarise(read(args.ledger))
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    if args.diagnostics:
        args.output.with_name("diagnostic_counts.json").write_text(json.dumps(diagnostic_counts(read(args.diagnostics)), indent=2, sort_keys=True) + "\n")
        args.output.with_name("paired_counts.json").write_text(json.dumps(paired_counts(read(args.diagnostics)), indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
