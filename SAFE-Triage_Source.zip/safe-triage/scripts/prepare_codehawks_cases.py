#!/usr/bin/env python3
"""Resolve pinned evidence and build private CodeHawks evaluation cases."""

from __future__ import annotations

import argparse
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("prepare_cases", HERE / "prepare_cases.py")
CASES = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(CASES)


def read_records(root: Path) -> list[dict]:
    return [json.loads(path.read_text(encoding="utf-8")) for path in sorted(root.glob("*/*.json"))]


def resolve_first_pinned(row: dict, cache: Path, pause: float) -> tuple[dict | None, str, str]:
    last_status = "missing_pinned_blob"
    for url in row.get("report_links", []):
        descriptor = CASES.evidence_descriptor(url)
        if descriptor is None:
            continue
        source, status = CASES.fetch(descriptor["raw_url"], cache, pause)
        last_status = status
        if source:
            return descriptor, source, status
    return None, "", last_status


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reports-root", type=Path, required=True)
    parser.add_argument("--source-cache", type=Path, required=True)
    parser.add_argument("--private-output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--pause", type=float, default=0.05)
    args = parser.parse_args()

    output = []
    for row in read_records(args.reports_root):
        descriptor, source, status = resolve_first_pinned(row, args.source_cache, args.pause)
        evidence = ""
        if descriptor and source:
            evidence = CASES.snippet(source, descriptor["line_start"], descriptor["line_end"])
        report_text = f"Title: {row['title']}\n\nReport:\n{row['report_text']}".strip()
        output.append(
            {
                "case_id": f"codehawks::{row['contest_id']}::{row['submission_id']}",
                "platform": "CodeHawks",
                "project_id": row["contest_id"],
                "split": "external_feasibility_v1",
                "gold_route": row["gold_route"],
                "gold_reason": f"codehawks_{row['final_validity']}_{row['submitted_severity']}",
                "report_text": report_text[:6000],
                "report_sha256": row["report_sha256"],
                "report_chars_full": len(report_text),
                "report_chars_model_input": min(len(report_text), 6000),
                "evidence_available": int(bool(evidence)),
                "evidence_status": status,
                "evidence_url": descriptor["evidence_url"] if descriptor else "",
                "repository_slug": descriptor["repository_slug"] if descriptor else "",
                "commit": descriptor["commit"] if descriptor else "",
                "source_path": descriptor["source_path"] if descriptor else "",
                "line_start": descriptor["line_start"] if descriptor else None,
                "line_end": descriptor["line_end"] if descriptor else None,
                "evidence_snippet": evidence,
                "submission_url": row["submission_url"],
                "contest_repository_url": row["repository_url"],
            }
        )

    args.private_output.parent.mkdir(parents=True, exist_ok=True)
    with args.private_output.open("w", encoding="utf-8") as handle:
        for row in output:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

    grouped = defaultdict(list)
    for row in output:
        grouped[row["project_id"]].append(row)
    summary = {
        "cases": len(output),
        "projects": len(grouped),
        "evidence_resolved": sum(row["evidence_available"] for row in output),
        "gold_routes": dict(sorted(Counter(row["gold_route"] for row in output).items())),
        "by_contest": {
            contest: {
                "cases": len(rows),
                "evidence_resolved": sum(row["evidence_available"] for row in rows),
                "gold_routes": dict(sorted(Counter(row["gold_route"] for row in rows).items())),
            }
            for contest, rows in sorted(grouped.items())
        },
        "private_case_file": str(args.private_output),
        "release_warning": "Case text is private-to-project pending redistribution-rights review.",
        "confirmatory": False,
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
