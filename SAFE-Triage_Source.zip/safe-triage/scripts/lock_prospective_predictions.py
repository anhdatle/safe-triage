#!/usr/bin/env python3
"""Hash completed prospective predictions before outcome unblinding."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol-lock", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    protocol = json.loads(args.protocol_lock.read_text(encoding="utf-8"))
    if protocol.get("status") != "awaiting_predictions":
        raise ValueError("Protocol lock is not awaiting predictions")
    files = [{"path": str(path), "sha256": sha256(path), "bytes": path.stat().st_size} for path in args.predictions]
    result = {
        **protocol,
        "status": "predictions_locked_before_unblinding",
        "predictions_locked_at_utc": datetime.now(timezone.utc).isoformat(),
        "prediction_files": files,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

