#!/usr/bin/env python3
"""Hash the M1/future-prospective protocol and executable analysis surface."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


FILES = [
    "M1_EXECUTION_PROTOCOL.md",
    "M1_PROTOCOL_ADDENDUM_TRANSFORMER.md",
    "M1_PROTOCOL_ADDENDUM_LABEL_ELIGIBILITY.md",
    "scripts/run_llm.py",
    "scripts/prepare_prospective_blind.py",
    "scripts/lock_prospective_predictions.py",
    "scripts/run_strong_supervised.py",
    "scripts/run_transformer_supervised.py",
    "scripts/analyse_m1.py",
]


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    records = [{"path": item, "bytes": (root / item).stat().st_size, "sha256": digest(root / item)} for item in FILES]
    output = {
        "lock_version": "safe-triage-m1-future-v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": records,
        "scope": "Executable local lock for future contests; an external timestamp remains required for a public preregistration claim.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
