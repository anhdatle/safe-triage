#!/usr/bin/env python3
"""Acquire a frozen, author-free index of public CodeHawks submissions.

The public HTML cache belongs under external_data/ and is not releaseable by
default. Derived records omit author names. Tags and judgements are retained for
auditing but must never be included in model input.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import re
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from bs4 import BeautifulSoup


BASE = "https://codehawks.cyfrin.io"
PAGE_SIZE = 30
CONTESTS = {
    "2023-12-the-standard": 1501,
    "2023-10-SteadeFi": 435,
    "2024-05-Sablier": 426,
    "2024-07-zaros": 916,
    "2024-08-tadle": 1790,
    "2024-12-quantamm": 1027,
}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def fetch(url: str, cache_path: Path, pause: float, retries: int = 4) -> bytes:
    if cache_path.exists():
        return cache_path.read_bytes()
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    request = Request(
        url,
        headers={
            "User-Agent": "Safe-Triage academic dataset audit/0.1 (public pages; rate limited)",
            "Accept": "text/html,application/xhtml+xml",
        },
    )
    for attempt in range(retries):
        try:
            with urlopen(request, timeout=45) as response:
                body = response.read()
            cache_path.write_bytes(body)
            time.sleep(pause + random.uniform(0, pause / 5))
            return body
        except HTTPError as exc:
            if exc.code not in {429, 500, 502, 503, 504} or attempt + 1 == retries:
                raise
        except URLError:
            if attempt + 1 == retries:
                raise
        time.sleep(2**attempt)
    raise RuntimeError(f"Unable to fetch {url}")


def normalize_validity(value: str) -> str:
    value = value.strip().lower()
    if value == "valid":
        return "valid"
    if value == "invalid":
        return "invalid"
    return "unresolved"


def gold_route(validity: str, severity: str) -> str | None:
    if validity == "unresolved":
        return None
    if validity == "valid" and severity.lower() in {"critical", "high", "medium"}:
        return "PRIORITY_REVIEW"
    return "STANDARD_REVIEW"


def parse_index_page(html: bytes, contest_id: str, page: int, fetched_at: str) -> tuple[list[dict], dict]:
    soup = BeautifulSoup(html, "html.parser")
    plain = " ".join(soup.stripped_strings)
    count_match = re.search(r"\b(\d+)\s*/\s*(\d+)\b", plain)
    displayed_total = int(count_match.group(2)) if count_match else None
    raw = html.decode("utf-8", errors="replace")
    repo_match = re.search(r'githubUrl:"(https://github\.com/[^"?]+)', raw)
    repo_url = repo_match.group(1) if repo_match else None
    page_hash = sha256_bytes(html)
    records = []
    seen = set()
    href_pattern = re.compile(rf"^/c/{re.escape(contest_id)}/s/(\d+)$")
    for row in soup.select("tbody tr"):
        link = row.find("a", href=href_pattern)
        if link is None:
            continue
        match = href_pattern.match(link.get("href", ""))
        assert match is not None
        submission_id = int(match.group(1))
        if submission_id in seen:
            continue
        seen.add(submission_id)
        cells = [" ".join(cell.stripped_strings) for cell in row.select("td")]
        if len(cells) < 3:
            continue
        title = re.sub(r"^#\d+\s*", "", cells[0]).strip()
        severity = cells[1].strip().lower()
        validity = normalize_validity(cells[2])
        tags = cells[3].strip() if len(cells) >= 4 else ""
        records.append(
            {
                "platform": "CodeHawks",
                "contest_id": contest_id,
                "submission_id": submission_id,
                "title": title,
                "submitted_severity": severity,
                "final_validity": validity,
                "gold_route": gold_route(validity, severity),
                "tags_audit_only": tags,
                "submission_url": f"{BASE}/c/{contest_id}/s/{submission_id}",
                "contest_url": f"{BASE}/c/{contest_id}",
                "repository_url": repo_url,
                "index_page": page,
                "index_page_sha256": page_hash,
                "fetched_at_utc": fetched_at,
                "author_removed": True,
            }
        )
    return records, {"displayed_total": displayed_total, "repository_url": repo_url}


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--pause", type=float, default=0.35)
    parser.add_argument("--contest-manifest", type=Path)
    args = parser.parse_args()

    contests = CONTESTS
    if args.contest_manifest:
        manifest = json.loads(args.contest_manifest.read_text(encoding="utf-8"))
        contests = {row["contest_id"]: int(row["expected_total"]) for row in manifest["contests"]}

    fetched_at = datetime.now(timezone.utc).isoformat()
    all_rows: list[dict] = []
    contest_audit: dict[str, dict] = {}
    for contest_id, expected_total in contests.items():
        contest_rows = []
        repository_urls = set()
        displayed_totals = set()
        for page in range(1, math.ceil(expected_total / PAGE_SIZE) + 1):
            url = f"{BASE}/c/{contest_id}/submissions?page={page}"
            cache_path = args.cache / contest_id / f"index-{page:03d}.html"
            html = fetch(url, cache_path, args.pause)
            rows, metadata = parse_index_page(html, contest_id, page, fetched_at)
            contest_rows.extend(rows)
            if metadata["repository_url"]:
                repository_urls.add(metadata["repository_url"])
            if metadata["displayed_total"] is not None:
                displayed_totals.add(metadata["displayed_total"])
        ids = [row["submission_id"] for row in contest_rows]
        validity = Counter(row["final_validity"] for row in contest_rows)
        routes = Counter(row["gold_route"] or "EXCLUDED_UNRESOLVED" for row in contest_rows)
        severity = Counter(row["submitted_severity"] for row in contest_rows)
        contest_audit[contest_id] = {
            "expected_total": expected_total,
            "parsed_records": len(contest_rows),
            "unique_submission_ids": len(set(ids)),
            "displayed_totals": sorted(displayed_totals),
            "repository_urls": sorted(repository_urls),
            "validity": dict(sorted(validity.items())),
            "gold_routes": dict(sorted(routes.items())),
            "submitted_severity": dict(sorted(severity.items())),
            "complete": len(contest_rows) == expected_total == len(set(ids)),
        }
        all_rows.extend(contest_rows)
        print(json.dumps({"contest": contest_id, **contest_audit[contest_id]}, sort_keys=True))

    duplicates = Counter((row["contest_id"], row["submission_id"]) for row in all_rows)
    duplicate_keys = [list(key) for key, count in duplicates.items() if count > 1]
    summary = {
        "snapshot_fetched_at_utc": fetched_at,
        "source": BASE,
        "scope": f"{len(contests)} completed public professional competitions",
        "records": len(all_rows),
        "contests": len(contests),
        "authors_removed": True,
        "model_input_excludes": ["final_validity", "gold_route", "tags_audit_only"],
        "duplicate_keys": duplicate_keys,
        "validity": dict(sorted(Counter(row["final_validity"] for row in all_rows).items())),
        "gold_routes": dict(sorted(Counter(row["gold_route"] or "EXCLUDED_UNRESOLVED" for row in all_rows).items())),
        "submitted_severity": dict(sorted(Counter(row["submitted_severity"] for row in all_rows).items())),
        "contest_audit": contest_audit,
        "complete": not duplicate_keys and all(item["complete"] for item in contest_audit.values()),
        "release_warning": "Do not redistribute cached HTML or report text without a rights review.",
    }
    write_jsonl(args.output, sorted(all_rows, key=lambda row: (row["contest_id"], row["submission_id"])))
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))
    if not summary["complete"]:
        raise SystemExit("Snapshot audit failed: record counts or uniqueness do not match")


if __name__ == "__main__":
    main()
