#!/usr/bin/env python3
"""Recompute descriptive controls and paired effects, without new inference.

All threshold and rank-matched comparisons are retrospective diagnostics.
No statistical certification or causal production inference is performed.
"""
import json
from collections import defaultdict
from pathlib import Path

from analyse_runs import exact_quote, integrity_pass, metrics, read_jsonl, record_id, supervised_map
from prepare_cases import evidence_descriptor

ROOT = Path(__file__).resolve().parents[1]


def gate(case, pred, sup, threshold=0.65, omit=None):
    checks = {
        "confidence": sup["confidence"] >= threshold,
        "agreement": pred.get("route") == sup["prediction"],
        "parse": bool(pred.get("parse_valid")),
        "support": pred.get("evidence_supported") is True,
        "quote": exact_quote(pred, case),
        "integrity": integrity_pass(case),
    }
    return all(value for name, value in checks.items() if name != omit)


def paired_effect(clean_open, modified_open, clean_route, modified_route, gold):
    """Separate policy non-rejection from an induced erroneous action."""
    return {
        "newly_automated": int(modified_open and not clean_open),
        "lost_automation": int(clean_open and not modified_open),
        "wrong_automated": int(modified_open and modified_route != gold),
        "new_wrong_automated": int(
            modified_open and modified_route != gold
            and not (clean_open and clean_route != gold)
        ),
        "changed_automated_route": int(
            clean_open and modified_open and clean_route != modified_route
        ),
    }


def main():
    cases = {r["case_id"]: r for r in read_jsonl(ROOT / "artifacts/cases.jsonl")}
    sup = supervised_map(read_jsonl(ROOT / "artifacts/supervised_predictions.jsonl"))
    runs = read_jsonl(ROOT / "artifacts/full_runs/qwen3_8b__retrieval.jsonl")
    groups = defaultdict(list)
    for pred in runs:
        case = cases[pred["case_id"]]
        groups[(case["platform"], case["split"])].append((case, pred, sup[(case["platform"], record_id(case["case_id"]))]))
    controls = {}
    for group, triples in sorted(groups.items()):
        k = sum(gate(*t) for t in triples)
        ranked = sorted(triples, key=lambda t: (-t[2]["confidence"], t[0]["case_id"]))
        top_ids = {t[0]["case_id"] for t in ranked[:k]}
        systems = {}
        for name in ["priority_only", "supervised_all", "supervised_t065", "supervised_rank_matched", "hybrid"] + [f"hybrid_without_{v}" for v in ["agreement", "support", "quote", "integrity"]]:
            rows = []
            for case, pred, s in triples:
                action = s["prediction"]
                if name == "priority_only":
                    action = "PRIORITY_REVIEW"
                elif name == "supervised_t065" and s["confidence"] < 0.65:
                    action = "ABSTAIN"
                elif name == "supervised_rank_matched" and case["case_id"] not in top_ids:
                    action = "ABSTAIN"
                elif name.startswith("hybrid"):
                    omit = name.removeprefix("hybrid_without_") if name != "hybrid" else None
                    action = pred["route"] if gate(case, pred, s, omit=omit) else "ABSTAIN"
                rows.append({"action": action, "project_id": case["project_id"], "gold_route": case["gold_route"]})
            systems[name] = {**metrics(rows), "automated_standard": sum(r["action"] == "STANDARD_REVIEW" for r in rows)}
        controls["/".join(group)] = systems

    cc = {r["case_id"]: r for r in read_jsonl(ROOT / "artifacts/challenges_v2.jsonl")}
    cs = {r["case_id"]: r for r in read_jsonl(ROOT / "artifacts/supervised_challenges_v2.jsonl")}
    pairs = defaultdict(dict)
    for p in read_jsonl(ROOT / "artifacts/challenge_runs_v2/qwen3_8b__retrieval.jsonl"):
        c = cc[p["case_id"]]
        pairs[c["base_case_id"]][c["condition"]] = (c, p, cs[c["case_id"]])
    effects = defaultdict(lambda: defaultdict(int))
    for conditions in pairs.values():
        clean = conditions["clean"]
        for condition, triple in conditions.items():
            c, p, s = triple
            e = effects[condition]
            e["n"] += 1
            opened = gate(*triple)
            e["automated"] += int(opened)
            e["policy_non_rejection"] += int(opened and condition != "clean")
            for key, value in paired_effect(gate(*clean), opened, clean[1].get("route"), p.get("route"), c["gold_route"]).items():
                e[key] += value

    repos = defaultdict(set)
    for row in read_jsonl(ROOT / "external_data/code4rena_processed.jsonl"):
        d = evidence_descriptor(row["model_input"])
        if d:
            repos[row["split"]].add(d["repository_slug"].lower())
    overlap = {f"{a}/{b}": sorted(repos[a] & repos[b]) for a in sorted(repos) for b in sorted(repos) if a < b}
    attrition = {}
    for group in groups:
        all_cases = [c for c in cases.values() if (c["platform"], c["split"]) == group]
        attrition["/".join(group)] = {"all_reports": len(all_cases), "resolved_evaluated": len(groups[group]), "hybrid_automated": controls["/".join(group)]["hybrid"]["automated"]}
    result = {"status": "retrospective_descriptive_only", "controls": controls, "paired_effects": effects, "first_cited_code_repository_overlap": overlap, "attrition": attrition}
    target = ROOT / "artifacts/negative_study_audit.json"
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
