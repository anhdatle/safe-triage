#!/usr/bin/env python3
"""Produce the pre-specified M1 limitation-remediation analyses."""

from __future__ import annotations

import argparse
import json
import random
import statistics
from collections import Counter, defaultdict
from pathlib import Path

import analyse_codehawks_external as codehawks
import analyse_runs as primary
from scipy.stats import fisher_exact, mannwhitneyu


COST_RATIOS = [1, 5, 10, 20]
SEED = 20260905


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def group_name(row: dict) -> str:
    if row["platform"] == "CodeHawks":
        return "codehawks_original_six" if row.get("split") == "external_feasibility_v1" else "codehawks_expanded_external"
    return f"{row['platform'].lower()}_{row['split']}"


def linked_cluster(row: dict) -> str:
    if row["platform"] != "CodeHawks":
        return row["project_id"]
    contest = row["project_id"].lower()
    for family in ["beanstalk", "sablier", "zaros", "stake-link", "stakelink"]:
        if family in contest:
            return "codehawks::stakelink" if family in {"stake-link", "stakelink"} else f"codehawks::{family}"
    return row["project_id"]


def decision_metrics(rows: list[dict], prediction_key: str) -> dict:
    usable = [row for row in rows if row.get(prediction_key) in {"PRIORITY_REVIEW", "STANDARD_REVIEW"}]
    tp = sum(row[prediction_key] == row["gold_route"] == "PRIORITY_REVIEW" for row in usable)
    tn = sum(row[prediction_key] == row["gold_route"] == "STANDARD_REVIEW" for row in usable)
    fp = sum(row[prediction_key] == "PRIORITY_REVIEW" and row["gold_route"] == "STANDARD_REVIEW" for row in usable)
    fn = sum(row[prediction_key] == "STANDARD_REVIEW" and row["gold_route"] == "PRIORITY_REVIEW" for row in usable)
    return {
        "n": len(rows),
        "decisions": len(usable),
        "errors": fp + fn,
        "error_rate": (fp + fn) / len(usable) if usable else None,
        "priority_true_positive": tp,
        "standard_true_negative": tn,
        "over_prioritised": fp,
        "under_prioritised": fn,
        "priority_precision": tp / (tp + fp) if tp + fp else None,
        "priority_recall": tp / (tp + fn) if tp + fn else None,
        "predicted_priority": tp + fp,
        "predicted_standard": tn + fn,
        "cost_per_decision": {
            f"under_{ratio}_over_1": (ratio * fn + fp) / len(usable) if usable else None for ratio in COST_RATIOS
        },
    }


def resolved_bias(cases: list[dict]) -> dict:
    result = {}
    for name, rows in {
        "resolved": [row for row in cases if row.get("evidence_available")],
        "unresolved": [row for row in cases if not row.get("evidence_available")],
    }.items():
        lengths = sorted(int(row.get("report_chars_full", 0)) for row in rows)
        validity = Counter(row.get("gold_reason", "").split("_")[1] for row in rows)
        severity = Counter(row.get("gold_reason", "").split("_")[-1] for row in rows)
        result[name] = {
            "n": len(rows),
            "priority": sum(row["gold_route"] == "PRIORITY_REVIEW" for row in rows),
            "priority_prevalence": sum(row["gold_route"] == "PRIORITY_REVIEW" for row in rows) / len(rows),
            "median_report_chars": lengths[len(lengths) // 2],
            "validity": dict(sorted(validity.items())),
            "severity": dict(sorted(severity.items())),
            "contests": dict(sorted(Counter(row["project_id"] for row in rows).items())),
            "linked_clusters": len({linked_cluster(row) for row in rows}),
        }
    resolved = [row for row in cases if row.get("evidence_available")]
    unresolved = [row for row in cases if not row.get("evidence_available")]
    priority_table = [
        [sum(row["gold_route"] == "PRIORITY_REVIEW" for row in resolved), sum(row["gold_route"] != "PRIORITY_REVIEW" for row in resolved)],
        [sum(row["gold_route"] == "PRIORITY_REVIEW" for row in unresolved), sum(row["gold_route"] != "PRIORITY_REVIEW" for row in unresolved)],
    ]
    valid = lambda row: "_valid_" in row.get("gold_reason", "")
    validity_table = [
        [sum(valid(row) for row in resolved), sum(not valid(row) for row in resolved)],
        [sum(valid(row) for row in unresolved), sum(not valid(row) for row in unresolved)],
    ]
    lengths_r = [int(row.get("report_chars_full", 0)) for row in resolved]
    lengths_u = [int(row.get("report_chars_full", 0)) for row in unresolved]
    length_test = mannwhitneyu(lengths_r, lengths_u, alternative="two-sided")
    result["comparisons"] = {
        "priority_prevalence_fisher": {
            "odds_ratio_resolved_vs_unresolved": float(fisher_exact(priority_table).statistic),
            "p_value": float(fisher_exact(priority_table).pvalue),
        },
        "validity_prevalence_fisher": {
            "odds_ratio_resolved_vs_unresolved": float(fisher_exact(validity_table).statistic),
            "p_value": float(fisher_exact(validity_table).pvalue),
        },
        "report_length_mann_whitney": {
            "u": float(length_test.statistic),
            "p_value": float(length_test.pvalue),
            "rank_biserial_resolved_minus_unresolved": float(2 * length_test.statistic / (len(lengths_r) * len(lengths_u)) - 1),
        },
        "multiplicity_note": "Descriptive diagnostics; p-values are not used as a model-selection gate.",
    }
    return result


def gate_open(case: dict, llm: dict, supervised: dict, threshold: float) -> bool:
    quote = codehawks.exact_quote(llm, case) if case["platform"] == "CodeHawks" else primary.exact_quote(llm, case)
    integrity = codehawks.integrity_pass(case) if case["platform"] == "CodeHawks" else primary.integrity_pass(case)
    return bool(
        llm.get("parse_valid")
        and llm.get("route") == supervised["prediction"]
        and supervised["confidence"] >= threshold
        and llm.get("evidence_supported") is True
        and quote
        and integrity
    )


def matched_rows(cases: list[dict], predictions: dict[str, dict], count: int) -> list[dict]:
    ranked = sorted(cases, key=lambda row: (-predictions[row["case_id"]]["confidence"], row["case_id"]))[:count]
    return [{"gold_route": row["gold_route"], "prediction": predictions[row["case_id"]]["prediction"]} for row in ranked]


def cluster_matched(cases: list[dict], hybrid_rows: list[dict], predictions: dict[str, dict]) -> tuple[list[dict], list[dict]]:
    by_cluster_cases: dict[str, list[dict]] = defaultdict(list)
    by_cluster_hybrid: dict[str, list[dict]] = defaultdict(list)
    for case in cases:
        by_cluster_cases[linked_cluster(case)].append(case)
    for row in hybrid_rows:
        by_cluster_hybrid[linked_cluster(row)].append(row)
    hybrid_actions, supervised_actions = [], []
    for cluster, cluster_cases in sorted(by_cluster_cases.items()):
        actions = [row for row in by_cluster_hybrid[cluster] if row["prediction"] != "ABSTAIN"]
        hybrid_actions.extend(actions)
        supervised_actions.extend(matched_rows(cluster_cases, predictions, len(actions)))
    return hybrid_actions, supervised_actions


def bootstrap_difference(cluster_records: list[dict], draws: int = 5000) -> dict:
    rng = random.Random(SEED)
    values = []
    for _ in range(draws):
        sample = [rng.choice(cluster_records) for _ in cluster_records]
        h_n = sum(row["hybrid_n"] for row in sample)
        s_n = sum(row["supervised_n"] for row in sample)
        if h_n and s_n:
            values.append(sum(row["hybrid_errors"] for row in sample) / h_n - sum(row["supervised_errors"] for row in sample) / s_n)
    values.sort()
    return {
        "clusters": len(cluster_records),
        "draws": draws,
        "valid_draws": len(values),
        "lower95": values[int(0.025 * len(values))] if values else None,
        "upper95": values[min(len(values) - 1, int(0.975 * len(values)))] if values else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary-cases", type=Path, required=True)
    parser.add_argument("--codehawks-cases", type=Path, required=True)
    parser.add_argument("--llm-runs", type=Path, required=True)
    parser.add_argument("--supervised", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--threshold", type=float, default=0.65)
    args = parser.parse_args()

    all_cases = read(args.primary_cases) + read(args.codehawks_cases)
    cases = {row["case_id"]: row for row in all_cases}
    resolved = {case_id: row for case_id, row in cases.items() if row.get("evidence_available")}
    denominators = Counter(group_name(row) for row in all_cases)
    supervised_files = sorted(args.supervised.glob("*.jsonl"))
    supervised_models = {path.stem: {row["case_id"]: row for row in read(path)} for path in supervised_files}

    baseline_results = {}
    for model, predictions in supervised_models.items():
        model_results = {}
        by_group: dict[str, list[dict]] = defaultdict(list)
        for case_id, prediction in predictions.items():
            case = cases[case_id]
            by_group[group_name(case)].append({"gold_route": case["gold_route"], "prediction": prediction["prediction"]})
        for group, rows in sorted(by_group.items()):
            model_results[group] = decision_metrics(rows, "prediction")
        baseline_results[model] = model_results

    locked_supervised = supervised_models["tfidf_logistic"]
    llm_results, hybrid_results = {}, {}
    for path in sorted(args.llm_runs.glob("*__retrieval.jsonl")):
        runs = {row["case_id"]: row for row in read(path)}
        if not set(runs).issubset(set(resolved)):
            continue
        model = next(iter(runs.values()))["model"]
        by_group_cases: dict[str, list[dict]] = defaultdict(list)
        for case_id in sorted(runs):
            by_group_cases[group_name(resolved[case_id])].append(resolved[case_id])
        llm_results[model], hybrid_results[model] = {}, {}
        for group, group_cases in sorted(by_group_cases.items()):
            required = [row for row in resolved.values() if group_name(row) == group]
            if len(group_cases) != len(required):
                continue
            llm_rows = [
                {"gold_route": case["gold_route"], "prediction": runs[case["case_id"]].get("route") if runs[case["case_id"]].get("parse_valid") else None}
                for case in group_cases
            ]
            metrics = decision_metrics(llm_rows, "prediction")
            metrics["parser_valid"] = sum(runs[case["case_id"]].get("parse_valid", False) for case in group_cases)
            latencies = sorted(float(runs[case["case_id"]].get("latency_s", 0)) for case in group_cases)
            metrics["runtime_errors"] = sum(bool(runs[case["case_id"]].get("error")) for case in group_cases)
            metrics["latency_mean_s"] = statistics.fmean(latencies)
            metrics["latency_median_s"] = statistics.median(latencies)
            metrics["latency_p95_s"] = latencies[min(len(latencies) - 1, int(0.95 * len(latencies)))]
            metrics["quote_match"] = sum(
                codehawks.exact_quote(runs[case["case_id"]], case) if case["platform"] == "CodeHawks" else primary.exact_quote(runs[case["case_id"]], case)
                for case in group_cases
            )
            llm_results[model][group] = metrics

            hybrid_rows = []
            for case in group_cases:
                action = runs[case["case_id"]].get("route") if gate_open(case, runs[case["case_id"]], locked_supervised[case["case_id"]], args.threshold) else "ABSTAIN"
                hybrid_rows.append({"case_id": case["case_id"], "platform": case["platform"], "project_id": case["project_id"], "gold_route": case["gold_route"], "prediction": action})
            hybrid_actions, matched = cluster_matched(group_cases, hybrid_rows, locked_supervised)
            hybrid_metric = decision_metrics(hybrid_actions, "prediction")
            hybrid_metric["conditional_coverage"] = len(hybrid_actions) / len(group_cases)
            hybrid_metric["end_to_end_coverage"] = len(hybrid_actions) / denominators[group]
            hybrid_metric["matched_supervised"] = {
                baseline: decision_metrics(cluster_matched(group_cases, hybrid_rows, baseline_predictions)[1], "prediction")
                for baseline, baseline_predictions in supervised_models.items()
            }
            cluster_records = []
            for cluster in sorted({linked_cluster(case) for case in group_cases}):
                h = [row for row in hybrid_actions if linked_cluster(cases[row["case_id"]]) == cluster]
                cluster_case_ids = {case["case_id"] for case in group_cases if linked_cluster(case) == cluster}
                s = matched_rows([cases[case_id] for case_id in cluster_case_ids], locked_supervised, len(h))
                cluster_records.append({
                    "hybrid_n": len(h), "hybrid_errors": sum(row["prediction"] != row["gold_route"] for row in h),
                    "supervised_n": len(s), "supervised_errors": sum(row["prediction"] != row["gold_route"] for row in s),
                })
            hybrid_metric["cluster_bootstrap"] = bootstrap_difference(cluster_records)
            hybrid_results[model][group] = hybrid_metric
        if not llm_results[model]:
            del llm_results[model]
            del hybrid_results[model]

    codehawks_cases = [row for row in all_cases if row["platform"] == "CodeHawks"]
    codehawks_bias = {
        cohort: resolved_bias([row for row in codehawks_cases if group_name(row) == cohort])
        for cohort in sorted({group_name(row) for row in codehawks_cases})
    }
    output = {
        "status": "m1_analysis_complete_for_available_runs",
        "threshold": args.threshold,
        "denominators": dict(sorted(denominators.items())),
        "resolved_denominators": dict(sorted(Counter(group_name(row) for row in resolved.values()).items())),
        "codehawks_resolved_selection": codehawks_bias,
        "strong_supervised": baseline_results,
        "llm": llm_results,
        "hybrid": hybrid_results,
        "cost_note": "Under-prioritisation multipliers are sensitivity scenarios, not industry-estimated costs.",
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "summary.json").write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"models_complete": sorted(llm_results), "output": str(args.output / 'summary.json')}, indent=2))


if __name__ == "__main__":
    main()
