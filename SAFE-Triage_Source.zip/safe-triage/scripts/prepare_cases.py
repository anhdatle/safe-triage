#!/usr/bin/env python3
"""Resolve pinned source evidence and prepare deterministic evaluation cases."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


PINNED_BLOB = re.compile(
    r"https?://github\.com/([^/\s]+)/([^/\s]+)/blob/([0-9a-fA-F]{40})/([^\s)#]+)(?:#L(\d+)(?:-L(\d+))?)?"
)


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def evidence_descriptor(text: str) -> dict | None:
    match = PINNED_BLOB.search(text.replace("\\_", "_"))
    if not match:
        return None
    owner, repo, commit, source_path, start, end = match.groups()
    source_path = urllib.parse.unquote(source_path)
    raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/{commit}/{source_path}"
    return {
        "evidence_url": match.group(0),
        "raw_url": raw_url,
        "repository_slug": f"{owner}/{repo}",
        "commit": commit,
        "source_path": source_path,
        "line_start": int(start) if start else 1,
        "line_end": int(end) if end else int(start) if start else 80,
    }


def fetch(raw_url: str, cache: Path, pause: float) -> tuple[str, str]:
    key = hashlib.sha256(raw_url.encode()).hexdigest()
    data_path = cache / f"{key}.txt"
    meta_path = cache / f"{key}.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        return (data_path.read_text(encoding="utf-8", errors="replace") if data_path.exists() else ""), str(meta["status"])
    cache.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(raw_url, headers={"User-Agent": "SAFE-Triage-research/0.1"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            body = response.read()
        text = body.decode("utf-8", errors="replace")
        data_path.write_text(text, encoding="utf-8")
        status = "resolved"
        meta = {"raw_url": raw_url, "status": status, "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)}
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        text = ""
        status = f"error:{type(exc).__name__}"
        meta = {"raw_url": raw_url, "status": status, "sha256": "", "bytes": 0}
    meta_path.write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if pause:
        time.sleep(pause)
    return text, status


def snippet(source: str, start: int, end: int) -> str:
    lines = source.splitlines()
    if not lines:
        return ""
    lo = max(1, start - 3)
    hi = min(len(lines), max(end, start) + 3)
    return "\n".join(f"{number}: {lines[number - 1]}" for number in range(lo, hi + 1))


def case_rows(path: Path, platform: str, allowed_splits: set[str], cache: Path, pause: float) -> list[dict]:
    results = []
    for row in read_jsonl(path):
        if str(row["split"]) not in allowed_splits:
            continue
        descriptor = evidence_descriptor(str(row["model_input"]))
        source, status = ("", "missing_pinned_blob")
        if descriptor:
            source, status = fetch(str(descriptor["raw_url"]), cache, pause)
        evidence = snippet(source, int(descriptor["line_start"]), int(descriptor["line_end"])) if descriptor and source else ""
        results.append({
            "case_id": f"{platform.lower()}::{row['record_id']}",
            "platform": platform,
            "project_id": row["repository"],
            "split": row["split"],
            "gold_route": "PRIORITY_REVIEW" if row["outcome"] == "ESCALATE" else "STANDARD_REVIEW",
            "gold_reason": row["outcome_reason"],
            "report_text": row["model_input"],
            "report_sha256": hashlib.sha256(str(row["model_input"]).encode()).hexdigest(),
            "evidence_available": int(bool(evidence)),
            "evidence_status": status,
            "evidence_url": descriptor["evidence_url"] if descriptor else "",
            "repository_slug": descriptor["repository_slug"] if descriptor else "",
            "commit": descriptor["commit"] if descriptor else "",
            "source_path": descriptor["source_path"] if descriptor else "",
            "line_start": descriptor["line_start"] if descriptor else None,
            "line_end": descriptor["line_end"] if descriptor else None,
            "evidence_snippet": evidence,
        })
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--code4rena", type=Path, required=True)
    parser.add_argument("--sherlock", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pause", type=float, default=0.02)
    args = parser.parse_args()
    rows = case_rows(args.code4rena, "Code4rena", {"calibration", "test"}, args.cache, args.pause)
    rows.extend(case_rows(args.sherlock, "Sherlock", {"external"}, args.cache, args.pause))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    summary = {
        "cases": len(rows),
        "evidence_resolved": sum(int(row["evidence_available"]) for row in rows),
        "by_platform_split": {},
    }
    keys = sorted({(row["platform"], row["split"]) for row in rows})
    for platform, split in keys:
        selected = [row for row in rows if row["platform"] == platform and row["split"] == split]
        summary["by_platform_split"][f"{platform}:{split}"] = {
            "cases": len(selected),
            "projects": len({row["project_id"] for row in selected}),
            "evidence_resolved": sum(int(row["evidence_available"]) for row in selected),
        }
    (args.output.parent / "case_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
