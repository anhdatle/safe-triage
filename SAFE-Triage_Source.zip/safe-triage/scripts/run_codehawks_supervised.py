#!/usr/bin/env python3
"""Apply the frozen Code4rena-trained supervised control to CodeHawks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--code4rena", type=Path, required=True)
    parser.add_argument("--codehawks-cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    train = [row for row in read(args.code4rena) if row["split"] == "train"]
    evaluation = read(args.codehawks_cases)
    features = FeatureUnion(
        [
            ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=60000, sublinear_tf=True)),
            ("char", TfidfVectorizer(analyzer="char", ngram_range=(3, 5), min_df=2, max_features=60000, sublinear_tf=True)),
        ]
    )
    x_train = features.fit_transform([row["model_input"] for row in train])
    y_train = [int(row["outcome"] == "ESCALATE") for row in train]
    model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=20260905)
    model.fit(x_train, y_train)
    probabilities = model.predict_proba(features.transform([row["report_text"] for row in evaluation]))[:, 1]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for row, probability in zip(evaluation, probabilities):
            result = {
                "case_id": row["case_id"],
                "evaluation": "codehawks_external_feasibility_v1",
                "platform": "CodeHawks",
                "project_id": row["project_id"],
                "gold_route": row["gold_route"],
                "prediction": "PRIORITY_REVIEW" if probability >= 0.5 else "STANDARD_REVIEW",
                "probability_priority": float(probability),
                "confidence": float(max(probability, 1 - probability)),
            }
            handle.write(json.dumps(result, sort_keys=True) + "\n")
    print(json.dumps({"train": len(train), "evaluated": len(evaluation), "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
