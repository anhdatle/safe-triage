#!/usr/bin/env python3
"""Fetch a deterministic, outcome-blind CodeHawks report-text sample."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from bs4 import BeautifulSoup


class RateLimiter:
    def __init__(self, requests_per_second: float) -> None:
        self.interval = 1.0 / requests_per_second
        self.lock = threading.Lock()
        self.next_time = 0.0

    def wait(self) -> None:
        with self.lock:
            now = time.monotonic()
            delay = max(0.0, self.next_time - now)
            self.next_time = max(now, self.next_time) + self.interval
        if delay:
            time.sleep(delay)


def read_jsonl(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def sample_key(row: dict, seed: str) -> str:
    value = f"{seed}\0{row['contest_id']}\0{row['submission_id']}".encode()
    return hashlib.sha256(value).hexdigest()


def select_outcome_blind(rows: list[dict], per_contest: int, seed: str) -> list[dict]:
    grouped: dict[str, list[dict]] = {}
    for row in rows:
        # Missing public adjudication makes a record ineligible. Among eligible
        # records, neither route nor severity is used for sampling or ranking.
        if row.get("gold_route") is None:
            continue
        grouped.setdefault(row["contest_id"], []).append(row)
    selected = []
    for contest_id, candidates in sorted(grouped.items()):
        ranked = sorted(candidates, key=lambda row: sample_key(row, seed))
        selected.extend(ranked[: min(per_contest, len(ranked))])
    return sorted(selected, key=lambda row: (row["contest_id"], row["submission_id"]))


def fetch_html(url: str, limiter: RateLimiter, retries: int = 4) -> bytes:
    request = Request(
        url,
        headers={
            "User-Agent": "Safe-Triage academic dataset audit/0.1 (public pages; rate limited)",
            "Accept": "text/html,application/xhtml+xml",
        },
    )
    for attempt in range(retries):
        limiter.wait()
        try:
            with urlopen(request, timeout=45) as response:
                return response.read()
        except HTTPError as exc:
            if exc.code not in {429, 500, 502, 503, 504} or attempt + 1 == retries:
                raise
        except URLError:
            if attempt + 1 == retries:
                raise
        time.sleep(2**attempt)
    raise RuntimeError(f"Unable to fetch {url}")


def parse_report_body(html: bytes) -> tuple[str, list[str]]:
    soup = BeautifulSoup(html, "html.parser")
    candidates = soup.select("div.markdown")
    # Templates changed over time: some reports use "Summary:", some begin at
    # "Proof of Concept", and compilations use custom headings. The report body
    # is the largest rendered Markdown block; judgement updates live outside it.
    report = max(candidates, key=lambda node: len(node.get_text(" ", strip=True)), default=None)
    if report is None:
        return "", []
    for block in report.select("script,style"):
        block.decompose()
    text = report.get_text("\n", strip=True)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    links = sorted({a["href"] for a in report.find_all("a", href=True)})
    return text, links


def acquire_one(row: dict, output_dir: Path, limiter: RateLimiter) -> dict:
    destination = output_dir / row["contest_id"] / f"{row['submission_id']}.json"
    if destination.exists():
        cached = json.loads(destination.read_text(encoding="utf-8"))
        if cached.get("report_text"):
            return cached
    html = fetch_html(row["submission_url"], limiter)
    report_text, report_links = parse_report_body(html)
    record = {
        key: row[key]
        for key in [
            "platform",
            "contest_id",
            "submission_id",
            "title",
            "submitted_severity",
            "final_validity",
            "gold_route",
            "submission_url",
            "contest_url",
            "repository_url",
        ]
    }
    record.update(
        {
            "report_text": report_text,
            "report_chars": len(report_text),
            "report_sha256": hashlib.sha256(report_text.encode()).hexdigest(),
            "report_links": report_links,
            "github_blob_links": [u for u in report_links if "github.com/" in u and "/blob/" in u],
            "author_removed": True,
            "judgement_and_tags_excluded_from_model_text": True,
        }
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    return record


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--private-output-dir", type=Path, required=True)
    parser.add_argument("--selection-manifest", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--per-contest", type=int, default=100)
    parser.add_argument("--seed", default="codehawks-external-v1-20260905")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--requests-per-second", type=float, default=4.0)
    args = parser.parse_args()

    selected = select_outcome_blind(read_jsonl(args.index), args.per_contest, args.seed)
    manifest = [
        {
            key: row[key]
            for key in ["contest_id", "submission_id", "submission_url", "submitted_severity", "final_validity", "gold_route"]
        }
        for row in selected
    ]
    write_jsonl(args.selection_manifest, manifest)

    limiter = RateLimiter(args.requests_per_second)
    records = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {executor.submit(acquire_one, row, args.private_output_dir, limiter): row for row in selected}
        for completed, future in enumerate(as_completed(futures), start=1):
            records.append(future.result())
            if completed % 50 == 0:
                print(json.dumps({"reports_completed": completed, "reports_selected": len(selected)}), flush=True)

    records.sort(key=lambda row: (row["contest_id"], row["submission_id"]))
    missing = [f"{row['contest_id']}::{row['submission_id']}" for row in records if not row["report_text"]]
    short = [f"{row['contest_id']}::{row['submission_id']}" for row in records if 0 < row["report_chars"] < 80]
    duplicate_hashes = Counter(row["report_sha256"] for row in records if row["report_text"])
    summary = {
        "selection_seed": args.seed,
        "selection_rule": f"lowest SHA-256 ranks per contest; {args.per_contest} per contest; outcome-blind",
        "selected": len(records),
        "contests": len({row["contest_id"] for row in records}),
        "report_bodies_resolved": sum(bool(row["report_text"]) for row in records),
        "missing_report_bodies": missing,
        "reports_under_80_chars": short,
        "gold_routes": dict(sorted(Counter(row["gold_route"] for row in records).items())),
        "validity": dict(sorted(Counter(row["final_validity"] for row in records).items())),
        "submitted_severity": dict(sorted(Counter(row["submitted_severity"] for row in records).items())),
        "reports_with_github_blob_links": sum(bool(row["github_blob_links"]) for row in records),
        "exact_duplicate_groups": sum(count > 1 for count in duplicate_hashes.values()),
        "reports_in_exact_duplicate_groups": sum(count for count in duplicate_hashes.values() if count > 1),
        "authors_removed": True,
        "complete": not missing and len(records) == args.per_contest * len({row["contest_id"] for row in records}),
        "claim_boundary": "Feasibility sample only; no model result is confirmatory until the analysis policy is frozen.",
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    if not summary["complete"]:
        raise SystemExit("Report-body acquisition audit failed")


if __name__ == "__main__":
    main()
