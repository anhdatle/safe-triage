#!/usr/bin/env python3
"""Derive the 70B prompt-table row on the original 52 pilot report IDs."""
import json
from pathlib import Path

from analyse_runs import exact_quote, read_jsonl

ROOT = Path(__file__).resolve().parents[1]


def main():
    pilot = read_jsonl(ROOT / "artifacts/pilot_runs/llama3.1_8b__retrieval.jsonl")
    ids = {row["case_id"] for row in pilot}
    assert len(ids) == 52
    cases = {row["case_id"]: row for row in read_jsonl(ROOT / "artifacts/cases.jsonl")}
    full = read_jsonl(ROOT / "artifacts/m1/llm_runs/llama3.3_70b__retrieval.jsonl")
    rows = {row["case_id"]: row for row in full if row["case_id"] in ids}
    assert set(rows) == ids
    parsed = sum(bool(row["parse_valid"]) for row in rows.values())
    errors = sum(row["parse_valid"] and row["route"] != row["gold_route"] for row in rows.values())
    quotes = sum(exact_quote(row, cases[key]) for key, row in rows.items())
    result = {"model": "llama3.3:70b", "mode": "retrieval", "n": len(rows),
              "parsed": parsed, "errors": errors, "quote_pass": quotes,
              "parse_rate": parsed / len(rows), "routing_error": errors / parsed,
              "quote_rate": quotes / len(rows),
              "source": "Matched subset of the full 978-report 70B run; not a separate inference run."}
    path = ROOT / "artifacts/submission/capacity70_prompt_counts.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
