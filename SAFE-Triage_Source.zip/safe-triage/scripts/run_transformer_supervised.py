#!/usr/bin/env python3
"""Fine-tune a transformer triage baseline on Code4rena training projects only."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import balanced_accuracy_score, f1_score
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForSequenceClassification, AutoTokenizer


SEED = 20260905


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


class TextDataset(Dataset):
    def __init__(self, texts: list[str], labels: list[int] | None = None) -> None:
        self.texts = texts
        self.labels = labels

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, index: int) -> tuple[str, int | None]:
        return self.texts[index], self.labels[index] if self.labels is not None else None


def collator(tokenizer: object, max_length: int):
    def collate(batch: list[tuple[str, int | None]]) -> dict:
        encoded = tokenizer(
            [row[0] for row in batch], padding=True, truncation=True,
            max_length=max_length, return_tensors="pt"
        )
        if batch[0][1] is not None:
            encoded["labels"] = torch.tensor([row[1] for row in batch], dtype=torch.long)
        return encoded
    return collate


def device() -> torch.device:
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def train_model(model_name: str, rows: list[dict], epochs: int, batch_size: int, max_length: int) -> tuple[object, object, str]:
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)
    target = device()
    model.to(target)
    labels = [int(row["outcome"] == "ESCALATE") for row in rows]
    counts = np.bincount(labels, minlength=2)
    weights = torch.tensor(len(labels) / (2 * counts), dtype=torch.float32, device=target)
    loader = DataLoader(
        TextDataset([row["model_input"] for row in rows], labels),
        batch_size=batch_size, shuffle=True,
        generator=torch.Generator().manual_seed(SEED),
        collate_fn=collator(tokenizer, max_length),
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5)
    model.train()
    for epoch in range(epochs):
        total = 0.0
        for step, batch in enumerate(loader, 1):
            labels_tensor = batch.pop("labels").to(target)
            inputs = {key: value.to(target) for key, value in batch.items()}
            logits = model(**inputs).logits
            loss = torch.nn.functional.cross_entropy(logits, labels_tensor, weight=weights)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            total += float(loss.detach().cpu())
            if step % 25 == 0:
                print(json.dumps({"epoch": epoch + 1, "step": step, "steps": len(loader), "mean_loss": total / step}), flush=True)
    commit = getattr(model.config, "_commit_hash", None) or "unavailable"
    return tokenizer, model, commit


def predict(tokenizer: object, model: object, texts: list[str], batch_size: int, max_length: int) -> np.ndarray:
    target = device()
    loader = DataLoader(TextDataset(texts), batch_size=batch_size, shuffle=False, collate_fn=collator(tokenizer, max_length))
    values = []
    model.eval()
    with torch.no_grad():
        for batch in loader:
            inputs = {key: value.to(target) for key, value in batch.items()}
            values.extend(torch.softmax(model(**inputs).logits, dim=1)[:, 1].cpu().numpy().tolist())
    return np.asarray(values)


def evaluation_rows(primary_cases: list[dict], codehawks_cases: list[dict]) -> list[dict]:
    return [
        {
            "case_id": row["case_id"], "platform": row["platform"], "project_id": row["project_id"],
            "split": row["split"], "gold_route": row["gold_route"], "text": row["report_text"],
            "evidence_available": int(row.get("evidence_available", 0)),
        }
        for row in primary_cases + codehawks_cases
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--code4rena", type=Path, required=True)
    parser.add_argument("--primary-cases", type=Path, required=True)
    parser.add_argument("--codehawks-cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", default="distilroberta-base")
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-length", type=int, default=512)
    args = parser.parse_args()

    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
    train = [row for row in read(args.code4rena) if row["split"] == "train"]
    projects = sorted({row["repository"] for row in train})
    held_projects = {project for project in projects if int(hashlib.sha256(f"transformer-holdout|{project}".encode()).hexdigest(), 16) % 5 == 0}
    fit_rows = [row for row in train if row["repository"] not in held_projects]
    hold_rows = [row for row in train if row["repository"] in held_projects]

    tokenizer, model, commit = train_model(args.model, fit_rows, args.epochs, args.batch_size, args.max_length)
    hold_prob = predict(tokenizer, model, [row["model_input"] for row in hold_rows], args.batch_size, args.max_length)
    hold_true = np.asarray([int(row["outcome"] == "ESCALATE") for row in hold_rows])
    hold_pred = (hold_prob >= 0.5).astype(int)
    del model
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()

    tokenizer, model, commit = train_model(args.model, train, args.epochs, args.batch_size, args.max_length)
    evaluation = evaluation_rows(read(args.primary_cases), read(args.codehawks_cases))
    probs = predict(tokenizer, model, [row["text"] for row in evaluation], args.batch_size, args.max_length)
    args.output.mkdir(parents=True, exist_ok=True)
    output_path = args.output / "distilroberta.jsonl"
    with output_path.open("w", encoding="utf-8") as handle:
        for row, probability in zip(evaluation, probs):
            probability = float(probability)
            handle.write(json.dumps({
                **{key: row[key] for key in ["case_id", "platform", "project_id", "split", "gold_route", "evidence_available"]},
                "model": "distilroberta", "prediction": "PRIORITY_REVIEW" if probability >= 0.5 else "STANDARD_REVIEW",
                "probability_priority": probability, "confidence": max(probability, 1 - probability),
            }, sort_keys=True) + "\n")
    summary = {
        "model": args.model, "model_revision": commit, "epochs": args.epochs, "max_length": args.max_length,
        "device": str(device()), "train_reports": len(train), "train_projects": len(projects),
        "internal_holdout_reports": len(hold_rows), "internal_holdout_projects": len(held_projects),
        "internal_holdout_macro_f1": float(f1_score(hold_true, hold_pred, average="macro")),
        "internal_holdout_balanced_accuracy": float(balanced_accuracy_score(hold_true, hold_pred)),
        "external_data_used_for_tuning": False,
    }
    (args.output / "distilroberta_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
