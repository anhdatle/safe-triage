#!/usr/bin/env python3
"""Build the pinned-code Immunefi positive-transfer case set."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("prepare_cases", HERE / "prepare_cases.py")
CASES = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(CASES)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--reports-root", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pause", type=float, default=0.02)
    args = parser.parse_args()

    output = []
    with args.manifest.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["eligible"] != "1":
                continue
            report_path = args.reports_root / row["relative_path"]
            report_text = report_path.read_text(encoding="utf-8", errors="replace")
            descriptor = CASES.evidence_descriptor(row["pinned_evidence_url"])
            if descriptor is None:
                continue
            source, status = CASES.fetch(descriptor["raw_url"], args.cache, args.pause)
            evidence = CASES.snippet(source, descriptor["line_start"], descriptor["line_end"]) if source else ""
            severity = row["official_severity"].lower()
            output.append({
                "case_id": f"immunefi::{row['project_id']}::{row['report_id']}",
                "platform": "Immunefi",
                "project_id": row["project_id"],
                "split": "positive_transfer",
                "gold_route": "PRIORITY_REVIEW" if severity in {"critical", "high", "medium"} else "STANDARD_REVIEW",
                "gold_reason": f"published_{severity}",
                "report_text": report_text[:6000],
                "report_sha256": hashlib.sha256(report_text.encode()).hexdigest(),
                "report_chars_full": len(report_text),
                "report_chars_model_input": min(len(report_text), 6000),
                "evidence_available": int(bool(evidence)),
                "evidence_status": status,
                "evidence_url": descriptor["evidence_url"],
                "repository_slug": descriptor["repository_slug"],
                "commit": descriptor["commit"],
                "source_path": descriptor["source_path"],
                "line_start": descriptor["line_start"],
                "line_end": descriptor["line_end"],
                "evidence_snippet": evidence,
            })

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for row in output:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    summary = {
        "cases": len(output),
        "projects": len({row["project_id"] for row in output}),
        "evidence_resolved": sum(row["evidence_available"] for row in output),
        "severity_routes_are_descriptive_only": True,
        "warning": "Published Immunefi findings are success-selected and cannot estimate incoming rejection prevalence.",
    }
    (args.output.parent / "immunefi_case_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
