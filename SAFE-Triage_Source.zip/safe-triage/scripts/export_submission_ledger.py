#!/usr/bin/env python3
"""Export derived metrics only; omit report text, code, URLs and identities."""
import json
import re
from collections import defaultdict
from pathlib import Path
from analyse_runs import exact_quote, integrity_pass, read_jsonl, record_id, supervised_map
from audit_negative_study import gate

ROOT = Path(__file__).resolve().parents[1]
LINK = re.compile(r"https?://github\.com/([^/\s]+)/([^/\s]+)/(?:blob|tree)/", re.I)


def code_repos(text):
    return {f"{a}/{b}".lower() for a, b in LINK.findall(text.replace("\\_", "_"))}


def components(project_repos):
    parent = {p: p for p in project_repos}
    def find(p):
        while p != parent[p]:
            parent[p] = parent[parent[p]]
            p = parent[p]
        return p
    owner = {}
    for p, repos in sorted(project_repos.items()):
        for repo in sorted(repos):
            if repo in owner:
                a, b = find(p), find(owner[repo])
                parent[max(a, b)] = min(a, b)
            else:
                owner[repo] = p
    return {p: find(p) for p in project_repos}


def main():
    cases = {r["case_id"]: r for r in read_jsonl(ROOT / "artifacts/cases.jsonl")}
    sup = supervised_map(read_jsonl(ROOT / "artifacts/supervised_predictions.jsonl"))
    project_repos = defaultdict(set)
    training = set()
    legacy_labels = set()
    for filename, platform in [("code4rena_processed.jsonl", "Code4rena"), ("sherlock_processed.jsonl", "Sherlock")]:
        for r in read_jsonl(ROOT / "external_data" / filename):
            if r.get("outcome_reason") == "closed_unlabelled_legacy":
                legacy_labels.add((platform, r["record_id"]))
            key = platform + "/" + r["repository"]
            project_repos[key].update(code_repos(r["model_input"]))
            if platform == "Code4rena" and r["split"] == "train":
                training.add(key)
    comp = components(project_repos)
    train_comp = {comp[p] for p in training}
    project_ids = {p: f"p{i:04}" for i, p in enumerate(sorted(comp))}
    cluster_ids = {p: f"c{i:04}" for i, p in enumerate(sorted(set(comp.values())))}
    ledger = []
    predictions = sorted(read_jsonl(ROOT / "artifacts/full_runs/qwen3_8b__retrieval.jsonl"), key=lambda r: r["case_id"])
    for i, pred in enumerate(predictions):
        c = cases[pred["case_id"]]
        s = sup[c["platform"], record_id(c["case_id"])]
        p = c["platform"] + "/" + c["project_id"]
        actions = {"hybrid": pred["route"] if gate(c, pred, s) else None}
        for check in ("agreement", "support", "quote", "integrity"):
            actions["without_" + check] = pred["route"] if gate(c, pred, s, omit=check) else None
        ledger.append({"id": f"r{i:05}", "partition": c["platform"] + "/" + c["split"],
                       "project": project_ids[p], "cluster": cluster_ids[comp[p]],
                       "training_link": comp[p] in train_comp,
                       "legacy_label": (c["platform"], record_id(c["case_id"])) in legacy_labels,
                       "gold": c["gold_route"], "supervised": s["prediction"], "score": s["confidence"],
                       "retrieval": pred["route"] if pred["parse_valid"] else None,
                       "quote_pass": exact_quote(pred, c), "integrity_pass": integrity_pass(c),
                       "snippet_lines": len(c["evidence_snippet"].splitlines()), **actions})
    out = ROOT / "artifacts/submission"
    out.mkdir(exist_ok=True)
    (out / "decisions.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in ledger))
    diagnostics = []
    immunefi = {r["case_id"]: r for r in read_jsonl(ROOT / "artifacts/immunefi_cases.jsonl")}
    challenge_cases = {r["case_id"]: r for r in read_jsonl(ROOT / "artifacts/challenges_v2.jsonl")}
    challenge_sup = {r["case_id"]: r for r in read_jsonl(ROOT / "artifacts/supervised_challenges_v2.jsonl")}
    base_ids = {s: f"b{i:04}" for i, s in enumerate(sorted({r["base_case_id"] for r in challenge_cases.values()}))}
    for folder in ("pilot_runs", "capacity_pilot", "immunefi_runs", "challenge_runs_v2"):
        for path in sorted((ROOT / "artifacts" / folder).glob("*.jsonl")):
            for r in read_jsonl(path):
                row = {"experiment": folder, "model": r["model"], "mode": r["mode"],
                       "partition": r["platform"] + "/" + r["split"],
                       "parsed": bool(r["parse_valid"]), "route": r["route"], "gold": r["gold_route"]}
                c = (immunefi if folder == "immunefi_runs" else challenge_cases if folder == "challenge_runs_v2" else cases)[r["case_id"]]
                row["quote_pass"] = exact_quote(r, c)
                row["support"] = r.get("evidence_supported") is True
                if folder == "challenge_runs_v2":
                    row.update(base=base_ids[c["base_case_id"]], condition=c["condition"],
                               hybrid=r["route"] if gate(c, r, challenge_sup[c["case_id"]]) else None)
                diagnostics.append(row)
    (out / "diagnostics.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in diagnostics))
    print(f"Exported {len(ledger)} derived records; no source text or repository names.")


if __name__ == "__main__":
    main()
