#!/usr/bin/env python3
"""Create an allowlisted anonymous full-paper and numerical-reproduction ZIP."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    files = {
        "README.md": ROOT / "SUBMISSION_README.md",
        "author_paper/main.tex": ROOT / "author_paper/main.tex",
        "author_paper/full_appendix.tex": ROOT / "author_paper/full_appendix.tex",
        "author_paper/figures/method_overview.tex": ROOT / "author_paper/figures/method_overview.tex",
        "author_paper/figures/containment_result_map.tex": ROOT / "author_paper/figures/containment_result_map.tex",
        "author_paper/figures/containment_result_visualization.tex": ROOT / "author_paper/figures/containment_result_visualization.tex",
        "author_paper/figures/containment_results.png": ROOT / "author_paper/figures/containment_results.png",
        "author_paper/scripts/generate_containment_visualization.py": ROOT / "author_paper/scripts/generate_containment_visualization.py",
        "author_paper/references.bib": ROOT / "author_paper/references.bib",
        "author_paper/llncs.cls": ROOT / "author_paper/llncs.cls",
        "author_paper/splncs04.bst": ROOT / "author_paper/splncs04.bst",
        "paper/SAFE-Triage_Full_Paper.pdf": ROOT / "output/pdf/SAFE-Triage_Full_Paper.pdf",
        "analysis/submission_analysis.py": ROOT / "scripts/submission_analysis.py",
        "data/decisions.jsonl": ROOT / "artifacts/submission/decisions.jsonl",
        "data/diagnostics.jsonl": ROOT / "artifacts/submission/diagnostics.jsonl",
        "results/uncertainty.json": ROOT / "artifacts/submission/uncertainty.json",
        "results/diagnostic_counts.json": ROOT / "artifacts/submission/diagnostic_counts.json",
        "results/paired_counts.json": ROOT / "artifacts/submission/paired_counts.json",
        "results/assurance_summary.json": ROOT / "artifacts/assurance_method_evaluation/summary.json",
        "results/m1_analysis_summary.json": ROOT / "artifacts/m1/analysis/summary.json",
        "results/extended_assurance_summary.json": ROOT / "artifacts/extended_assurance/summary.json",
        "results/challenge_by_model.csv": ROOT / "artifacts/extended_assurance/challenge_by_model.csv",
        "results/clean_action_cost.csv": ROOT / "artifacts/extended_assurance/clean_action_cost.csv",
        "results/containment_efficiency.csv": ROOT / "artifacts/extended_assurance/containment_efficiency.csv",
        "results/risk_coverage.csv": ROOT / "artifacts/extended_assurance/risk_coverage.csv",
        "results/policy_sensitivity.csv": ROOT / "artifacts/extended_assurance/policy_sensitivity.csv",
        "results/business_utility.csv": ROOT / "artifacts/extended_assurance/business_utility.csv",
        "results/defense_system_comparison.csv": ROOT / "artifacts/extended_assurance/defense_system_comparison.csv",
        "results/extended_attack_summary.json": ROOT / "artifacts/extended_attack_analysis/summary.json",
        "results/extended_attack_by_model.csv": ROOT / "artifacts/extended_attack_analysis/challenge_by_model.csv",
        "results/extended_attack_clean_action_cost.csv": ROOT / "artifacts/extended_attack_analysis/clean_action_cost.csv",
        "results/extended_attack_containment_efficiency.csv": ROOT / "artifacts/extended_attack_analysis/containment_efficiency.csv",
        "results/monitoring.json": ROOT / "artifacts/monitoring/historical_qwen32_safe_025_monitor.json",
        "artifacts/monitoring/historical_qwen32_safe_025_monitor.csv": ROOT / "artifacts/monitoring/historical_qwen32_safe_025_monitor.csv",
    }
    for table in sorted((ROOT / "author_paper/tables").glob("*.csv")):
        files[f"author_paper/tables/{table.name}"] = table
    for curve in sorted((ROOT / "artifacts/extended_assurance").glob("risk_curve_*.csv")):
        files[f"artifacts/extended_assurance/{curve.name}"] = curve
    for name in (
        "run_llm.py", "run_supervised_baseline.py", "prepare_cases.py",
        "analyse_runs.py", "audit_negative_study.py", "export_submission_ledger.py",
        "prepare_challenges.py", "prepare_extended_challenges.py",
        "seed_extended_runs.py",
        "extended_assurance_analysis.py", "prepare_monitoring_replay.py",
        "sequential_monitor.py", "evaluate_assurance_methods.py", "run_osp_baseline.py",
        "analyse_m1.py", "run_strong_supervised.py",
    ):
        files["inference/" + name] = ROOT / "scripts" / name
    payloads = {name: path.read_bytes() for name, path in files.items()}
    hashes = {}
    sources = [
        ROOT / "artifacts/cases.jsonl", ROOT / "artifacts/challenges_v2.jsonl",
        ROOT / "artifacts/challenges_extended_v1.jsonl",
        ROOT / "artifacts/immunefi_cases.jsonl", ROOT / "artifacts/supervised_predictions.jsonl",
        ROOT / "artifacts/supervised_challenges_v2.jsonl",
        ROOT / "artifacts/supervised_challenges_extended_v1.jsonl",
    ]
    sources.extend([ROOT / "external_data/code4rena_processed.jsonl", ROOT / "external_data/sherlock_processed.jsonl"])
    for folder in ("full_runs", "pilot_runs", "capacity_pilot", "immunefi_runs", "challenge_runs_v2", "challenge_runs_extended_v1"):
        sources.extend(sorted((ROOT / "artifacts" / folder).glob("*.jsonl")))
    sources.extend(sorted((ROOT / "artifacts/m1/llm_runs").glob("*.jsonl")))
    sources.extend(sorted((ROOT / "artifacts/m1/strong_supervised").glob("*.jsonl")))
    for path in sources:
        hashes[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    payloads["source_hashes.json"] = (json.dumps(hashes, indent=2, sort_keys=True) + "\n").encode()
    for name, data in payloads.items():
        if not name.endswith(".pdf") and (b"/Users/" in data or b"/private/tmp/" in data):
            raise ValueError(f"Local path in release: {name}")
    manifest = {name: hashlib.sha256(data).hexdigest() for name, data in payloads.items()}
    payloads["SHA256SUMS.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    out = ROOT / "output/pdf/SAFE-Triage_Full_Submission_Package.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in sorted(payloads.items()):
            info = zipfile.ZipInfo(name, (2026, 9, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, data)
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        for name, expected in manifest.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == expected
    print(f"Verified {len(payloads)} files in {out.name}")


if __name__ == "__main__":
    main()
