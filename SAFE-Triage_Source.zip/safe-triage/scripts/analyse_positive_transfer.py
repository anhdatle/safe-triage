#!/usr/bin/env python3
"""Summarise Immunefi evidence-grounding transfer without prevalence claims."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def normalise(value: str) -> str:
    return " ".join(str(value).split()).lower()


def quote_ok(prediction: dict, case: dict) -> bool:
    quote = normalise(prediction.get("evidence_quote", ""))
    return len(quote.replace(" ", "")) >= 12 and quote in normalise(case["evidence_snippet"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    cases = {row["case_id"]: row for row in read(args.cases)}
    predictions = read(args.runs)
    by_project = defaultdict(list)
    for prediction in predictions:
        case = cases[prediction["case_id"]]
        by_project[case["project_id"]].append((case, prediction))

    def summarise(items: list[tuple[dict, dict]]) -> dict:
        n = len(items)
        return {
            "n": n,
            "parse_valid": sum(bool(prediction.get("parse_valid")) for _, prediction in items),
            "evidence_supported_true": sum(prediction.get("evidence_supported") is True for _, prediction in items),
            "exact_quote": sum(quote_ok(prediction, case) for case, prediction in items),
            "route_matches_published_severity_band": sum(
                prediction.get("route") == case["gold_route"] for case, prediction in items
            ),
        }

    all_items = [item for items in by_project.values() for item in items]
    summary = {
        "overall": summarise(all_items),
        "by_project": {project: summarise(items) for project, items in sorted(by_project.items())},
        "interpretation": (
            "Evidence-grounding positive transfer only. Published findings are success-selected; "
            "route agreement cannot estimate incoming-queue rejection performance."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary["overall"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
