#!/usr/bin/env python3
"""Prepare a historical project replay for the sequential monitor.

This is a plumbing and sensitivity test, not prospective deployment evidence.
Code4rena project identifiers encode year and month and are replayed in that
order; ties are resolved by project identifier.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import analyse_m1


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--model", default="qwen3:32b")
    parser.add_argument("--threshold", type=float, default=0.54)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    cases = {
        row["case_id"]: row for row in read_jsonl(root / "artifacts/m1/resolved_cases_978.jsonl")
        if row["platform"] == "Code4rena" and row["split"] == "test"
    }
    safe_name = args.model.replace(":", "_")
    runs = {row["case_id"]: row for row in read_jsonl(root / f"artifacts/m1/llm_runs/{safe_name}__retrieval.jsonl") if row["case_id"] in cases}
    supervised = {row["case_id"]: row for row in read_jsonl(root / "artifacts/m1/strong_supervised/tfidf_logistic.jsonl") if row["case_id"] in cases}
    if set(runs) != set(cases) or set(supervised) != set(cases):
        raise ValueError("Monitoring replay requires complete aligned case, LLM, and supervised records")

    by_project: dict[str, list[dict]] = defaultdict(list)
    for case_id, case in cases.items():
        action = runs[case_id].get("route") if analyse_m1.gate_open(case, runs[case_id], supervised[case_id], args.threshold) else None
        by_project[case["project_id"]].append({"case": case, "action": action})

    output = []
    for project_id in sorted(by_project):
        rows = by_project[project_id]
        actions = [row for row in rows if row["action"] is not None]
        unsafe = [row for row in actions if row["action"] != row["case"]["gold_route"]]
        output.append({
            "project_id": project_id,
            "order_key": project_id[:7],
            "eligible_cases": len(rows),
            "automated_cases": len(actions),
            "unsafe_events": len(unsafe),
            "under_priority_events": sum(
                row["action"] == "STANDARD_REVIEW" and row["case"]["gold_route"] == "PRIORITY_REVIEW"
                for row in actions
            ),
            "policy": "safe_triage",
            "model": args.model,
            "threshold": args.threshold,
        })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for row in output:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    print(json.dumps({
        "status": "historical_replay_only",
        "projects": len(output),
        "active_projects": sum(row["automated_cases"] > 0 for row in output),
        "automated_cases": sum(row["automated_cases"] for row in output),
        "unsafe_cases": sum(row["unsafe_events"] for row in output),
    }, indent=2))


if __name__ == "__main__":
    main()
