#!/usr/bin/env python3
"""Compare decision-risk control with the full SAFE-Triage assurance gate.

This is a retrospective meta-evaluation.  It does not claim a conformal or
deployment guarantee.  Thresholds are selected on Code4rena calibration
projects and then frozen for the remaining public partitions.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path

from scipy.stats import beta

import analyse_m1


SEED = 20260906
POLICIES = (
    "supervised_risk_control",
    "llm_confidence_control",
    "agreement_risk_control",
    "safe_triage",
)


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def partition(row: dict) -> str:
    if row["platform"] == "CodeHawks":
        return "CodeHawks/CH-24" if row.get("split") == "expanded_external_m1" else "CodeHawks/CH-6"
    return f"{row['platform']}/{row['split']}"


def cp_upper(errors: int, n: int, alpha: float = 0.05) -> float | None:
    """One-sided Clopper--Pearson upper bound for a Bernoulli rate."""
    if n == 0:
        return None
    if errors == n:
        return 1.0
    return float(beta.ppf(1 - alpha, errors + 1, n - errors))


def point_metrics(rows: list[dict]) -> dict:
    selected = [row for row in rows if row["action"] is not None]
    errors = sum(row["action"] != row["gold"] for row in selected)
    under = sum(row["action"] == "STANDARD_REVIEW" and row["gold"] == "PRIORITY_REVIEW" for row in selected)
    over = sum(row["action"] == "PRIORITY_REVIEW" and row["gold"] == "STANDARD_REVIEW" for row in selected)
    return {
        "n": len(rows),
        "actions": len(selected),
        "coverage": len(selected) / len(rows) if rows else None,
        "errors": errors,
        "risk": errors / len(selected) if selected else None,
        "under": under,
        "over": over,
    }


def project_bootstrap_upper(rows: list[dict], alpha: float = 0.05, draws: int = 2000, salt: str = "") -> float | None:
    """Exploratory upper percentile after resampling complete projects.

    Projects with no selected action remain in the resampling population.  The
    returned value is an empirical sensitivity analysis, not a finite-sample
    conformal guarantee.
    """
    by_project: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        by_project[row["project"]].append(row)
    projects = sorted(by_project)
    if not projects or not any(row["action"] is not None for row in rows):
        return None
    digest = int(hashlib.sha256(salt.encode()).hexdigest()[:8], 16)
    rng = random.Random(SEED + digest)
    values = []
    for _ in range(draws):
        sample = [row for project in rng.choices(projects, k=len(projects)) for row in by_project[project]]
        metric = point_metrics(sample)
        if metric["risk"] is not None:
            values.append(metric["risk"])
    values.sort()
    return values[min(len(values) - 1, int((1 - alpha) * len(values)))] if values else None


def apply_threshold(rows: list[dict], threshold: float | None) -> list[dict]:
    output = []
    for row in rows:
        clone = dict(row)
        clone["action"] = row["route"] if threshold is not None and row["eligible"] and row["score"] >= threshold else None
        output.append(clone)
    return output


def calibrate(rows: list[dict], target: float, alpha: float, draws: int) -> dict:
    """Tune on one project subset and validate once on the other subset."""
    candidates = [round(0.50 + 0.01 * i, 2) for i in range(46)]
    projects = sorted({row["project"] for row in rows})
    tuning_projects = {
        project for project in projects
        if int(hashlib.sha256(project.encode()).hexdigest(), 16) % 3 == 0
    }
    # The fallback is deterministic and only protects very small future inputs.
    if len(tuning_projects) < 5:
        tuning_projects = set(projects[: max(1, len(projects) // 3)])
    tuning_rows = [row for row in rows if row["project"] in tuning_projects]
    validation_rows = [row for row in rows if row["project"] not in tuning_projects]

    eligible = []
    trace = []
    for threshold in candidates:
        selected = apply_threshold(tuning_rows, threshold)
        metric = point_metrics(selected)
        entry = {
            "threshold": threshold,
            **metric,
            "tuning_point_target_met": metric["risk"] is not None and metric["risk"] <= target,
        }
        trace.append(entry)
        if entry["tuning_point_target_met"]:
            eligible.append(entry)
    tuning_choice = max(eligible, key=lambda row: (row["actions"], -row["threshold"]), default=None)
    selected = None
    status = "no_tuning_candidate"
    if tuning_choice:
        fixed = apply_threshold(validation_rows, tuning_choice["threshold"])
        validation = point_metrics(fixed)
        validation["report_cp_upper"] = cp_upper(validation["errors"], validation["actions"], alpha)
        validation["project_bootstrap_upper"] = project_bootstrap_upper(
            fixed, alpha=alpha, draws=draws, salt=f"validation-{tuning_choice['threshold']:.2f}"
        )
        bounds = [validation["report_cp_upper"], validation["project_bootstrap_upper"]]
        validation["controlling_upper"] = max(value for value in bounds if value is not None) if validation["actions"] else None
        validation["target_met"] = validation["controlling_upper"] is not None and validation["controlling_upper"] <= target
        selected = {
            "threshold": tuning_choice["threshold"],
            "tuning": tuning_choice,
            "validation": validation,
            "validated": validation["target_met"],
        }
        status = "validated" if validation["target_met"] else "failed_independent_project_validation"
    return {
        "target_risk": target,
        "alpha": alpha,
        "threshold_grid": [0.50, 0.95, 0.01],
        "project_split": {
            "tuning_projects": len(tuning_projects),
            "validation_projects": len(projects) - len(tuning_projects),
            "rule": "sha256(project) modulo 3 equals zero for tuning; all other projects for validation",
        },
        "selection": "maximum tuning actions with point risk at or below target; fixed threshold evaluated once on disjoint validation projects",
        "selected": selected,
        "status": status,
        "trace": trace,
    }


def base_observations(cases: list[dict], supervised: dict[str, dict], run: dict[str, dict] | None, policy: str) -> list[dict]:
    rows = []
    for case in cases:
        sup = supervised[case["case_id"]]
        if policy == "supervised_risk_control":
            route, score, eligible = sup["prediction"], float(sup["confidence"]), True
        else:
            llm = run[case["case_id"]]  # type: ignore[index]
            if policy == "llm_confidence_control":
                route, score = llm.get("route"), float(llm.get("confidence") or 0.0)
                eligible = bool(llm.get("parse_valid") and route in {"PRIORITY_REVIEW", "STANDARD_REVIEW"})
            elif policy == "agreement_risk_control":
                route, score = llm.get("route"), float(sup["confidence"])
                eligible = bool(llm.get("parse_valid") and route == sup["prediction"])
            elif policy == "safe_triage":
                route, score = llm.get("route"), float(sup["confidence"])
                eligible = analyse_m1.gate_open(case, llm, sup, threshold=0.0)
            else:
                raise ValueError(policy)
        rows.append({
            "case_id": case["case_id"],
            "partition": partition(case),
            "project": f"{case['platform']}::{case['project_id']}",
            "gold": case["gold_route"],
            "route": route,
            "score": score,
            "eligible": eligible,
            "action": None,
        })
    return rows


def evaluate_policy(rows: list[dict], calibration: dict) -> dict:
    threshold = calibration["selected"]["threshold"] if calibration["selected"] else None
    result = {}
    for name in sorted({row["partition"] for row in rows}):
        selected = apply_threshold([row for row in rows if row["partition"] == name], threshold)
        metric = point_metrics(selected)
        metric["report_cp_upper"] = cp_upper(metric["errors"], metric["actions"])
        metric["projects"] = len({row["project"] for row in selected})
        metric["active_projects"] = len({row["project"] for row in selected if row["action"] is not None})
        result[name] = metric
    return result


def challenge_evaluation(
    root: Path,
    maxprob_threshold: float | None,
    agreement_threshold: float | None,
    safe_threshold: float | None,
) -> dict:
    cases = {row["case_id"]: row for row in read_jsonl(root / "artifacts/challenges_v2.jsonl")}
    runs = {row["case_id"]: row for row in read_jsonl(root / "artifacts/challenge_runs_v2/qwen3_8b__retrieval.jsonl")}
    supervised = {row["case_id"]: row for row in read_jsonl(root / "artifacts/supervised_challenges_v2.jsonl")}
    grouped: dict[str, list[dict]] = defaultdict(list)
    for case_id, run in runs.items():
        case, sup = cases[case_id], supervised[case_id]
        agreement_open = bool(
            agreement_threshold is not None
            and run.get("parse_valid")
            and run.get("route") == sup["prediction"]
            and sup["confidence"] >= agreement_threshold
        )
        maxprob_open = bool(maxprob_threshold is not None and sup["confidence"] >= maxprob_threshold)
        safe_open = bool(safe_threshold is not None and analyse_m1.gate_open(case, run, sup, safe_threshold))
        grouped[case["condition"]].append({
            "base": case["base_case_id"],
            "gold": case["gold_route"],
            "llm_route": run.get("route"),
            "supervised_route": sup["prediction"],
            "supervised_open": True,
            "maxprob_open": maxprob_open,
            "agreement_open": agreement_open,
            "safe_open": safe_open,
        })

    output = {}
    clean = {row["base"]: row for row in grouped["clean"]}
    provenance_conditions = {"cross_project_mismatch", "within_repo_mismatch"}
    for condition, rows in sorted(grouped.items()):
        item = {"n": len(rows)}
        methods = (
            ("supervised_no_abstention", "supervised_open", "supervised_route"),
            ("maxprob_selective_prediction", "maxprob_open", "supervised_route"),
            ("agreement_risk_control", "agreement_open", "llm_route"),
            ("safe_triage", "safe_open", "llm_route"),
        )
        for method, field, route_field in methods:
            actions = [row for row in rows if row[field]]
            wrong = [row for row in actions if row[route_field] != row["gold"]]
            newly_wrong = [
                row for row in wrong
                if not (
                    clean.get(row["base"], {}).get(field)
                    and clean[row["base"]][route_field] != clean[row["base"]]["gold"]
                )
            ]
            item[method] = {
                "actions": len(actions),
                "wrong_actions": len(wrong),
                "new_wrong_vs_clean": len(newly_wrong),
                "known_provenance_failure_exposures": len(actions) if condition in provenance_conditions else None,
            }
        output[condition] = item
    clean_rows = grouped["clean"]
    output["clean_cost"] = {
        method: {
            "correct_actions_retained": sum(
                row[field] and row[route_field] == row["gold"] for row in clean_rows
            ),
            "wrong_actions_retained": sum(
                row[field] and row[route_field] != row["gold"] for row in clean_rows
            ),
            "total_actions": sum(row[field] for row in clean_rows),
        }
        for method, field, route_field in (
            ("supervised_no_abstention", "supervised_open", "supervised_route"),
            ("maxprob_selective_prediction", "maxprob_open", "supervised_route"),
            ("agreement_risk_control", "agreement_open", "llm_route"),
            ("safe_triage", "safe_open", "llm_route"),
        )
    }
    return output


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--target-risk", type=float, default=0.15)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--bootstrap-draws", type=int, default=2000)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    output_dir = args.output or root / "artifacts/assurance_method_evaluation"

    all_supervised_rows = read_jsonl(root / "artifacts/m1/strong_supervised/tfidf_logistic.jsonl")
    supervised = {row["case_id"]: row for row in all_supervised_rows}
    resolved_cases = read_jsonl(root / "artifacts/m1/resolved_cases_978.jsonl")
    resolved_ids = {row["case_id"] for row in resolved_cases}
    full_cases = [{
        "case_id": row["case_id"], "platform": row["platform"], "split": row["split"],
        "project_id": row["project_id"], "gold_route": row["gold_route"],
    } for row in all_supervised_rows]
    assert len({row["case_id"] for row in full_cases}) == len(full_cases)
    assert resolved_ids.issubset(supervised)

    results = {
        "design": {
            "status": "retrospective_framework_validation",
            "target_risk": args.target_risk,
            "alpha": args.alpha,
            "calibration_population": "Code4rena/calibration",
            "calibration_unit_sensitivity": "whole project bootstrap",
            "warning": "The project bootstrap is an empirical sensitivity analysis, not a conformal or deployment guarantee.",
        },
        "models": {},
    }

    # The supervised selective policy is a model-independent reference and is
    # evaluated on all labeled reports, including reports without code.
    supervised_rows = base_observations(full_cases, supervised, None, "supervised_risk_control")
    supervised_cal = calibrate(
        [row for row in supervised_rows if row["partition"] == "Code4rena/calibration"],
        args.target_risk, args.alpha, args.bootstrap_draws,
    )
    results["supervised_reference"] = {
        "calibration": supervised_cal,
        "evaluation": evaluate_policy(supervised_rows, supervised_cal),
    }

    for path in sorted((root / "artifacts/m1/llm_runs").glob("*__retrieval.jsonl")):
        all_run = {row["case_id"]: row for row in read_jsonl(path)}
        run = {case_id: row for case_id, row in all_run.items() if case_id in resolved_ids}
        model = next(iter(run.values()))["model"]
        assert set(run) == resolved_ids
        model_result = {}
        for policy in POLICIES[1:]:
            rows = base_observations(resolved_cases, supervised, run, policy)
            calibration = calibrate(
                [row for row in rows if row["partition"] == "Code4rena/calibration"],
                args.target_risk, args.alpha, args.bootstrap_draws,
            )
            model_result[policy] = {
                "calibration": calibration,
                "evaluation": evaluate_policy(rows, calibration),
            }
        results["models"][model] = model_result

    qwen_policies = results["models"]["qwen3:8b"]
    maxprob = results["supervised_reference"]["calibration"]
    agreement = qwen_policies["agreement_risk_control"]["calibration"]
    safe = qwen_policies["safe_triage"]["calibration"]
    maxprob_threshold = maxprob["selected"]["threshold"] if maxprob["selected"] else None
    agreement_threshold = agreement["selected"]["threshold"] if agreement["selected"] else None
    safe_threshold = safe["selected"]["threshold"] if safe["selected"] else None
    results["qwen3_8b_challenges"] = challenge_evaluation(
        root, maxprob_threshold, agreement_threshold, safe_threshold
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    calibration_rows = []
    evaluation_rows = []
    reference = [("tfidf_logistic", "supervised_risk_control", results["supervised_reference"])]
    for model, policies in sorted(results["models"].items()):
        reference.extend((model, name, policy) for name, policy in policies.items())
    for model, policy, result in reference:
        selected = result["calibration"]["selected"]
        validation = selected["validation"] if selected else None
        calibration_rows.append({
            "model": model, "policy": policy, "status": result["calibration"]["status"],
            "threshold": selected["threshold"] if selected else "",
            "actions": validation["actions"] if validation else 0,
            "coverage": validation["coverage"] if validation else 0,
            "risk": validation["risk"] if validation else "",
            "report_cp_upper": validation["report_cp_upper"] if validation else "",
            "project_bootstrap_upper": validation["project_bootstrap_upper"] if validation else "",
        })
        for part, metric in result["evaluation"].items():
            evaluation_rows.append({"model": model, "policy": policy, "partition": part, **metric})
    write_csv(output_dir / "calibration.csv", calibration_rows)
    write_csv(output_dir / "evaluation.csv", evaluation_rows)
    print(json.dumps({"output": str(output_dir), "calibrated_policies": len(calibration_rows)}, indent=2))


if __name__ == "__main__":
    main()
