#!/usr/bin/env python3
"""Audit label, split, and evidence-link properties of the public corpora."""

from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import re
from pathlib import Path


PINNED_GITHUB = re.compile(
    r"https?://github\.com/[^/\s]+/[^/\s]+/(?:blob|tree)/[0-9a-fA-F]{40}(?:/|\b)"
)


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def summarise_jsonl(path: Path, platform: str) -> dict:
    rows = read_jsonl(path)
    split_repos: dict[str, set[str]] = collections.defaultdict(set)
    for row in rows:
        split_repos[str(row["split"])].add(str(row["repository"]))
    overlap = {}
    splits = sorted(split_repos)
    for i, left in enumerate(splits):
        for right in splits[i + 1:]:
            overlap[f"{left}__{right}"] = sorted(split_repos[left] & split_repos[right])
    ids = [str(row["record_id"]) for row in rows]
    input_hashes = [
        str(row.get("model_input_sha256") or hashlib.sha256(str(row["model_input"]).encode()).hexdigest())
        for row in rows
    ]
    return {
        "platform": platform,
        "path": path.name,
        "file_sha256": file_sha256(path),
        "records": len(rows),
        "projects": len({str(row["repository"]) for row in rows}),
        "outcomes": dict(collections.Counter(str(row["outcome"]) for row in rows)),
        "outcome_reasons": dict(collections.Counter(str(row["outcome_reason"]) for row in rows)),
        "splits": dict(collections.Counter(str(row["split"]) for row in rows)),
        "projects_by_split": {key: len(value) for key, value in sorted(split_repos.items())},
        "project_overlap_between_splits": overlap,
        "duplicate_record_ids": len(ids) - len(set(ids)),
        "duplicate_model_inputs": len(input_hashes) - len(set(input_hashes)),
        "records_with_github_url": sum("github.com/" in str(row["model_input"]) for row in rows),
        "records_with_pinned_github_url": sum(bool(PINNED_GITHUB.search(str(row["model_input"]))) for row in rows),
    }


def summarise_immunefi(path: Path) -> dict:
    rows = list(csv.DictReader(path.open(encoding="utf-8")))
    eligible = [row for row in rows if row["eligible"] == "1"]
    split_projects: dict[str, set[str]] = collections.defaultdict(set)
    for row in eligible:
        split_projects[row["split"]].add(row["project_id"])
    return {
        "platform": "Immunefi",
        "path": path.name,
        "file_sha256": file_sha256(path),
        "records_all": len(rows),
        "records_primary_eligible": len(eligible),
        "projects_primary_eligible": len({row["project_id"] for row in eligible}),
        "severities": dict(collections.Counter(row["official_severity"] for row in eligible)),
        "records_by_split": dict(collections.Counter(row["split"] for row in eligible)),
        "projects_by_split": {key: len(value) for key, value in sorted(split_projects.items())},
        "poc_heading": sum(int(row["poc_heading"]) for row in eligible),
        "pinned_same_repository_evidence": sum(bool(row["pinned_evidence_url"]) for row in eligible),
        "role": "evidence-grounding positive transfer; not rejection prevalence",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--code4rena", type=Path, required=True)
    parser.add_argument("--sherlock", type=Path, required=True)
    parser.add_argument("--immunefi", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = {
        "code4rena": summarise_jsonl(args.code4rena, "Code4rena"),
        "sherlock": summarise_jsonl(args.sherlock, "Sherlock"),
        "immunefi": summarise_immunefi(args.immunefi),
        "claim_boundary": (
            "Public adjudicated operational proxies; not a private production queue, "
            "not production prevalence, and not measured reviewer labour savings."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
