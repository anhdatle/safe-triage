#!/usr/bin/env python3
"""Compute minimum independent zero-event units for one-sided risk claims."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def required_units(target_risk: float, alpha: float) -> int:
    return math.ceil(math.log(alpha) / math.log(1 - target_risk))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--alpha", type=float, default=0.05)
    args = parser.parse_args()
    rows = [
        {"target_risk": target, "confidence": 1 - args.alpha, "minimum_zero_event_independent_units": required_units(target, args.alpha)}
        for target in [0.05, 0.10, 0.20]
    ]
    result = {
        "method": "one-sided exact zero-event binomial upper bound",
        "independence_unit": "project_or_competition",
        "rows": rows,
        "warning": "These are automated-project counts, not report counts. Any observed event requires more units.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
