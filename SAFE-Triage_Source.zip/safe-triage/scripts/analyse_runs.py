#!/usr/bin/env python3
"""Analyse LLM modes and the hybrid SAFE-Triage selective gate."""

from __future__ import annotations

import argparse
import csv
import glob
import json
import math
import random
import re
from pathlib import Path


PINNED_REPO = re.compile(
    r"https?://github\.com/([^/\s]+)/([^/\s]+)/(?:blob|tree)/[0-9a-fA-F]{40}(?:/|\b)",
    re.IGNORECASE,
)
INJECTION = re.compile(
    r"ignore\s+(?:all|any|previous|prior)\s+instructions|system\s+override|"
    r"return\s+priority_review\s+with\s+confidence",
    re.IGNORECASE,
)


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def normalise(value: str) -> str:
    return " ".join(str(value).split()).lower()


def report_repository(text: str) -> str:
    match = PINNED_REPO.search(text.replace("\\_", "_"))
    return f"{match.group(1)}/{match.group(2)}".lower() if match else ""


def exact_quote(prediction: dict, case: dict) -> bool:
    quote = normalise(prediction.get("evidence_quote", ""))
    return len(quote.replace(" ", "")) >= 12 and quote in normalise(case["evidence_snippet"])


def integrity_pass(case: dict) -> bool:
    report_repo = report_repository(case["report_text"])
    evidence_repo = str(case["repository_slug"]).lower()
    evidence_url = str(case.get("evidence_url", "")).replace("\\_", "_")
    report_text = str(case["report_text"]).replace("\\_", "_")
    return (
        bool(report_repo)
        and report_repo == evidence_repo
        and bool(evidence_url)
        and evidence_url in report_text
        and not INJECTION.search(report_text)
    )


def metrics(rows: list[dict]) -> dict:
    n = len(rows)
    automated = [row for row in rows if row["action"] != "ABSTAIN"]
    unsafe = [row for row in automated if row["action"] != row["gold_route"]]
    priority = [row for row in rows if row["gold_route"] == "PRIORITY_REVIEW"]
    under = [row for row in priority if row["action"] == "STANDARD_REVIEW"]
    return {
        "n": n,
        "projects": len({row["project_id"] for row in rows}),
        "automated": len(automated),
        "coverage": len(automated) / n if n else 0,
        "unsafe": len(unsafe),
        "unsafe_rate": len(unsafe) / len(automated) if automated else None,
        "priority_cases": len(priority),
        "under_prioritised": len(under),
        "under_priority_rate": len(under) / len(priority) if priority else None,
    }


def bootstrap_upper(rows: list[dict], field: str, draws: int = 2000) -> float | None:
    by_project = {}
    for row in rows:
        by_project.setdefault(row["project_id"], []).append(row)
    projects = sorted(by_project)
    if len(projects) < 2:
        return None
    rng = random.Random(20260905)
    values = []
    for _ in range(draws):
        sample = []
        for project in (rng.choice(projects) for _ in projects):
            sample.extend(by_project[project])
        value = metrics(sample)[field]
        if value is not None:
            values.append(value)
    if not values:
        return None
    values.sort()
    return values[min(len(values) - 1, int(0.95 * len(values)))]


def binomial_cdf(k: int, n: int, probability: float) -> float:
    return sum(
        math.comb(n, index) * probability**index * (1 - probability) ** (n - index)
        for index in range(k + 1)
    )


def exact_upper(k: int, n: int, alpha: float = 0.05) -> float | None:
    if n == 0:
        return None
    if k == n:
        return 1.0
    low, high = 0.0, 1.0
    for _ in range(80):
        middle = (low + high) / 2
        if binomial_cdf(k, n, middle) > alpha:
            low = middle
        else:
            high = middle
    return high


def zero_event_projects_required(target: float, alpha: float = 0.05) -> int:
    n = 1
    while exact_upper(0, n, alpha) > target:
        n += 1
    return n


def project_event_upper(rows: list[dict], event: str) -> tuple[int, int, float | None]:
    by_project = {}
    for row in rows:
        by_project.setdefault(row["project_id"], []).append(row)
    eligible, failed = 0, 0
    for project_rows in by_project.values():
        if event == "unsafe":
            relevant = [row for row in project_rows if row["action"] != "ABSTAIN"]
            flags = [row["action"] != row["gold_route"] for row in relevant]
        else:
            relevant = [row for row in project_rows if row["gold_route"] == "PRIORITY_REVIEW"]
            flags = [row["action"] == "STANDARD_REVIEW" for row in relevant]
        if relevant:
            eligible += 1
            failed += int(any(flags))
    return failed, eligible, exact_upper(failed, eligible)


def supervised_map(rows: list[dict]) -> dict[tuple[str, str], dict]:
    return {(row["platform"], row["record_id"]): row for row in rows}


def record_id(case_id: str) -> str:
    return case_id.split("::", 1)[1].split("::", 1)[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--supervised", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    cases = {row["case_id"]: row for row in read_jsonl(args.cases)}
    supervised = supervised_map(read_jsonl(args.supervised))
    run_files = sorted(Path(value) for value in glob.glob(str(args.runs / "*.jsonl")))
    by_model_mode = {}
    descriptive = []
    for path in run_files:
        rows = read_jsonl(path)
        if not rows:
            continue
        key = (rows[0]["model"], rows[0]["mode"])
        by_model_mode[key] = {row["case_id"]: row for row in rows}
        groups = sorted({(row["platform"], row["split"]) for row in rows})
        for platform, split in groups:
            selected = [row for row in rows if row["platform"] == platform and row["split"] == split]
            evaluated = [{"project_id": row["project_id"], "gold_route": row["gold_route"], "action": row["route"] if row["parse_valid"] else "ABSTAIN"} for row in selected]
            result = {"model": key[0], "system": key[1], "platform": platform, "split": split, "threshold": "", **metrics(evaluated)}
            result["unsafe_rate_upper95_project_bootstrap"] = bootstrap_upper(evaluated, "unsafe_rate")
            result["under_priority_upper95_project_bootstrap"] = bootstrap_upper(evaluated, "under_priority_rate")
            result["unsafe_projects"], result["automated_projects"], result["unsafe_project_rate_upper95_exact"] = project_event_upper(evaluated, "unsafe")
            result["under_priority_projects"], result["priority_projects"], result["under_priority_project_rate_upper95_exact"] = project_event_upper(evaluated, "under")
            descriptive.append(result)

    gate_rows = []
    for (model, mode), predictions in sorted(by_model_mode.items()):
        if mode != "retrieval":
            continue
        for threshold in [value / 100 for value in range(50, 100, 5)]:
            groups = sorted({(cases[case_id]["platform"], cases[case_id]["split"]) for case_id in predictions})
            for platform, split in groups:
                evaluated = []
                for case_id, pred in predictions.items():
                    case = cases[case_id]
                    if case["platform"] != platform or case["split"] != split:
                        continue
                    sup = supervised.get((case["platform"], record_id(case_id)))
                    opens = bool(
                        sup
                        and pred["parse_valid"]
                        and pred["route"] == sup["prediction"]
                        and float(sup["confidence"]) >= threshold
                        and pred.get("evidence_supported") is True
                        and exact_quote(pred, case)
                        and integrity_pass(case)
                    )
                    evaluated.append({
                        "project_id": case["project_id"],
                        "gold_route": case["gold_route"],
                        "action": pred["route"] if opens else "ABSTAIN",
                    })
                result = {"model": model, "system": "safe_triage_hybrid", "platform": platform, "split": split, "threshold": threshold, **metrics(evaluated)}
                result["unsafe_rate_upper95_project_bootstrap"] = bootstrap_upper(evaluated, "unsafe_rate")
                result["under_priority_upper95_project_bootstrap"] = bootstrap_upper(evaluated, "under_priority_rate")
                result["unsafe_projects"], result["automated_projects"], result["unsafe_project_rate_upper95_exact"] = project_event_upper(evaluated, "unsafe")
                result["under_priority_projects"], result["priority_projects"], result["under_priority_project_rate_upper95_exact"] = project_event_upper(evaluated, "under")
                gate_rows.append(result)

    rows = descriptive + gate_rows
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    eligible = [
        row for row in gate_rows
        if row["platform"] == "Code4rena" and row["split"] == "calibration"
        and row["coverage"] >= 0.20
        and row["unsafe_project_rate_upper95_exact"] is not None
        and row["unsafe_project_rate_upper95_exact"] <= 0.10
        and row["under_priority_project_rate_upper95_exact"] is not None
        and row["under_priority_project_rate_upper95_exact"] <= 0.05
    ]
    decision = max(eligible, key=lambda row: row["coverage"], default=None)
    locked_evaluations = []
    if decision:
        locked_evaluations = [
            row for row in gate_rows
            if row["model"] == decision["model"] and row["threshold"] == decision["threshold"]
            and not (row["platform"] == "Code4rena" and row["split"] == "calibration")
        ]
    calibration_projects = len({
        row["project_id"] for row in cases.values()
        if row["platform"] == "Code4rena" and row["split"] == "calibration"
    })
    required_10 = zero_event_projects_required(0.10)
    required_5 = zero_event_projects_required(0.05)
    summary = {
        "status": "retrospective_diagnostic_only",
        "selection_decision": decision or "no_go",
        "interpretation": decision and "selected" or "safety_not_established_and_protocol_redesign",
        "protocol_feasibility": {
            "calibration_projects": calibration_projects,
            "minimum_zero_event_projects_for_10pct_upper95": required_10,
            "minimum_zero_event_projects_for_5pct_upper95": required_5,
            "posthoc_project_event_rule_pass_possible": calibration_projects >= max(required_10, required_5),
            "protocol_note": "Project-event exact bounds are posthoc; v0.1 specified report-risk cluster bootstrap bounds. These are different estimands.",
        },
        "locked_evaluations": locked_evaluations,
        "models": sorted({model for model, _ in by_model_mode}),
        "run_files": [path.name for path in run_files],
        "warning": "Pilot touched Code4rena test projects; no confirmatory claim is allowed.",
    }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
