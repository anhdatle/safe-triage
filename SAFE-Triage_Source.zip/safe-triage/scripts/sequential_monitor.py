#!/usr/bin/env python3
"""Anytime-valid project-event monitoring for a frozen SAFE-Triage version."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def log_mixture_ratio(p: float, events: int, n: int, a: float = 0.5, b: float = 0.5) -> float:
    p = min(1 - 1e-15, max(1e-15, p))
    return (
        log_beta(events + a, n - events + b)
        - log_beta(a, b)
        - events * math.log(p)
        - (n - events) * math.log1p(-p)
    )


def upper_confidence_sequence(events: int, n: int, alpha: float = 0.05) -> float | None:
    if n == 0:
        return None
    threshold = math.log(1 / alpha)
    low = events / n
    high = 1 - 1e-15
    if log_mixture_ratio(high, events, n) < threshold:
        return 1.0
    for _ in range(100):
        middle = (low + high) / 2
        if log_mixture_ratio(middle, events, n) < threshold:
            low = middle
        else:
            high = middle
    return high


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--risk-budget", type=float, default=0.10)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--csv-output", type=Path)
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.events.read_text(encoding="utf-8").splitlines() if line]
    seen, events, history = 0, 0, []
    for row in rows:
        if int(row.get("automated_cases", 0)) <= 0:
            continue
        seen += 1
        events += int(int(row.get("unsafe_events", 0)) > 0)
        upper = upper_confidence_sequence(events, seen, args.alpha)
        history.append({
            "project_id": row["project_id"],
            "automated_projects": seen,
            "unsafe_projects": events,
            "unsafe_project_rate": events / seen,
            "anytime_upper": upper,
            "within_budget": bool(upper is not None and upper <= args.risk_budget),
        })
    result = {
        "method": "beta-binomial mixture anytime-valid confidence sequence",
        "alpha": args.alpha,
        "risk_budget": args.risk_budget,
        "history": history,
        "latest": history[-1] if history else None,
        "assumptions": [
            "one Bernoulli unsafe-event indicator per independently finalised project",
            "one frozen system version and eligibility policy",
            "complete outcome capture in chronological order",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    if args.csv_output and history:
        args.csv_output.parent.mkdir(parents=True, exist_ok=True)
        with args.csv_output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(history[0]))
            writer.writeheader()
            writer.writerows(history)
    print(json.dumps(result["latest"], indent=2))


if __name__ == "__main__":
    main()
