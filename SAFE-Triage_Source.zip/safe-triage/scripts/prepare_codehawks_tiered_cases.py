#!/usr/bin/env python3
"""Resolve CodeHawks evidence under explicit provenance tiers A, B, or D."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from collections import Counter
from pathlib import Path
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen

import prepare_cases as base


BLOB = re.compile(r"^/([^/]+)/([^/]+)/blob/([^/]+)/(.+)$", re.IGNORECASE)
LINES = re.compile(r"^L(\d+)(?:-L(\d+))?$")


def read_records(root: Path) -> list[dict]:
    return [json.loads(path.read_text(encoding="utf-8")) for path in sorted(root.glob("*/*.json"))]


def repo_slug(url: str) -> str:
    parsed = urlparse(url)
    parts = parsed.path.strip("/").split("/")
    return "/".join(parts[:2]).removesuffix(".git").lower() if len(parts) >= 2 else ""


def linked_cluster(contest_id: str) -> str:
    value = contest_id.lower()
    for family in ["beanstalk", "sablier", "zaros", "stake-link", "stakelink"]:
        if family in value:
            return "stakelink" if family in {"stake-link", "stakelink"} else family
    return contest_id


def parse_blob(url: str) -> dict | None:
    parsed = urlparse(url.replace("\\_", "_"))
    if parsed.netloc.lower() not in {"github.com", "www.github.com"}:
        return None
    match = BLOB.match(parsed.path)
    if not match:
        return None
    owner, repository, ref, source_path = match.groups()
    line_match = LINES.match(parsed.fragment)
    start = int(line_match.group(1)) if line_match else None
    end = int(line_match.group(2) or line_match.group(1)) if line_match else None
    return {
        "repository_slug": f"{owner}/{repository}".removesuffix(".git").lower(),
        "ref": ref,
        "source_path": source_path,
        "line_start": start,
        "line_end": end,
        "evidence_url": url,
    }


def get_json(url: str) -> dict:
    request = Request(url, headers={"User-Agent": "Safe-Triage academic evidence resolver/0.2"})
    with urlopen(request, timeout=60) as response:
        return json.loads(response.read().decode())


def resolve_commit(slug: str, ref: str) -> str | None:
    if re.fullmatch(r"[0-9a-fA-F]{40}", ref):
        return ref.lower()
    try:
        return str(get_json(f"https://api.github.com/repos/{slug}/commits/{quote(ref, safe='')} ".strip())["sha"]).lower()
    except Exception:
        return None


def source_text(slug: str, commit: str, source_path: str, cache: Path, pause: float) -> tuple[str, str]:
    url = f"https://raw.githubusercontent.com/{slug}/{commit}/{source_path}"
    key = hashlib.sha256(url.encode()).hexdigest()
    destination = cache / f"{key}.txt"
    if destination.exists():
        return destination.read_text(encoding="utf-8", errors="replace"), "cached"
    try:
        request = Request(url, headers={"User-Agent": "Safe-Triage academic evidence resolver/0.2"})
        with urlopen(request, timeout=60) as response:
            body = response.read().decode("utf-8", errors="replace")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(body, encoding="utf-8")
        time.sleep(pause)
        return body, "resolved"
    except Exception as exc:
        return "", f"{type(exc).__name__}"


def resolve(row: dict, cache: Path, pause: float) -> tuple[dict | None, str, str]:
    official = repo_slug(row.get("repository_url", ""))
    for link in row.get("report_links", []):
        descriptor = parse_blob(link)
        if descriptor is None or descriptor["repository_slug"] != official:
            continue
        commit = resolve_commit(descriptor["repository_slug"], descriptor["ref"])
        if not commit:
            continue
        source, status = source_text(descriptor["repository_slug"], commit, descriptor["source_path"], cache, pause)
        if source:
            tier = "A_FULL_COMMIT" if re.fullmatch(r"[0-9a-fA-F]{40}", descriptor["ref"]) else "B_RESOLVED_REF"
            descriptor.update({"commit": commit, "evidence_tier": tier})
            return descriptor, source, status
    return None, "", "D_UNRESOLVED"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reports-root", type=Path, required=True)
    parser.add_argument("--source-cache", type=Path, required=True)
    parser.add_argument("--private-output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--pause", type=float, default=0.05)
    args = parser.parse_args()
    records = read_records(args.reports_root)
    output = []
    for index, row in enumerate(records, 1):
        descriptor, source, status = resolve(row, args.source_cache, args.pause)
        start = (descriptor or {}).get("line_start") or 1
        end = (descriptor or {}).get("line_end") or 80
        evidence = base.snippet(source, start, end) if descriptor else ""
        output.append({
            "case_id": f"codehawks::{row['contest_id']}::{row['submission_id']}",
            "platform": "CodeHawks", "project_id": row["contest_id"], "split": "expanded_external_m1",
            "gold_route": row["gold_route"], "gold_reason": f"codehawks_{row['final_validity']}_{row['submitted_severity']}",
            "report_text": f"Title: {row['title']}\n\nReport:\n{row['report_text']}"[:6000],
            "report_chars_full": len(row["report_text"]), "report_sha256": row["report_sha256"],
            "evidence_available": int(bool(evidence)),
            "evidence_tier": descriptor["evidence_tier"] if descriptor else "D_UNRESOLVED", "evidence_status": status,
            "evidence_url": descriptor["evidence_url"] if descriptor else "", "repository_slug": descriptor["repository_slug"] if descriptor else "",
            "contest_repository_url": row.get("repository_url", ""), "commit": descriptor["commit"] if descriptor else "",
            "source_path": descriptor["source_path"] if descriptor else "", "line_start": descriptor["line_start"] if descriptor else None,
            "line_end": descriptor["line_end"] if descriptor else None, "evidence_snippet": evidence,
        })
        if index % 100 == 0:
            print(json.dumps({"completed": index, "total": len(records)}), flush=True)
    args.private_output.parent.mkdir(parents=True, exist_ok=True)
    with args.private_output.open("w", encoding="utf-8") as handle:
        for row in output:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    summary = {
        "cases": len(output), "contests": len({row["project_id"] for row in output}),
        "linked_project_clusters": len({linked_cluster(row["project_id"]) for row in output}),
        "tiers": dict(sorted(Counter(row["evidence_tier"] for row in output).items())),
        "resolved": sum(row["evidence_available"] for row in output),
        "claim_boundary": "Tier B resolves a report-supplied ref to a full commit; tiers are reported separately.",
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
