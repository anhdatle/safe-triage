#!/usr/bin/env python3
"""Audit the attacker-controlled claimed-severity shortcut in Sherlock text."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
from sklearn.pipeline import FeatureUnion


CLAIM = re.compile(r"(Report:\s+\S+\s+)(critical|high|medium|low)(\s+#)", re.IGNORECASE)


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def mask(text: str) -> str:
    return CLAIM.sub(r"\1[CLAIMED_SEVERITY]\3", text, count=1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--training", type=Path, required=True)
    parser.add_argument("--sherlock", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    training = [row for row in read(args.training) if row["split"] == "train"]
    sherlock = read(args.sherlock)
    features = FeatureUnion([
        ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=60000, sublinear_tf=True)),
        ("char", TfidfVectorizer(analyzer="char", ngram_range=(3, 5), min_df=2, max_features=60000, sublinear_tf=True)),
    ])
    train_matrix = features.fit_transform([row["model_input"] for row in training])
    model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=20260905)
    model.fit(train_matrix, [int(row["outcome"] == "ESCALATE") for row in training])
    original = model.predict(features.transform([row["model_input"] for row in sherlock]))
    masked = model.predict(features.transform([mask(row["model_input"]) for row in sherlock]))
    gold = [int(row["outcome"] == "ESCALATE") for row in sherlock]
    result = {
        "n": len(sherlock),
        "claimed_severity_header_present": sum(bool(CLAIM.search(row["model_input"])) for row in sherlock),
        "balanced_accuracy_original": float(balanced_accuracy_score(gold, original)),
        "balanced_accuracy_masked": float(balanced_accuracy_score(gold, masked)),
        "route_changes_after_masking": int(sum(a != b for a, b in zip(original, masked))),
        "interpretation": (
            "Claimed severity is available at submission but attacker-controlled, not final-adjudication ground truth. "
            "The masked result tests shortcut dependence; it is not a new held-out evaluation."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
