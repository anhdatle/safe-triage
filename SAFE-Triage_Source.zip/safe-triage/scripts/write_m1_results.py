#!/usr/bin/env python3
"""Render an auditable Markdown summary of M1 analyses."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def pct(value: float | None) -> str:
    return "--" if value is None else f"{100 * value:.1f}%"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--strong-summary", type=Path, required=True)
    parser.add_argument("--expanded-index", type=Path)
    parser.add_argument("--expanded-reports", type=Path)
    parser.add_argument("--expanded-cases", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    analysis = json.loads(args.analysis.read_text(encoding="utf-8"))
    strong = json.loads(args.strong_summary.read_text(encoding="utf-8"))

    lines = [
        "# M1 limitation-remediation results", "",
        "## Evidence status", "",
        "Existing Code4rena and Sherlock results remain retrospective. The original six-contest CodeHawks result is frozen external replication. Expanded historical CodeHawks contests are external evidence, not prospective confirmation. Future contests remain pending by definition.", "",
        "## Repository-grouped supervised model selection", "",
        "| Model | Mean macro-F1 | Balanced accuracy |", "|---|---:|---:|",
    ]
    for model, row in strong["cv"].items():
        lines.append(f"| {model} | {row['macro_f1_mean']:.3f} | {row['balanced_accuracy_mean']:.3f} |")
    lines += ["", f"Training-only selected model: `{strong['training_selected_model']}`. External results were not used for selection.", ""]
    transformer_path = args.strong_summary.parent / "distilroberta_summary.json"
    if transformer_path.exists():
        transformer = json.loads(transformer_path.read_text(encoding="utf-8"))
        lines += [
            "The fixed DistilRoBERTa control used one deterministic repository holdout rather than the five CV folds above: "
            f"macro-F1 {transformer['internal_holdout_macro_f1']:.3f}, balanced accuracy "
            f"{transformer['internal_holdout_balanced_accuracy']:.3f} on "
            f"{transformer['internal_holdout_reports']} reports from {transformer['internal_holdout_projects']} projects. External data were not used for tuning.",
            "",
        ]

    lines += ["## Supervised external performance", "", "| Model | Partition | Error | Priority precision | Priority recall | Under / over |", "|---|---|---:|---:|---:|---:|"]
    for model, groups in analysis["strong_supervised"].items():
        for group, row in groups.items():
            lines.append(f"| {model} | {group} | {row['errors']}/{row['decisions']} ({pct(row['error_rate'])}) | {pct(row['priority_precision'])} | {pct(row['priority_recall'])} | {row['under_prioritised']} / {row['over_prioritised']} |")

    lines += ["", "## Full-scale LLM and hybrid results", "", "| LLM | Partition | Valid output | LLM error | Quote match | Median latency | Hybrid coverage conditional / end-to-end | Hybrid error |", "|---|---|---:|---:|---:|---:|---:|---:|"]
    for model, groups in analysis["llm"].items():
        for group, row in groups.items():
            hybrid = analysis["hybrid"][model][group]
            lines.append(
                f"| {model} | {group} | {row['parser_valid']}/{row['n']} | {row['errors']}/{row['decisions']} ({pct(row['error_rate'])}) | {row['quote_match']}/{row['n']} | {row['latency_median_s']:.2f} s | {pct(hybrid['conditional_coverage'])} / {pct(hybrid['end_to_end_coverage'])} | {hybrid['errors']}/{hybrid['decisions']} ({pct(hybrid['error_rate'])}) |"
            )

    lines += ["", "## Asymmetric routing cost", "", "Costs below assign ten units to an under-prioritised report and one unit to an over-prioritised report. This is a sensitivity analysis, not an empirically estimated business cost.", "", "| System | Partition | Under / over | Equal-cost loss | 10:1 loss |", "|---|---|---:|---:|---:|"]
    for model, groups in analysis["llm"].items():
        for group, row in groups.items():
            costs = row["cost_per_decision"]
            lines.append(
                f"| LLM {model} | {group} | {row['under_prioritised']} / {row['over_prioritised']} | {costs['under_1_over_1']:.3f} | {costs['under_10_over_1']:.3f} |"
            )
    for model, groups in analysis["strong_supervised"].items():
        for group, row in groups.items():
            costs = row["cost_per_decision"]
            lines.append(
                f"| Supervised {model} | {group} | {row['under_prioritised']} / {row['over_prioritised']} | {costs['under_1_over_1']:.3f} | {costs['under_10_over_1']:.3f} |"
            )

    lines += ["", "## Hybrid versus supervised at identical workload", "", "| LLM gate | Partition | Actions | Hybrid errors | Selected logistic errors | Hybrid minus logistic 95% cluster interval |", "|---|---|---:|---:|---:|---:|"]
    for model, groups in analysis["hybrid"].items():
        for group, row in groups.items():
            matched = row["matched_supervised"]["tfidf_logistic"]
            interval = row["cluster_bootstrap"]
            lines.append(
                f"| {model} | {group} | {row['decisions']} | {row['errors']} | {matched['errors']} | [{pct(interval['lower95'])}, {pct(interval['upper95'])}] ({interval['clusters']} clusters) |"
            )

    lines += ["", "## CodeHawks evidence-resolution selection", ""]
    for cohort, result in analysis["codehawks_resolved_selection"].items():
        r, u = result["resolved"], result["unresolved"]
        comparisons = result["comparisons"]
        lines += [
            f"### {cohort}", "",
            f"Resolved reports: {r['n']}; priority prevalence {pct(r['priority_prevalence'])}; median length {r['median_report_chars']} characters.",
            f"Unresolved reports: {u['n']}; priority prevalence {pct(u['priority_prevalence'])}; median length {u['median_report_chars']} characters.",
            f"Resolved-versus-unresolved priority odds ratio: {comparisons['priority_prevalence_fisher']['odds_ratio_resolved_vs_unresolved']:.2f}; descriptive Fisher p={comparisons['priority_prevalence_fisher']['p_value']:.3g}.", "",
        ]

    present = {}
    if args.expanded_index and args.expanded_index.exists():
        value = json.loads(args.expanded_index.read_text(encoding="utf-8"))
        present["Expanded index"] = {"contests": value.get("contests"), "records": value.get("records"), "complete": value.get("complete")}
    if args.expanded_reports and args.expanded_reports.exists():
        value = json.loads(args.expanded_reports.read_text(encoding="utf-8"))
        present["Expanded report sample"] = {key: value.get(key) for key in ["contests", "selected", "report_bodies_resolved", "exact_duplicate_groups", "reports_in_exact_duplicate_groups", "complete"]}
    if args.expanded_cases and args.expanded_cases.exists():
        value = json.loads(args.expanded_cases.read_text(encoding="utf-8"))
        present["Expanded evidence cases"] = value
    if present:
        lines += ["## Expanded CodeHawks acquisition", ""]
        for name, value in present.items():
            lines.append(f"- **{name}:** `{json.dumps(value, sort_keys=True)}`")
        lines.append("")

    lines += [
        "## Claim boundary", "",
        "Completion of M1 reduces model, baseline, coverage, selection and clustering limitations. It does not create private-industry validity, expert semantic validation, or prospective results for competitions that did not exist at protocol freeze.", "",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
