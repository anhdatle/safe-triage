#!/usr/bin/env python3
"""Separate future evaluation cases from labels before model inference."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path


FORBIDDEN = ("gold", "outcome", "validity", "severity", "judgement", "tag", "author")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def write(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def blind_row(row: dict) -> dict:
    return {key: value for key, value in row.items() if not any(token in key.lower() for token in FORBIDDEN)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--blind-output", type=Path, required=True)
    parser.add_argument("--sealed-labels", type=Path, required=True)
    parser.add_argument("--lock", type=Path, required=True)
    args = parser.parse_args()

    rows = read(args.cases)
    blind = [blind_row(row) for row in rows]
    labels = [{"case_id": row["case_id"], "gold_route": row["gold_route"]} for row in rows]
    if any(any(token in key.lower() for token in FORBIDDEN) for row in blind for key in row):
        raise ValueError("Outcome-bearing field remained in blind output")
    write(args.blind_output, blind)
    write(args.sealed_labels, labels)
    os.chmod(args.sealed_labels, 0o600)
    lock = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "awaiting_predictions",
        "cases": len(rows),
        "blind_cases_sha256": sha256(args.blind_output),
        "sealed_labels_sha256": sha256(args.sealed_labels),
        "rule": "Prediction files must be hashed before labels are opened for evaluation.",
    }
    args.lock.parent.mkdir(parents=True, exist_ok=True)
    args.lock.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(lock, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

