#!/usr/bin/env python3
"""Create a local cryptographic lock manifest before LLM inference."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


INCLUDE = [
    "PROTOCOL.md",
    "PROMPTS.md",
    "DATA_SCHEMA.md",
    "RESEARCH_DESIGN.md",
    "scripts/build_manifest.py",
    "scripts/audit_public_corpora.py",
    "scripts/prepare_cases.py",
    "scripts/prepare_challenges.py",
    "scripts/run_llm.py",
    "external_data/code4rena_processed.jsonl",
    "external_data/sherlock_processed.jsonl",
    "artifacts/manifest/reports.csv",
    "artifacts/cases.jsonl",
    "artifacts/challenges.jsonl",
]


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    files = []
    for relative in INCLUDE:
        path = root / relative
        if not path.exists():
            raise FileNotFoundError(path)
        files.append({"path": relative, "bytes": path.stat().st_size, "sha256": digest(path)})
    payload = {
        "lock_version": "safe-triage-local-lock-v0.1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": files,
        "limitation": "Local hash lock; external timestamp/public preregistration remains required for prospective claims.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
