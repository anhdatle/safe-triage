#!/usr/bin/env python3
"""Train stronger report-triage controls using Code4rena training data only."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.metrics import balanced_accuracy_score, f1_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import FeatureUnion
from sklearn.svm import LinearSVC


SEED = 20260905


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def features() -> FeatureUnion:
    return FeatureUnion(
        [
            ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=60000, sublinear_tf=True)),
            ("char", TfidfVectorizer(analyzer="char", ngram_range=(3, 5), min_df=2, max_features=60000, sublinear_tf=True)),
        ]
    )


def estimators() -> dict[str, object]:
    return {
        "tfidf_logistic": LogisticRegression(max_iter=3000, class_weight="balanced", random_state=SEED),
        "tfidf_linear_svc": LinearSVC(C=1.0, class_weight="balanced", random_state=SEED),
        "tfidf_modified_huber": SGDClassifier(
            loss="modified_huber", alpha=1e-5, max_iter=3000, class_weight="balanced", random_state=SEED
        ),
    }


def sigmoid(value: np.ndarray) -> np.ndarray:
    clipped = np.clip(value, -30, 30)
    return 1.0 / (1.0 + np.exp(-clipped))


def probabilities(model: object, matrix: object) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        return np.asarray(model.predict_proba(matrix))[:, 1]
    return sigmoid(np.asarray(model.decision_function(matrix), dtype=float))


def grouped_cv(train: list[dict]) -> dict[str, dict]:
    groups = np.asarray([row["repository"] for row in train])
    labels = np.asarray([int(row["outcome"] == "ESCALATE") for row in train])
    texts = np.asarray([row["model_input"] for row in train], dtype=object)
    folds = min(5, len(set(groups)))
    results: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for train_idx, valid_idx in GroupKFold(n_splits=folds).split(texts, labels, groups):
        vectorizer = features()
        x_train = vectorizer.fit_transform(texts[train_idx])
        x_valid = vectorizer.transform(texts[valid_idx])
        for name, estimator in estimators().items():
            estimator.fit(x_train, labels[train_idx])
            predicted = estimator.predict(x_valid)
            results[name].append(
                (f1_score(labels[valid_idx], predicted, average="macro"), balanced_accuracy_score(labels[valid_idx], predicted))
            )
    return {
        name: {
            "folds": folds,
            "macro_f1_mean": float(np.mean([value[0] for value in values])),
            "macro_f1_folds": [float(value[0]) for value in values],
            "balanced_accuracy_mean": float(np.mean([value[1] for value in values])),
        }
        for name, values in sorted(results.items())
    }


def evaluation_rows(primary_cases: list[dict], codehawks_cases: list[dict]) -> list[dict]:
    rows = []
    for row in primary_cases + codehawks_cases:
        rows.append(
            {
                "case_id": row["case_id"],
                "platform": row["platform"],
                "project_id": row["project_id"],
                "split": row["split"],
                "gold_route": row["gold_route"],
                "text": row["report_text"],
                "evidence_available": int(row.get("evidence_available", 0)),
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--code4rena", type=Path, required=True)
    parser.add_argument("--primary-cases", type=Path, required=True)
    parser.add_argument("--codehawks-cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    train = [row for row in read(args.code4rena) if row["split"] == "train"]
    evaluations = evaluation_rows(read(args.primary_cases), read(args.codehawks_cases))
    cv = grouped_cv(train)
    vectorizer = features()
    x_train = vectorizer.fit_transform([row["model_input"] for row in train])
    y_train = np.asarray([int(row["outcome"] == "ESCALATE") for row in train])
    x_eval = vectorizer.transform([row["text"] for row in evaluations])

    args.output.mkdir(parents=True, exist_ok=True)
    for name, estimator in estimators().items():
        estimator.fit(x_train, y_train)
        probs = probabilities(estimator, x_eval)
        path = args.output / f"{name}.jsonl"
        with path.open("w", encoding="utf-8") as handle:
            for row, probability in zip(evaluations, probs):
                probability = float(probability)
                if not math.isfinite(probability):
                    raise ValueError(f"Non-finite score for {row['case_id']}")
                output = {
                    **{key: row[key] for key in ["case_id", "platform", "project_id", "split", "gold_route", "evidence_available"]},
                    "model": name,
                    "prediction": "PRIORITY_REVIEW" if probability >= 0.5 else "STANDARD_REVIEW",
                    "probability_priority": probability,
                    "confidence": max(probability, 1 - probability),
                }
                handle.write(json.dumps(output, sort_keys=True) + "\n")
    best = max(cv, key=lambda name: (cv[name]["macro_f1_mean"], name))
    summary = {
        "status": "training_only_grouped_model_selection",
        "train_reports": len(train),
        "train_projects": len({row["repository"] for row in train}),
        "evaluation_reports": len(evaluations),
        "cv": cv,
        "training_selected_model": best,
        "selection_rule": "highest mean repository-grouped CV macro-F1; external data not used",
        "score_note": "SVC decision scores use a fixed sigmoid for ranking and are not calibrated probabilities.",
    }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

