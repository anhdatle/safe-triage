#!/usr/bin/env python3
"""Seed the extended suite with identical clean outputs from the paired run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--main-run", type=Path, required=True)
    parser.add_argument("--extended-cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--preserve-existing", action="store_true")
    parser.add_argument("--selection-run", type=Path)
    args = parser.parse_args()
    clean_ids = {row["case_id"] for row in read(args.extended_cases) if row["condition"] == "clean"}
    if args.selection_run:
        selected_ids = {
            row.get("base_case_id", row["case_id"]) for row in read(args.selection_run)
            if row.get("condition") == "clean"
        }
        clean_ids &= selected_ids
    rows = [row for row in read(args.main_run) if row["case_id"] in clean_ids and row["condition"] == "clean"]
    if {row["case_id"] for row in rows} != clean_ids:
        raise ValueError("The extended clean set is not identical to the completed paired run")
    existing = read(args.output) if args.preserve_existing and args.output.exists() else []
    if args.selection_run:
        existing = [row for row in existing if row.get("base_case_id", row["case_id"]) in clean_ids]
    by_id = {row["case_id"]: row for row in existing}
    for row in rows:
        by_id.setdefault(row["case_id"], row)
    combined = list(by_id.values())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for row in combined:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(json.dumps({
        "seeded_clean_cases": len(rows), "preserved_existing": len(existing),
        "unique_output_rows": len(combined), "output": str(args.output)
    }, indent=2))


if __name__ == "__main__":
    main()
