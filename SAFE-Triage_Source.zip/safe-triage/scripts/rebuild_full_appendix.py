#!/usr/bin/env python3
"""Restore the full evaluation and result narrative as same-PDF appendices."""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "author_paper"


def between(text: str, start: str, end: str) -> str:
    i = text.index(start)
    j = text.index(end, i)
    return text[i:j].rstrip() + "\n"


def namespace_labels(text: str, prefix: str) -> str:
    labels = set(re.findall(r"\\label\{([^}]+)\}", text))
    for label in sorted(labels, key=len, reverse=True):
        renamed = f"{prefix}:{label}"
        text = text.replace(f"\\label{{{label}}}", f"\\label{{{renamed}}}")
        text = text.replace(f"\\ref{{{label}}}", f"\\ref{{{renamed}}}")
        text = text.replace(f"\\eqref{{{label}}}", f"\\eqref{{{renamed}}}")
    return text


def remove_moved_figures(text: str) -> str:
    """Remove figures promoted to the 15-page main text."""
    for label in (
        "appfull:fig:interface_gap",
        "appfull:fig:containment-tradeoff",
        "appfull:fig:riskcoverage",
        "appfull:fig:coverage-gap",
    ):
        pattern = (
            r"\\begin\{figure\}\[htb\]"
            r"(?:(?!\\end\{figure\}).)*?"
            + re.escape(f"\\label{{{label}}}")
            + r"(?:(?!\\end\{figure\}).)*?\\end\{figure\}\n"
        )
        text, count = re.subn(pattern, "", text, count=1, flags=re.DOTALL)
        if count != 1:
            raise ValueError(f"Could not remove promoted figure {label}")
    return text


def main() -> None:
    source = (PAPER / "supplement.tex").read_text()
    evaluation = between(
        source, "\\section{Evaluation Methodology}", "\\section{Results}"
    )
    results = between(source, "\\section{Results}", "\\section{Discussion}")

    evaluation = evaluation.replace(
        "\\section{Evaluation Methodology}",
        "\\section{Full Evaluation Protocol}",
        1,
    )
    results = results.replace(
        "\\section{Results}", "\\section{Complete Experimental Results}", 1
    )
    restored = namespace_labels(evaluation + "\n" + results, "appfull")
    restored = restored.replace(
        "\\ref{tab:assurance-map}", "\\ref{tab:assurance-map-app}"
    )
    restored = remove_moved_figures(restored)
    for old, new in {
        "appfull:fig:interface_gap": "fig:interface-gap-main",
        "appfull:fig:containment-tradeoff": "fig:containment-main",
        "appfull:fig:riskcoverage": "fig:risk-coverage-main",
        "appfull:fig:coverage-gap": "fig:coverage-gap-main",
    }.items():
        restored = restored.replace(f"\\ref{{{old}}}", f"\\ref{{{new}}}")
    header = (
        "% Generated from supplement.tex by scripts/rebuild_full_appendix.py.\n"
        "% It preserves the complete pre-compression evaluation narrative.\n"
    )
    (PAPER / "full_appendix.tex").write_text(header + restored)

    main_path = PAPER / "main.tex"
    main_text = main_path.read_text()
    if "\\input{full_appendix}" not in main_text:
        concise_eval_start = main_text.index("\\section{Evaluation and Statistical Details}")
        data_start = main_text.index("\\section{Data and Retrieval Details}", concise_eval_start)
        main_text = (
            main_text[:concise_eval_start]
            + "\\input{full_appendix}\n\n"
            + main_text[data_start:]
        )
        extended_start = main_text.index("\\section{Extended Results}")
        prompt_clear = main_text.index(
            "\\clearpage\n\\section{Prompt and Serving Diagnostic}", extended_start
        )
        main_text = main_text[:extended_start] + main_text[prompt_clear:]
        main_path.write_text(main_text)


if __name__ == "__main__":
    main()
