#!/usr/bin/env python3
"""Analyse the frozen CodeHawks external evaluation without retuning."""

from __future__ import annotations

import argparse
import json
import random
import re
from collections import Counter, defaultdict
from pathlib import Path


INJECTION = re.compile(
    r"ignore\s+(?:all|any|previous|prior)\s+instructions|system\s+override|"
    r"return\s+priority_review\s+with\s+confidence",
    re.IGNORECASE,
)


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def normalise(value: str) -> str:
    return " ".join(str(value).split()).lower()


def repo_slug(url: str) -> str:
    match = re.search(r"github\.com/([^/]+/[^/#?]+)", url, re.IGNORECASE)
    return match.group(1).removesuffix(".git").lower() if match else ""


def exact_quote(prediction: dict, case: dict) -> bool:
    quote = normalise(prediction.get("evidence_quote", ""))
    return len(quote.replace(" ", "")) >= 12 and quote in normalise(case["evidence_snippet"])


def integrity_pass(case: dict) -> bool:
    return bool(
        case.get("evidence_url")
        and re.fullmatch(r"[0-9a-fA-F]{40}", str(case.get("commit", "")))
        and repo_slug(case.get("contest_repository_url", "")) == str(case.get("repository_slug", "")).lower()
        and not INJECTION.search(case["report_text"])
    )


def action_metrics(rows: list[dict]) -> dict:
    actions = [row for row in rows if row["action"] != "ABSTAIN"]
    errors = sum(row["action"] != row["gold_route"] for row in actions)
    return {
        "n": len(rows),
        "automated": len(actions),
        "coverage": len(actions) / len(rows) if rows else 0.0,
        "errors": errors,
        "error_rate": errors / len(actions) if actions else None,
        "priority_actions": sum(row["action"] == "PRIORITY_REVIEW" for row in actions),
        "standard_actions": sum(row["action"] == "STANDARD_REVIEW" for row in actions),
        "under_prioritised": sum(
            row["gold_route"] == "PRIORITY_REVIEW" and row["action"] == "STANDARD_REVIEW" for row in actions
        ),
    }


def matched_supervised(cases: list[dict], supervised: dict[str, dict], count: int) -> list[dict]:
    ranked = sorted(cases, key=lambda row: (-supervised[row["case_id"]]["confidence"], row["case_id"]))[:count]
    return [
        {
            "case_id": row["case_id"],
            "gold_route": row["gold_route"],
            "action": supervised[row["case_id"]]["prediction"],
        }
        for row in ranked
    ]


def bootstrap_difference(per_contest: list[dict], draws: int = 5000) -> dict:
    # Resample all competition clusters. Zero-action competitions remain part of
    # the deployment population even though they contribute no matched actions.
    usable = list(per_contest)
    rng = random.Random(20260905)
    values = []
    for _ in range(draws):
        sample = [rng.choice(usable) for _ in usable]
        h_err = sum(row["hybrid"]["errors"] for row in sample)
        h_n = sum(row["hybrid"]["automated"] for row in sample)
        s_err = sum(row["supervised_matched"]["errors"] for row in sample)
        s_n = sum(row["supervised_matched"]["automated"] for row in sample)
        if h_n and s_n:
            values.append(h_err / h_n - s_err / s_n)
    values.sort()
    return {
        "draws": draws,
        "valid_draws": len(values),
        "point_difference": (
            sum(row["hybrid"]["errors"] for row in usable) / sum(row["hybrid"]["automated"] for row in usable)
            - sum(row["supervised_matched"]["errors"] for row in usable)
            / sum(row["supervised_matched"]["automated"] for row in usable)
        ),
        "lower95": values[int(0.025 * len(values))],
        "upper95": values[min(len(values) - 1, int(0.975 * len(values)))],
        "clusters": len(usable),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--llm", type=Path, required=True)
    parser.add_argument("--supervised", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--threshold", type=float, default=0.65)
    args = parser.parse_args()

    cases = {row["case_id"]: row for row in read(args.cases)}
    predictions = {row["case_id"]: row for row in read(args.llm)}
    supervised = {row["case_id"]: row for row in read(args.supervised)}
    eligible = [cases[case_id] for case_id in sorted(predictions)]
    by_contest = defaultdict(list)
    per_case = []
    for case in eligible:
        pred = predictions[case["case_id"]]
        sup = supervised[case["case_id"]]
        quote = exact_quote(pred, case)
        integrity = integrity_pass(case)
        opens = bool(
            pred["parse_valid"]
            and pred["route"] == sup["prediction"]
            and sup["confidence"] >= args.threshold
            and pred.get("evidence_supported") is True
            and quote
            and integrity
        )
        row = {
            "case_id": case["case_id"],
            "contest_id": case["project_id"],
            "gold_route": case["gold_route"],
            "llm_parse_valid": pred["parse_valid"],
            "llm_route": pred["route"],
            "llm_correct": pred["parse_valid"] and pred["route"] == case["gold_route"],
            "agreement": pred["parse_valid"] and pred["route"] == sup["prediction"],
            "supervised_confident": sup["confidence"] >= args.threshold,
            "support": pred.get("evidence_supported") is True,
            "quote_match": quote,
            "integrity": integrity,
            "hybrid_action": pred["route"] if opens else "ABSTAIN",
        }
        per_case.append(row)
        by_contest[case["project_id"]].append(row)

    contest_results = []
    for contest, rows in sorted(by_contest.items()):
        contest_cases = [cases[row["case_id"]] for row in rows]
        hybrid_rows = [
            {"gold_route": row["gold_route"], "action": row["hybrid_action"]} for row in rows
        ]
        hybrid = action_metrics(hybrid_rows)
        matched = action_metrics(matched_supervised(contest_cases, supervised, hybrid["automated"]))
        parsed = [row for row in rows if row["llm_parse_valid"]]
        contest_results.append(
            {
                "contest_id": contest,
                "evidence_eligible": len(rows),
                "llm_parser_valid": len(parsed),
                "llm_errors": sum(not row["llm_correct"] for row in parsed),
                "llm_error_rate": sum(not row["llm_correct"] for row in parsed) / len(parsed) if parsed else None,
                "gate_components": {
                    name: sum(row[name] for row in rows)
                    for name in ["agreement", "supervised_confident", "support", "quote_match", "integrity"]
                },
                "hybrid": hybrid,
                "supervised_matched": matched,
                "end_to_end_hybrid_coverage": hybrid["automated"] / 100,
            }
        )

    pooled_hybrid_rows = [
        {"gold_route": row["gold_route"], "action": row["hybrid_action"]} for row in per_case
    ]
    pooled_hybrid = action_metrics(pooled_hybrid_rows)
    pooled_matched_rows = []
    for result in contest_results:
        contest_cases = [case for case in eligible if case["project_id"] == result["contest_id"]]
        pooled_matched_rows.extend(matched_supervised(contest_cases, supervised, result["hybrid"]["automated"]))
    parsed = [row for row in per_case if row["llm_parse_valid"]]
    all_supervised = list(supervised.values())
    result = {
        "status": "frozen_external_evaluation_complete",
        "threshold": args.threshold,
        "sample_reports": len(supervised),
        "evidence_eligible": len(eligible),
        "llm_parser_valid": len(parsed),
        "llm_errors": sum(not row["llm_correct"] for row in parsed),
        "llm_error_rate": sum(not row["llm_correct"] for row in parsed) / len(parsed) if parsed else None,
        "hybrid": pooled_hybrid,
        "supervised_matched": action_metrics(pooled_matched_rows),
        "supervised_all_600": {
            "errors": sum(row["prediction"] != row["gold_route"] for row in all_supervised),
            "error_rate": sum(row["prediction"] != row["gold_route"] for row in all_supervised) / len(all_supervised),
        },
        "cluster_bootstrap_hybrid_minus_supervised": bootstrap_difference(contest_results),
        "by_contest": contest_results,
        "gate_components": {
            name: sum(row[name] for row in per_case)
            for name in ["agreement", "supervised_confident", "support", "quote_match", "integrity"]
        },
        "claim_boundary": "Six external competition clusters; not certification evidence.",
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "summary.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with (args.output / "per_case.jsonl").open("w", encoding="utf-8") as handle:
        for row in per_case:
            handle.write(json.dumps(row, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
