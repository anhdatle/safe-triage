#!/usr/bin/env python3
"""Text-domain, OSP-style adaptation inspired by Gangrade et al. (2021).

The published OSP decision rule learns one score per class, retains only the
argmax class above a common threshold, and searches model/threshold settings
for high coverage subject to an error target. Here, the original image
backbone and minimax optimizer are replaced by two class-weighted TF-IDF
logistic heads. Selection uses the study's conditional selective-error endpoint
rather than OSP's raw population-error endpoint. This is therefore an
OSP-style linear adaptation, not a reproduction of the published algorithm.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression

from evaluate_assurance_methods import cp_upper, project_bootstrap_upper
from run_strong_supervised import SEED, features


ROUTES = ("STANDARD_REVIEW", "PRIORITY_REVIEW")


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def tuning_projects(projects: set[str]) -> set[str]:
    selected = {
        project for project in projects
        if int(hashlib.sha256(f"Code4rena::{project}".encode()).hexdigest(), 16) % 3 == 0
    }
    if len(selected) < 5:
        selected = set(sorted(projects)[: max(1, len(projects) // 3)])
    return selected


def route_scores(class_scores: np.ndarray, threshold: float) -> tuple[np.ndarray, np.ndarray]:
    """Apply OSP-style decision regions: argmax class above a common threshold."""
    winner = class_scores.argmax(axis=1)
    confidence = class_scores[np.arange(len(class_scores)), winner]
    action = np.where(confidence >= threshold, winner, -1)
    return action, confidence


def metrics(actions: np.ndarray, gold: np.ndarray) -> dict:
    chosen = actions >= 0
    errors = int(np.sum(actions[chosen] != gold[chosen]))
    n_actions = int(np.sum(chosen))
    return {
        "n": int(len(gold)),
        "actions": n_actions,
        "coverage": n_actions / len(gold) if len(gold) else None,
        "errors": errors,
        "risk": errors / n_actions if n_actions else None,
    }


def select_configuration(
    candidates: dict[float, np.ndarray],
    gold: np.ndarray,
    tune_mask: np.ndarray,
    target: float,
) -> dict | None:
    trace = []
    feasible = []
    for positive_weight, scores in sorted(candidates.items()):
        for threshold in (round(0.50 + 0.01 * i, 2) for i in range(46)):
            actions, _ = route_scores(scores[tune_mask], threshold)
            row = {"positive_weight": positive_weight, "threshold": threshold, **metrics(actions, gold[tune_mask])}
            row["tuning_point_target_met"] = row["risk"] is not None and row["risk"] <= target
            trace.append(row)
            if row["tuning_point_target_met"]:
                feasible.append(row)
    if not feasible:
        return None
    return max(feasible, key=lambda row: (row["actions"], -row["threshold"], -row["positive_weight"]))


def fit_heads(x_train: object, y_train: np.ndarray, x_eval: object, weights: list[float]) -> dict[float, np.ndarray]:
    outputs = {}
    for positive_weight in weights:
        columns = []
        for class_index in range(2):
            binary = (y_train == class_index).astype(int)
            head = LogisticRegression(
                max_iter=3000,
                class_weight={0: 1.0, 1: positive_weight},
                random_state=SEED,
            )
            head.fit(x_train, binary)
            columns.append(head.predict_proba(x_eval)[:, 1])
        outputs[positive_weight] = np.column_stack(columns)
    return outputs


def challenge_summary(rows: list[dict], actions: np.ndarray) -> dict:
    grouped: dict[str, list[tuple[dict, int]]] = defaultdict(list)
    for row, action in zip(rows, actions):
        grouped[row["condition"]].append((row, int(action)))
    clean = {row["base_case_id"]: (row, action) for row, action in grouped["clean"]}
    output = {}
    for condition, pairs in sorted(grouped.items()):
        selected = [(row, action) for row, action in pairs if action >= 0]
        wrong = [(row, action) for row, action in selected if ROUTES[action] != row["gold_route"]]
        new_wrong = 0
        for row, action in wrong:
            clean_row, clean_action = clean[row["base_case_id"]]
            if clean_action < 0 or ROUTES[clean_action] == clean_row["gold_route"]:
                new_wrong += 1
        output[condition] = {
            "n": len(pairs),
            "actions": len(selected),
            "wrong_actions": len(wrong),
            "new_wrong_vs_clean": new_wrong,
        }
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--target-risk", type=float, default=0.15)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--bootstrap-draws", type=int, default=2000)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output or root / "artifacts/published_baselines/osp_linear"

    source = read_jsonl(root / "external_data/code4rena_processed.jsonl")
    train = [row for row in source if row["split"] == "train"]
    evaluation = read_jsonl(root / "artifacts/cases.jsonl")
    qwen_ids = {
        row["case_id"] for row in read_jsonl(root / "artifacts/challenge_runs_v2/qwen3_8b__retrieval.jsonl")
    }
    challenges = [
        row for row in read_jsonl(root / "artifacts/challenges_v2.jsonl") if row["case_id"] in qwen_ids
    ]

    vectorizer = features()
    x_train = vectorizer.fit_transform([row["model_input"] for row in train])
    x_eval = vectorizer.transform([row["report_text"] for row in evaluation])
    x_challenge = vectorizer.transform([row["report_text"] for row in challenges])
    y_train = np.asarray([int(row["outcome"] == "ESCALATE") for row in train])
    y_eval = np.asarray([int(row["gold_route"] == "PRIORITY_REVIEW") for row in evaluation])
    weights = [0.25, 0.5, 1.0, 2.0, 4.0]
    eval_scores = fit_heads(x_train, y_train, x_eval, weights)
    challenge_scores = fit_heads(x_train, y_train, x_challenge, weights)

    calibration_mask = np.asarray([
        row["platform"] == "Code4rena" and row["split"] == "calibration" for row in evaluation
    ])
    calibration_projects = {row["project_id"] for row, keep in zip(evaluation, calibration_mask) if keep}
    tune_projects = tuning_projects(calibration_projects)
    tune_mask = np.asarray([
        keep and row["project_id"] in tune_projects for row, keep in zip(evaluation, calibration_mask)
    ])
    validation_mask = calibration_mask & ~tune_mask
    choice = select_configuration(eval_scores, y_eval, tune_mask, args.target_risk)

    status = "no_tuning_candidate"
    validation = None
    challenge = None
    if choice:
        scores = eval_scores[choice["positive_weight"]]
        validation_actions, _ = route_scores(scores[validation_mask], choice["threshold"])
        validation = metrics(validation_actions, y_eval[validation_mask])
        validation["report_cp_upper"] = cp_upper(validation["errors"], validation["actions"], args.alpha)
        bootstrap_rows = []
        selected_rows = [row for row, keep in zip(evaluation, validation_mask) if keep]
        for row, action in zip(selected_rows, validation_actions):
            bootstrap_rows.append({
                "project": f"Code4rena::{row['project_id']}",
                "route": ROUTES[action] if action >= 0 else None,
                "gold": row["gold_route"],
                "action": ROUTES[action] if action >= 0 else None,
            })
        validation["project_bootstrap_upper"] = project_bootstrap_upper(
            bootstrap_rows, args.alpha, args.bootstrap_draws, "osp-linear-validation"
        )
        bounds = [validation["report_cp_upper"], validation["project_bootstrap_upper"]]
        validation["controlling_upper"] = max(value for value in bounds if value is not None)
        validation["target_met"] = validation["controlling_upper"] <= args.target_risk
        status = "validated" if validation["target_met"] else "failed_independent_project_validation"
        challenge_actions, _ = route_scores(
            challenge_scores[choice["positive_weight"]], choice["threshold"]
        )
        challenge = challenge_summary(challenges, challenge_actions)

    result = {
        "method": "OSP-style linear adaptation",
        "publication": "Gangrade, Kag, and Saligrama, AISTATS 2021",
        "fidelity_boundary": (
            "Retains OSP's class-wise decision-region structure and coverage-maximising "
            "grid search; replaces its minimax training with class-weighted TF-IDF logistic "
            "heads and uses conditional selective error rather than OSP's raw population error."
        ),
        "target_risk": args.target_risk,
        "status": status,
        "training_reports": len(train),
        "training_projects": len({row["repository"] for row in train}),
        "tuning_projects": len(tune_projects),
        "validation_projects": len(calibration_projects - tune_projects),
        "weights": weights,
        "selected": choice,
        "validation": validation,
        "challenges": challenge,
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
