#!/usr/bin/env python3
"""Discover completed public professional CodeHawks contests and submission totals."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from urllib.request import Request, urlopen

from bs4 import BeautifulSoup


BASE = "https://codehawks.cyfrin.io"
USER_AGENT = "Safe-Triage academic dataset audit/0.2 (public pages; rate limited)"


def fetch(url: str) -> bytes:
    request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html"})
    with urlopen(request, timeout=60) as response:
        return response.read()


def contest_cards(html: bytes) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    records: dict[str, dict] = {}
    for link in soup.select('a[href^="/c/"]'):
        href = link.get("href", "")
        contest_id = href.removeprefix("/c/").strip("/")
        if not contest_id or contest_id in records:
            continue
        node = link
        for _ in range(5):
            node = node.parent
        text = " ".join(node.stripped_strings)
        access = "Public" if re.search(r"\bPublic\b", text) else "Private" if re.search(r"\bPrivate\b", text) else "Invite-only" if "Invite-only" in text else "Unknown"
        date_match = re.match(r"(20\d{2})-(\d{2})-", contest_id)
        year_month = f"{date_match.group(1)}-{date_match.group(2)}" if date_match else ""
        records[contest_id] = {
            "contest_id": contest_id,
            "contest_url": f"{BASE}{href}",
            "access": access,
            "year_month": year_month,
        }
    return sorted(records.values(), key=lambda row: row["contest_id"])


def submission_total(contest_id: str) -> tuple[int, str | None]:
    html = fetch(f"{BASE}/c/{contest_id}/submissions?page=1")
    soup = BeautifulSoup(html, "html.parser")
    plain = " ".join(soup.stripped_strings)
    count_match = re.search(r"\b(\d+)\s*/\s*(\d+)\b", plain)
    raw = html.decode("utf-8", errors="replace")
    repo_match = re.search(r'githubUrl:"(https://github\.com/[^"?]+)', raw)
    return (int(count_match.group(2)) if count_match else 0, repo_match.group(1) if repo_match else None)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cutoff", default="2025-12")
    args = parser.parse_args()

    candidates = [
        row for row in contest_cards(fetch(f"{BASE}/contests"))
        if row["access"] == "Public" and row["year_month"] and row["year_month"] <= args.cutoff
    ]
    records = []
    for row in candidates:
        total, repository_url = submission_total(row["contest_id"])
        if total:
            records.append({**row, "expected_total": total, "repository_url": repository_url})
            print(json.dumps(records[-1], sort_keys=True), flush=True)
    output = {
        "source": f"{BASE}/contests",
        "cutoff": args.cutoff,
        "selection": "completed dated contests marked Public with nonzero public submissions",
        "contests": records,
        "contest_count": len(records),
        "submission_total": sum(row["expected_total"] for row in records),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"contest_count": len(records), "submission_total": output["submission_total"]}, sort_keys=True))


if __name__ == "__main__":
    main()

