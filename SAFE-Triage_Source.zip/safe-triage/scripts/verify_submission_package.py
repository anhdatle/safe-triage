#!/usr/bin/env python3
"""Verify artifact from a fresh extraction, including standalone TeX build."""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    archive = ROOT / "output/pdf/SAFE-Triage_Full_Submission_Package.zip"
    with tempfile.TemporaryDirectory(prefix="fc27-reproduction-") as temp:
        dest = Path(temp)
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                assert not Path(name).is_absolute() and ".." not in Path(name).parts
            z.extractall(dest)
        hashes = json.loads((dest / "SHA256SUMS.json").read_text())
        for name, expected in hashes.items():
            assert hashlib.sha256((dest / name).read_bytes()).hexdigest() == expected
        command = [sys.executable, "analysis/submission_analysis.py", "--ledger", "data/decisions.jsonl", "--diagnostics", "data/diagnostics.jsonl", "--output", "recomputed.json"]
        subprocess.run(command, cwd=dest, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert json.loads((dest / "recomputed.json").read_text()) == json.loads((dest / "results/uncertainty.json").read_text())
        for name in ("diagnostic_counts.json", "paired_counts.json"):
            assert json.loads((dest / name).read_text()) == json.loads((dest / "results" / name).read_text())
        subprocess.run(["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error", "main.tex"], cwd=dest / "author_paper", check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        log = (dest / "author_paper/main.log").read_text()
        assert "Overfull" not in log
        assert "There were undefined references" not in log
        assert "Citation `" not in log or "undefined" not in log
        assert "Reference `" not in log or "undefined" not in log
        print("PASS: archive hashes, numerical replay, auxiliary/paired counts, standalone LNCS compilation, no overfull boxes or undefined references.")


if __name__ == "__main__":
    main()
