#!/usr/bin/env python3
"""Verify release hashes and replay the included derived observations offline."""
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    manifest = json.loads((ROOT / "SHA256SUMS.json").read_text())
    for name, expected in manifest.items():
        path = ROOT / name
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"Integrity check failed: {name}")
    with tempfile.TemporaryDirectory(prefix="safe-triage-replay-") as tmp:
        out = Path(tmp) / "uncertainty.json"
        subprocess.run([
            sys.executable, str(ROOT / "scripts/submission_analysis.py"),
            "--ledger", str(ROOT / "artifacts/submission/decisions.jsonl"),
            "--diagnostics", str(ROOT / "artifacts/submission/diagnostics.jsonl"),
            "--output", str(out),
        ], check=True, stdout=subprocess.DEVNULL)
        for name in ("uncertainty.json", "diagnostic_counts.json", "paired_counts.json"):
            if json.loads((Path(tmp) / name).read_text()) != json.loads(
                (ROOT / "artifacts/submission" / name).read_text()
            ):
                raise ValueError(f"Numerical replay differs: {name}")
    print(f"PASS: {len(manifest)} file hashes and all three numerical replay outputs.")


if __name__ == "__main__":
    main()
