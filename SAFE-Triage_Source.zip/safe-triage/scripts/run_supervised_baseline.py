#!/usr/bin/env python3
"""Train public-report triage controls and evaluate project/platform transfer."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion


def read(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def label(row: dict) -> int:
    return int(row["outcome"] == "ESCALATE")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--code4rena", type=Path, required=True)
    parser.add_argument("--sherlock", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    code4rena = read(args.code4rena)
    sherlock = read(args.sherlock)
    train = [row for row in code4rena if row["split"] == "train"]
    evaluations = {
        "code4rena_calibration": [row for row in code4rena if row["split"] == "calibration"],
        "code4rena_test_contaminated_by_pilot": [row for row in code4rena if row["split"] == "test"],
        "sherlock_external_locked": sherlock,
    }
    features = FeatureUnion([
        ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=60000, sublinear_tf=True)),
        ("char", TfidfVectorizer(analyzer="char", ngram_range=(3, 5), min_df=2, max_features=60000, sublinear_tf=True)),
    ])
    x_train = features.fit_transform([row["model_input"] for row in train])
    model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=20260905)
    model.fit(x_train, [label(row) for row in train])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for evaluation, rows in evaluations.items():
            matrix = features.transform([row["model_input"] for row in rows])
            probabilities = model.predict_proba(matrix)[:, 1]
            for row, probability in zip(rows, probabilities):
                result = {
                    "case_id": f"{evaluation}::{row['record_id']}",
                    "evaluation": evaluation,
                    "platform": "Sherlock" if evaluation.startswith("sherlock") else "Code4rena",
                    "project_id": row["repository"],
                    "record_id": row["record_id"],
                    "gold_route": "PRIORITY_REVIEW" if label(row) else "STANDARD_REVIEW",
                    "prediction": "PRIORITY_REVIEW" if probability >= 0.5 else "STANDARD_REVIEW",
                    "probability_priority": float(probability),
                    "confidence": float(max(probability, 1 - probability)),
                }
                handle.write(json.dumps(result, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
