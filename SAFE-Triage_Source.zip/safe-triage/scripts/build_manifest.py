#!/usr/bin/env python3
"""Build a provenance-preserving manifest from public Immunefi reports."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
import urllib.parse
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


SEVERITIES = ("Critical", "High", "Medium", "Low", "Insight")
DATE_RE = re.compile(
    r"Submitted on\s+([A-Z][a-z]{2}\s+\d{1,2}(?:st|nd|rd|th)?\s+\d{4})",
    re.IGNORECASE,
)
ID_RE = re.compile(r"(?:Report ID:(?:\*\*)?\s*|#)(?:#)?(\d{4,})", re.IGNORECASE)
TYPE_RE = re.compile(r"Report Type:(?:\*\*)?\s*([^\n\r]+)", re.IGNORECASE)
SEVERITY_RE = re.compile(
    r"Report severity:(?:\*\*)?\s*(Critical|High|Medium|Low|Insight)", re.IGNORECASE
)
TITLE_SEVERITY_RE = re.compile(
    r"(?:SC|Smart Contract)\s*[-–:]\s*(Critical|High|Medium|Low|Insight)",
    re.IGNORECASE,
)
TARGET_RE = re.compile(r"Target:(?:\*\*)?\s*(?:<)?(https?://[^\s)>]+)", re.IGNORECASE)
URL_RE = re.compile(r"https?://[^\s)>]+", re.IGNORECASE)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalise_severity(value: str | None) -> str:
    if not value:
        return ""
    lookup = {item.lower(): item for item in SEVERITIES}
    return lookup.get(value.strip().lower(), "")


def parse_date(text: str) -> str:
    match = DATE_RE.search(text)
    if not match:
        return ""
    value = re.sub(r"(\d{1,2})(st|nd|rd|th)", r"\1", match.group(1))
    try:
        return datetime.strptime(value, "%b %d %Y").date().isoformat()
    except ValueError:
        return ""


def first_heading(text: str, fallback: str) -> str:
    for line in text.splitlines():
        if line.startswith("#"):
            return re.sub(r"^#+\s*", "", line).replace("\\[", "[").replace("\\]", "]")
    return fallback


def parse_report(path: Path, root: Path) -> dict[str, object]:
    text = path.read_text(encoding="utf-8", errors="replace")
    severity_match = SEVERITY_RE.search(text) or TITLE_SEVERITY_RE.search(text)
    report_id_match = ID_RE.search(text)
    target_match = TARGET_RE.search(text)
    report_type_match = TYPE_RE.search(text)
    title = first_heading(text, path.stem)
    report_id = report_id_match.group(1) if report_id_match else ""
    if not report_id:
        filename_id = re.search(r"(?<!\d)(\d{4,})(?!\d)", path.name)
        report_id = filename_id.group(1) if filename_id else ""
    report_type = report_type_match.group(1).strip(" *") if report_type_match else ""
    if not report_type and re.search(r"\b(?:SC|Smart Contract)\b", title, re.IGNORECASE):
        report_type = "Smart Contract"
    code_blocks = len(re.findall(r"```[^\n]*\n", text))
    poc_heading = bool(re.search(r"^#{1,4}\s+.*Proof of Concept", text, re.MULTILINE | re.IGNORECASE))
    target_url = target_match.group(1).rstrip(".,") if target_match else ""
    parsed = urllib.parse.urlparse(target_url.replace("\\_", "_"))
    parts = [part for part in parsed.path.split("/") if part]
    is_github = parsed.netloc.lower() == "github.com" and len(parts) >= 2
    target_ref = parts[3] if is_github and len(parts) >= 4 and parts[2] in {"blob", "tree"} else ""
    target_path = "/".join(parts[4:]) if target_ref else ""
    repository_slug = "/".join(parts[:2]) if is_github else ""
    pinned_evidence_url = ""
    pinned_evidence_ref = ""
    pinned_evidence_path = ""
    for candidate in URL_RE.findall(text.replace("\\_", "_")):
        candidate = candidate.rstrip(".,;`")
        if not candidate.lower().startswith(("https://github.com/", "http://github.com/")):
            continue
        candidate_parts = [part for part in urllib.parse.urlparse(candidate).path.split("/") if part]
        if len(candidate_parts) < 5 or candidate_parts[2] not in {"blob", "tree"}:
            continue
        if "/".join(candidate_parts[:2]).lower() != repository_slug.lower():
            continue
        if not re.fullmatch(r"[0-9a-fA-F]{40}", candidate_parts[3]):
            continue
        pinned_evidence_url = candidate
        pinned_evidence_ref = candidate_parts[3]
        pinned_evidence_path = "/".join(candidate_parts[4:]).split("#", 1)[0]
        break
    return {
        "report_id": report_id,
        "project_id": path.parent.name,
        "relative_path": path.relative_to(root).as_posix(),
        "title": title,
        "submitted_date": parse_date(text),
        "report_type": report_type,
        "official_severity": normalise_severity(severity_match.group(1) if severity_match else None),
        "target_url": target_url,
        "target_kind": "github" if is_github else "other" if target_url else "missing",
        "repository_slug": repository_slug,
        "target_ref": target_ref,
        "target_path": target_path,
        "target_ref_pinned": int(bool(re.fullmatch(r"[0-9a-fA-F]{40}", target_ref))),
        "pinned_evidence_url": pinned_evidence_url,
        "pinned_evidence_ref": pinned_evidence_ref,
        "pinned_evidence_path": pinned_evidence_path,
        "poc_heading": int(poc_heading),
        "code_block_count": code_blocks,
        "report_chars": len(text),
        "source_sha256": sha256(path),
    }


def assign_project_splits(project_rows: list[dict[str, object]]) -> None:
    dated = sorted(
        (
            row for row in project_rows
            if row["representative_date"] and int(row.get("eligible_report_count", 1)) > 0
        ),
        key=lambda row: (str(row["representative_date"]), str(row["project_id"])),
    )
    n = len(dated)
    dev_end = int(n * 0.60)
    cal_end = int(n * 0.80)
    for index, row in enumerate(dated):
        row["split"] = "development" if index < dev_end else "calibration" if index < cal_end else "historical_test"
    for row in project_rows:
        if int(row.get("eligible_report_count", 0)) == 0:
            row["split"] = "ineligible_project"
        elif not row["representative_date"]:
            row["split"] = "undated_excluded"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)

    paths = sorted(
        path for path in source.rglob("*.md")
        if path.name.lower() not in {"readme.md", "summary.md"} and ".git" not in path.parts
    )
    reports = [parse_report(path, source) for path in paths]

    by_project: dict[str, list[dict[str, object]]] = defaultdict(list)
    for report in reports:
        by_project[str(report["project_id"])].append(report)

    projects: list[dict[str, object]] = []
    for project_id, rows in sorted(by_project.items()):
        dates = sorted(str(row["submitted_date"]) for row in rows if row["submitted_date"])
        representative = dates[len(dates) // 2] if dates else ""
        smart_contract = sum("smart contract" in str(row["report_type"]).lower() for row in rows)
        eligible = sum(
            bool(row["official_severity"])
            and "smart contract" in str(row["report_type"]).lower()
            and row["target_kind"] == "github"
            and bool(row["pinned_evidence_url"])
            for row in rows
        )
        projects.append({
            "project_id": project_id,
            "representative_date": representative,
            "report_count": len(rows),
            "smart_contract_count": smart_contract,
            "target_link_count": sum(bool(row["target_url"]) for row in rows),
            "poc_heading_count": sum(int(row["poc_heading"]) for row in rows),
            "eligible_report_count": eligible,
            "split": "",
        })
    assign_project_splits(projects)
    split_by_project = {str(row["project_id"]): str(row["split"]) for row in projects}
    for report in reports:
        report["split"] = split_by_project[str(report["project_id"])]
        report["eligible"] = int(
            bool(report["official_severity"])
            and "smart contract" in str(report["report_type"]).lower()
            and report["target_kind"] == "github"
            and bool(report["pinned_evidence_url"])
            and report["split"] != "undated_excluded"
        )

    report_fields = list(reports[0].keys()) if reports else []
    project_fields = list(projects[0].keys()) if projects else []
    with (output / "reports.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=report_fields)
        writer.writeheader()
        writer.writerows(reports)
    with (output / "projects.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=project_fields)
        writer.writeheader()
        writer.writerows(projects)

    revision = subprocess.check_output(
        ["git", "-C", str(source), "rev-parse", "HEAD"], text=True
    ).strip()
    summary = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": "https://github.com/immunefi-team/Past-Audit-Competitions",
        "source_revision": revision,
        "files_parsed": len(reports),
        "projects": len(projects),
        "eligible_reports": sum(int(row["eligible"]) for row in reports),
        "severity_counts_all": Counter(str(row["official_severity"]) or "missing" for row in reports),
        "split_counts_eligible": Counter(str(row["split"]) for row in reports if row["eligible"]),
        "licence_status": "No repository licence detected; do not redistribute raw reports without review.",
    }
    (output / "manifest_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
