# SAFE-Triage

Research code for **SAFE-Triage: Evidence-gated routing of smart-contract
vulnerability reports**.

SAFE-Triage combines a supervised route proposal, a code-conditioned LLM,
and checks on agreement, output validity, cited-source identity, quoted text,
and recognized instruction attacks. Failed checks leave routing to a human.
Both automatic routes lead to human review; neither rejects a report.

## Reproduce the published numerical analysis

This path uses only Python 3.11+ and the included derived records. It needs no
model server, credentials, network access, or third-party Python packages.

```bash
python3 scripts/verify_public_release.py
```

The verifier checks file hashes, recomputes the project/code-cluster bootstrap
analysis, and compares all three generated JSON outputs with the saved outputs.
It writes temporary outputs outside the repository. The seed is 20260905, with
5,000 bootstrap draws per grouping. This is numerical replay, not fresh LLM inference.

## Code and results

- `scripts/`: data preparation, local LLM inference, supervised and published-method
  comparators, gate evaluation, uncertainty estimates, attack experiments, monitoring,
  and historical manuscript utilities.
- `tests/`: 44 unit tests covering parsing, gates, selection, pairing, and monitoring.
- `artifacts/submission/`: pseudonymous decisions and derived diagnostics.
- Other allowlisted `artifacts/` directories: aggregate results and plotting inputs.
- `author_paper/scripts/` and `author_paper/tables/`: figure/table generation code and
  numerical inputs; the private manuscript draft is not included.
- `docs/`: prompts, schemas, baseline protocol, and source-data requirements.

There are six historical evaluation datasets from four platforms: Code4rena
calibration and later projects, Sherlock, two CodeHawks cohorts, and Immunefi.
The five-model common benchmark contains 978 code-resolved reports; the full
six-dataset evidence base contains 1,307. Models are Phi-4-mini 3.8B, Llama 3.1 8B,
Qwen 3 8B, Qwen 3 32B, and Llama 3.3 70B. Mistral/StruQ is a separate system comparison.

## Run tests and regenerate tables

The pinned dependencies record the tested local environment. Availability on a
different Python version or operating system may differ.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pip install -r requirements-m1.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python author_paper/scripts/generate_tables.py
.venv/bin/python author_paper/scripts/generate_containment_visualization.py
```

Regenerating tables/figures may modify derived files. Run the hash verifier on a
fresh checkout before regeneration. The transformer/StruQ tests additionally need
`requirements-m1.txt`; acquisition tools need `requirements-acquisition.txt`.

## Fresh inference

Fresh inference requires separately acquired reports and cited code, plus local
model checkpoints. Start with `docs/DATA_ACCESS.md` and the argument help for the
relevant script. `Makefile` preserves the original workflow and expected input paths.
Its manuscript-packaging targets require the separately distributed manuscript.

`scripts/run_llm.py` uses Ollama at `127.0.0.1:11434`. The evaluated configuration
used temperature zero, seed 20260905, an 8,192-token context and 220-token output
limit. A 70B model has substantial memory requirements. Transformer comparators
use PyTorch/Transformers and separate checkpoints. Review model code before using
any loader configured with `trust_remote_code=True`.

The prospective-lock scripts are utilities for subsequent data collection;
their presence does not mean the paper reports a prospective study. Historical
manuscript utilities are included for completeness, not as prerequisites for replay.

## Interpretation

The primary benefit is reduced automatic action on constructed provenance failures
and direct-marker attacks, measured against lost correct clean routes. These results
do not establish improved clean classification, resistance to every injection, or
production certification. Public adjudications provide routing labels. Attack labels
describe construction and provenance, not expert-verified semantic entailment.

## Rights

Third-party report bodies, contract code, model weights, raw model prose, private
files, and credentials are not redistributed. See `THIRD_PARTY_NOTICE.md`.
No open-source license is assigned in this initial release; public visibility alone
does not grant an unrestricted reuse license.
