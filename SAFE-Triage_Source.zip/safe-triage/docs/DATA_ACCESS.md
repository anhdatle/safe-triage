# Source inputs for fresh inference

The numerical replay does not require these inputs. For fresh inference, obtain
the public historical reports and their cited code from the original platforms:

- Code4rena: https://github.com/code-423n4 and https://code4rena.com/reports
- Sherlock: https://github.com/sherlock-audit and https://docs.sherlock.xyz/audits/judging/guidelines
- CodeHawks: https://codehawks.cyfrin.io/contests
- Immunefi: https://github.com/immunefi-team/Past-Audit-Competitions

The original Code4rena/Sherlock experiments consume inherited processed JSONL files
named `external_data/code4rena_processed.jsonl` and
`external_data/sherlock_processed.jsonl`. Their fields and transformations are
specified by `scripts/prepare_cases.py` and `scripts/run_supervised_baseline.py`.
An upstream raw-to-processed exporter for these inherited inputs is not included
in this project. Accordingly, this release supports exact numerical replay of
the included ledger, but does not promise a one-command reconstruction of the
entire historical input corpus from today's websites.

For CodeHawks, use `discover_codehawks_contests.py`, `acquire_codehawks.py`,
`acquire_codehawks_reports.py`, and the corresponding case-preparation scripts.
For Immunefi, supply a local copy of the public report repository to
`build_manifest.py --source ... --output artifacts/manifest`, then use
`prepare_immunefi_cases.py`. Run each script with `--help` for required paths.
Historical snapshots, model revisions, and processed-source hashes matter:
later website content or checkpoint revisions need not reproduce the same cases.

Reports are untrusted input. Do not execute payloads in a report or expose a
local inference endpoint publicly. Only process reports that are already public.
The release contains scripts for retrieving cited sources, not permission to
redistribute source content or access private systems.
