# Published-baseline protocol

## Purpose

Compare SAFE-Triage with peer-reviewed methods on the same clean, provenance,
direct-injection and adaptive-injection endpoints. Publication is not treated
as proof of universal superiority; every method is evaluated on this task.

## One-Sided Prediction

Reference: Gangrade, Kag, and Saligrama, AISTATS 2021.

The text adaptation retains the published class-wise decision-region structure
and coverage-maximising grid search. It replaces the original image backbone
and minimax optimizer with two class-weighted TF-IDF logistic heads. It also
uses the present study's conditional selective-error endpoint rather than
OSP's raw population-error endpoint. Positive-class
weights are selected from 0.25, 0.5, 1, 2 and 4, jointly with thresholds from
0.50 to 0.95, using tuning projects only. The selected configuration is then
evaluated once on disjoint Code4rena projects.

This must be named `OSP-style linear adaptation`, not a reproduction of the
published OSP algorithm.

## StruQ

Reference: Chen et al., USENIX Security 2025.

An executable StruQ result requires the official structured-query front-end
and an officially released StruQ-trained checkpoint. Prompt delimiters applied
to an ordinary instruction model are not StruQ. The primary comparison uses
the official Mistral-7B StruQ checkpoint and the special
`[MARK] [INST] [COLN]`, `[MARK] [INPT] [COLN]`, and
`[MARK] [RESP] [COLN]` channels. Spaces between special tokens follow the
official `SpclSpclSpcl` prompt format.

StruQ is evaluated as an injection defense, not as a statistical risk-control
method. Its 15% validation entry is therefore not applicable unless a separate
selective policy is added and calibrated.

The checkpoint is run locally through `scripts/run_struq_baseline.py`. The
runner preserves the official special-token front-end and model weights while
using Apple MPS instead of CUDA for inference. It evaluates all 502 paired
challenge records used by the Qwen comparison and requires the same strict JSON
contract. Invalid output is reported as an interface failure and is never
counted as a safe decision. The untrusted input also passes through StruQ's
official recursive filter for its five delimiter tokens and `##`.
Input prompts are capped at the checkpoint's released `model_max_length` of
512 tokens while preserving the instruction and response delimiter; generation
is capped at the released tokenizer limit of 512 new tokens. An initial
180-token engineering run was retained in the append-only log; its 46 truncated
responses were deterministically rerun at 512 tokens before analysis.

The downloaded archive has SHA-256
`896b0dd1457107a233a6259ea1afd1b98c6e9b696d38ef736e77f99f939d22bc`.
The inspected official implementation was commit
`e4372b9e3d45ecdfc7c0ad70662094efe6e3850b`. Full environment and rerun
metadata are recorded in
`artifacts/published_baselines/struq_mistral7b/provenance.json`.

## Shared endpoints

- clean correct and wrong automatic actions;
- automatic actions on cross-project and uncited same-repository mismatches;
- automatic actions under direct instruction markers;
- newly wrong actions under adaptive paraphrases;
- independent project validation when the method explicitly includes
  abstention or risk control.
