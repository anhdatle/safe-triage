# SAFE-Triage data schema

## Project table

- `project_id`
- `platform`
- `competition_name`
- `results_url`
- `repository_url`
- `target_commit`
- `start_date`
- `end_date`
- `results_publication_date`
- `acquired_at_utc`
- `source_revision`
- `licence_status`
- `split`

## Report table

- `report_id`
- `project_id`
- `report_url`
- `title`
- `report_text_path`
- `report_sha256`
- `report_chars_full`
- `report_chars_model_input` (maximum 6,000 characters for the current
  retrospective comparison; full text remains hash-addressable)
- `official_severity`
- `affected_component`
- `affected_function`
- `code_reference_text`
- `poc_available`
- `source_available`
- `exclusion_reason`
- `source_sha256`

## Challenge table

- `case_id`
- `report_id`
- `challenge_type`
- `challenge_version`
- `generation_seed`
- `expected_evidence_status`
- `transformation_record`

## Prediction table

- `case_id`
- `system_id`
- `model_id`
- `prompt_hash`
- `adapter_id`
- `raw_response_hash`
- `parse_valid`
- `predicted_severity`
- `predicted_component`
- `predicted_function`
- `evidence_locations`
- `evidence_resolvable`
- `consistency_pass`
- `integrity_pass`
- `risk_score`
- `action`
- `defer_reason`
- `latency_ms`
- `input_tokens`
- `output_tokens`

Raw reports, repositories, prompts, and model responses remain outside any
anonymous prediction-only release until licence and disclosure checks pass.
