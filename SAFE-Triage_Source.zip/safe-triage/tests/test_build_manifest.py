from pathlib import Path
import importlib.util
import tempfile
import unittest


SCRIPT = Path(__file__).parents[1] / "scripts" / "build_manifest.py"
SPEC = importlib.util.spec_from_file_location("build_manifest", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class BuildManifestTests(unittest.TestCase):
    def test_parse_modern_report(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = root / "example"
            project.mkdir()
            report = project / "12345-sc-high-example.md"
            report.write_text(
                "# #12345 [SC-High] Example\n\n"
                "**Submitted on Dec 1st 2024 at 16:37 UTC**\n"
                "* **Report ID:** #12345\n"
                "* **Report Type:** Smart Contract\n"
                "* **Report severity:** High\n"
                "* **Target:** https://github.com/org/repo/blob/abc/A.sol\n"
                "Reference: https://github.com/org/repo/blob/"
                "0123456789abcdef0123456789abcdef01234567/A.sol#L1\n"
                "## Proof of Concept\n```solidity\nfunction x() {}\n```\n",
                encoding="utf-8",
            )
            row = MODULE.parse_report(report, root)
            self.assertEqual(row["report_id"], "12345")
            self.assertEqual(row["official_severity"], "High")
            self.assertEqual(row["submitted_date"], "2024-12-01")
            self.assertEqual(row["poc_heading"], 1)
            self.assertTrue(row["target_url"].endswith("A.sol"))
            self.assertEqual(row["repository_slug"], "org/repo")
            self.assertEqual(row["target_ref"], "abc")
            self.assertEqual(row["pinned_evidence_ref"], "0123456789abcdef0123456789abcdef01234567")

    def test_project_split_is_disjoint(self):
        rows = [
            {
                "project_id": f"p{i}",
                "representative_date": f"2024-{i + 1:02d}-01",
                "eligible_report_count": 1,
                "split": "",
            }
            for i in range(10)
        ]
        MODULE.assign_project_splits(rows)
        self.assertEqual([row["split"] for row in rows].count("development"), 6)
        self.assertEqual([row["split"] for row in rows].count("calibration"), 2)
        self.assertEqual([row["split"] for row in rows].count("historical_test"), 2)


if __name__ == "__main__":
    unittest.main()
