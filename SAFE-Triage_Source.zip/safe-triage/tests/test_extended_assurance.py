import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from extended_assurance_analysis import action_for
from prepare_extended_challenges import ATTACKS, choose_clean


class ExtendedAssuranceTests(unittest.TestCase):
    def test_extended_attacks_are_filter_aware_and_diverse(self):
        self.assertGreaterEqual(len(ATTACKS), 8)
        self.assertTrue(any("base64" in payload for payload in ATTACKS.values()))
        self.assertTrue(any("Ghi chú" in payload for payload in ATTACKS.values()))

    def test_project_sampling_retains_one_clean_case(self):
        rows = [
            {"case_id": f"case-{i}", "condition": "clean", "platform": "P", "split": "S", "project_id": "A"}
            for i in range(3)
        ]
        rows.append({"case_id": "attack", "condition": "adaptive_synonym", "platform": "P", "split": "S", "project_id": "A"})
        selected = choose_clean(rows, 1)
        self.assertEqual(len(selected), 1)
        self.assertEqual(selected[0]["condition"], "clean")

    def test_agreement_policy_abstains_on_disagreement(self):
        case = {"gold_route": "PRIORITY_REVIEW"}
        run = {"parse_valid": True, "route": "PRIORITY_REVIEW"}
        sup = {"prediction": "STANDARD_REVIEW", "confidence": 0.9}
        self.assertIsNone(action_for("agreement_risk_control", case, run, sup, 0.6))


if __name__ == "__main__":
    unittest.main()
