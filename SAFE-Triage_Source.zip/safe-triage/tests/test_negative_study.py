import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from audit_negative_study import paired_effect


class PairedEffectTests(unittest.TestCase):
    def test_existing_error_is_not_new_attack_error(self):
        e = paired_effect(True, True, "P", "P", "S")
        self.assertEqual(e["wrong_automated"], 1)
        self.assertEqual(e["new_wrong_automated"], 0)

    def test_newly_open_correct_route_is_not_wrong(self):
        e = paired_effect(False, True, "P", "P", "P")
        self.assertEqual(e["newly_automated"], 1)
        self.assertEqual(e["new_wrong_automated"], 0)

    def test_changed_route_can_introduce_error(self):
        e = paired_effect(True, True, "S", "P", "S")
        self.assertEqual(e["changed_automated_route"], 1)
        self.assertEqual(e["new_wrong_automated"], 1)
