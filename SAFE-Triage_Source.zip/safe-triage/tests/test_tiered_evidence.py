import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from prepare_codehawks_tiered_cases import linked_cluster, parse_blob, repo_slug


class TieredEvidenceTests(unittest.TestCase):
    def test_blob_parser_keeps_ref_path_and_lines(self):
        row = parse_blob("https://github.com/Org/Repo/blob/main/src/A.sol#L10-L12")
        self.assertEqual(row["repository_slug"], "org/repo")
        self.assertEqual(row["ref"], "main")
        self.assertEqual(row["source_path"], "src/A.sol")
        self.assertEqual((row["line_start"], row["line_end"]), (10, 12))

    def test_repo_slug_normalises_git_suffix(self):
        self.assertEqual(repo_slug("https://github.com/Org/Repo.git"), "org/repo")

    def test_blob_without_anchor_is_allowed_for_tier_b(self):
        row = parse_blob("https://github.com/Org/Repo/blob/main/src/A.sol")
        self.assertIsNone(row["line_start"])
        self.assertIsNone(row["line_end"])

    def test_repeated_protocol_contests_share_cluster(self):
        self.assertEqual(linked_cluster("2024-05-Sablier"), linked_cluster("2024-10-sablier"))


if __name__ == "__main__":
    unittest.main()
