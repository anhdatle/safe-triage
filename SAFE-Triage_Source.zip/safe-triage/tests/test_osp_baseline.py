import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from run_osp_baseline import metrics, route_scores, select_configuration


class OSPBaselineTests(unittest.TestCase):
    def test_osp_requires_argmax_and_threshold(self):
        scores = np.asarray([[0.8, 0.7], [0.4, 0.6], [0.3, 0.2]])
        actions, confidence = route_scores(scores, 0.65)
        self.assertEqual(actions.tolist(), [0, -1, -1])
        self.assertEqual(confidence.tolist(), [0.8, 0.6, 0.3])

    def test_selection_maximises_coverage_under_target(self):
        scores = {1.0: np.asarray([[0.9, 0.1], [0.2, 0.8], [0.6, 0.4]])}
        gold = np.asarray([0, 1, 1])
        choice = select_configuration(scores, gold, np.asarray([True, True, True]), 0.0)
        self.assertIsNotNone(choice)
        self.assertEqual(choice["actions"], 2)
        self.assertEqual(metrics(*[route_scores(scores[1.0], choice["threshold"])[0], gold])["errors"], 0)


if __name__ == "__main__":
    unittest.main()
