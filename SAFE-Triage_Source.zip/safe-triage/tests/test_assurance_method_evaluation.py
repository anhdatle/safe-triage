import hashlib
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from evaluate_assurance_methods import apply_threshold, calibrate, cp_upper, point_metrics


class AssuranceMethodEvaluationTests(unittest.TestCase):
    def test_exact_upper_bound_decreases_with_clean_evidence(self):
        self.assertGreater(cp_upper(0, 10), cp_upper(0, 100))

    def test_threshold_abstains_below_cutoff(self):
        rows = [
            {"route": "PRIORITY_REVIEW", "gold": "PRIORITY_REVIEW", "score": 0.8, "eligible": True},
            {"route": "STANDARD_REVIEW", "gold": "PRIORITY_REVIEW", "score": 0.6, "eligible": True},
            {"route": "STANDARD_REVIEW", "gold": "STANDARD_REVIEW", "score": 0.9, "eligible": False},
        ]
        selected = apply_threshold(rows, 0.7)
        metric = point_metrics(selected)
        self.assertEqual(metric["actions"], 1)
        self.assertEqual(metric["errors"], 0)
        self.assertAlmostEqual(metric["coverage"], 1 / 3)

    def test_no_feasible_threshold_means_no_action(self):
        rows = [{"route": "PRIORITY_REVIEW", "gold": "PRIORITY_REVIEW", "score": 1.0, "eligible": True}]
        self.assertEqual(point_metrics(apply_threshold(rows, None))["actions"], 0)

    def test_tuning_success_does_not_override_failed_project_validation(self):
        projects = [f"project-{i}" for i in range(30)]
        tuning = {p for p in projects if int(hashlib.sha256(p.encode()).hexdigest(), 16) % 3 == 0}
        self.assertGreaterEqual(len(tuning), 5)
        rows = []
        for project in projects:
            for i in range(10):
                correct = project in tuning
                rows.append({
                    "project": project,
                    "route": "PRIORITY_REVIEW",
                    "gold": "PRIORITY_REVIEW" if correct else "STANDARD_REVIEW",
                    "score": 0.9,
                    "eligible": True,
                })
        result = calibrate(rows, target=0.15, alpha=0.05, draws=100)
        self.assertEqual(result["status"], "failed_independent_project_validation")
        self.assertFalse(result["selected"]["validated"])


if __name__ == "__main__":
    unittest.main()
