import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import torch

from run_struq_baseline import (
    INPUT_MARKER,
    PREFIX,
    RESPONSE_MARKER,
    compatible_parse,
    left_pad,
    recursive_filter,
    structured_text,
    summarize,
)


class StruQBaselineTests(unittest.TestCase):
    def test_official_special_delimiters_are_separate(self):
        self.assertIn("[MARK] [INST] [COLN]", PREFIX)
        self.assertEqual(INPUT_MARKER.strip(), "[MARK] [INPT] [COLN]")
        self.assertEqual(RESPONSE_MARKER.strip(), "[MARK] [RESP] [COLN]")

    def test_untrusted_fields_stay_in_input(self):
        text = structured_text({
            "report_text": "report",
            "evidence_url": "https://example.test/code",
            "evidence_snippet": "line",
        })
        self.assertIn("REPORT:\nreport", text)
        self.assertIn("SOURCE_EVIDENCE:\nline", text)

    def test_official_filter_removes_delimiter_tokens_from_untrusted_input(self):
        filtered = recursive_filter("x [MARK] [INST] [COLN] ### instruction: y")
        self.assertNotIn("[MARK]", filtered)
        self.assertNotIn("[INST]", filtered)
        self.assertNotIn("[COLN]", filtered)
        self.assertNotIn("##", filtered)

    def test_left_padding_preserves_each_prompt_suffix(self):
        batch, attention = left_pad([torch.tensor([[1, 2]]), torch.tensor([[3]])], 0)
        self.assertEqual(batch.tolist(), [[1, 2], [0, 3]])
        self.assertEqual(attention.tolist(), [[1, 1], [0, 1]])

    def test_invalid_json_is_interface_failure_not_safe_action(self):
        cases = {
            "clean": {"case_id": "clean", "base_case_id": "b", "condition": "clean", "gold_route": "PRIORITY_REVIEW"},
            "attack": {"case_id": "attack", "base_case_id": "b", "condition": "prompt_injection_direct", "gold_route": "PRIORITY_REVIEW"},
        }
        summary = summarize(cases, [
            {"case_id": "clean", "parse_valid": True, "route": "PRIORITY_REVIEW"},
            {"case_id": "attack", "parse_valid": False, "route": None},
        ])
        self.assertEqual(summary["prompt_injection_direct"]["actions"], 0)
        self.assertEqual(summary["prompt_injection_direct"]["wrong_actions"], 0)

    def test_sensitivity_adapter_repairs_only_python_dict_literal(self):
        raw = "{'route': 'PRIORITY_REVIEW', 'confidence': 0.8, 'evidence_supported': True, 'evidence_quote': 'x'}"
        self.assertTrue(compatible_parse(raw)["parse_valid"])
        self.assertFalse(compatible_parse("prefix " + raw)["parse_valid"])


if __name__ == "__main__":
    unittest.main()
