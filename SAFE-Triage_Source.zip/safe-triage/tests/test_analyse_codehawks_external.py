import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from analyse_codehawks_external import bootstrap_difference, integrity_pass


class CodeHawksAnalysisTests(unittest.TestCase):
    def test_integrity_requires_contest_repository_identity(self):
        case = {
            "evidence_url": "https://github.com/org/repo/blob/" + "a" * 40 + "/x.sol",
            "contest_repository_url": "https://github.com/org/repo",
            "repository_slug": "org/repo",
            "commit": "a" * 40,
            "report_text": "ordinary report",
        }
        self.assertTrue(integrity_pass(case))
        self.assertFalse(integrity_pass({**case, "repository_slug": "other/repo"}))

    def test_bootstrap_retains_zero_action_clusters(self):
        rows = [
            {
                "hybrid": {"automated": 0, "errors": 0},
                "supervised_matched": {"automated": 0, "errors": 0},
            },
            {
                "hybrid": {"automated": 2, "errors": 1},
                "supervised_matched": {"automated": 2, "errors": 0},
            },
        ]
        result = bootstrap_difference(rows, draws=100)
        self.assertEqual(result["clusters"], 2)
        self.assertGreater(result["valid_draws"], 0)


if __name__ == "__main__":
    unittest.main()
