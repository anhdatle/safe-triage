import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from submission_analysis import compare, clustered
from export_submission_ledger import components


class SubmissionTests(unittest.TestCase):
    def test_transitive_grouping(self):
        c = components({"a": {"r1"}, "b": {"r1", "r2"}, "c": {"r2"}, "d": {"r3"}})
        self.assertEqual(c["a"], c["c"])
        self.assertNotEqual(c["a"], c["d"])

    def test_empty_automation_is_undefined(self):
        self.assertIsNone(compare([{"hybrid": None}]))

    def test_matched_count_and_paired_zero_difference(self):
        rows = [{"id": str(i), "project": str(i), "hybrid": "P", "supervised": "P", "gold": "S", "score": .9} for i in range(4)]
        self.assertEqual(compare(rows), (1, 1, 0))
        result = clustered(rows, "project", draws=100)
        self.assertEqual(result["difference_interval"], [0, 0])
