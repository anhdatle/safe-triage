import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from prepare_prospective_blind import blind_row


class ProspectiveBlindTests(unittest.TestCase):
    def test_outcome_fields_are_removed(self):
        row = {
            "case_id": "x",
            "report_text": "body",
            "gold_route": "PRIORITY_REVIEW",
            "submitted_severity": "high",
            "final_validity": "valid",
            "tags_audit_only": "tag",
        }
        self.assertEqual(blind_row(row), {"case_id": "x", "report_text": "body"})


if __name__ == "__main__":
    unittest.main()
