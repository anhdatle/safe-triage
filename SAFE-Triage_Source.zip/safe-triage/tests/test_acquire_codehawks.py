import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from acquire_codehawks import gold_route, parse_index_page
from acquire_codehawks_reports import parse_report_body, select_outcome_blind
from discover_codehawks_contests import contest_cards


class CodeHawksAcquisitionTests(unittest.TestCase):
    def test_contest_discovery_extracts_access_and_date(self):
        html = b'''<section><div><div><div><div><a href="/c/2025-02-public">Contest</a> Public</div></div></div></div></section>
        <section><div><div><div><div><a href="/c/2025-02-private">Contest</a> Private</div></div></div></div></section>'''
        rows = {row["contest_id"]: row for row in contest_cards(html)}
        self.assertEqual(rows["2025-02-public"]["access"], "Public")
        self.assertEqual(rows["2025-02-private"]["access"], "Private")
        self.assertEqual(rows["2025-02-public"]["year_month"], "2025-02")

    def test_route_mapping_requires_valid_medium_or_higher(self):
        self.assertEqual(gold_route("valid", "high"), "PRIORITY_REVIEW")
        self.assertEqual(gold_route("valid", "medium"), "PRIORITY_REVIEW")
        self.assertEqual(gold_route("valid", "low"), "STANDARD_REVIEW")
        self.assertEqual(gold_route("invalid", "high"), "STANDARD_REVIEW")
        self.assertIsNone(gold_route("unresolved", "medium"))

    def test_index_parser_drops_author_and_keeps_audit_fields_separate(self):
        html = b'''<html><body><script>githubUrl:"https://github.com/x/repo"</script>
        <div>1 / 1</div><table><tbody><tr>
        <td><a href="/c/demo/s/7">#7 Finding title</a></td>
        <td>Medium</td><td>Valid</td><td>finding-tag</td><td>Alice</td>
        </tr></tbody></table></body></html>'''
        rows, metadata = parse_index_page(html, "demo", 1, "time")
        self.assertEqual(len(rows), 1)
        self.assertNotIn("author", rows[0])
        self.assertEqual(rows[0]["gold_route"], "PRIORITY_REVIEW")
        self.assertEqual(rows[0]["tags_audit_only"], "finding-tag")
        self.assertEqual(metadata["repository_url"], "https://github.com/x/repo")

    def test_report_parser_excludes_judgement_outside_markdown_body(self):
        html = b'''<div>Invalid Reason: known issue</div>
        <div class="markdown"><h2>Summary</h2><p>Actual report body.</p>
        <h2>Impact</h2><p>Loss of funds.</p></div>'''
        text, links = parse_report_body(html)
        self.assertIn("Actual report body", text)
        self.assertNotIn("known issue", text)
        self.assertEqual(links, [])

    def test_report_parser_accepts_legacy_custom_headings(self):
        html = b'''<div class="markdown"><h2>Proof of Concept</h2>
        <p>Legacy report body.</p></div><div class="markdown"><p>short comment</p></div>'''
        text, _ = parse_report_body(html)
        self.assertIn("Legacy report body", text)

    def test_selection_does_not_use_outcome(self):
        rows = [
            {"contest_id": "a", "submission_id": i, "gold_route": "P" if i % 2 else "S"}
            for i in range(10)
        ]
        first = select_outcome_blind(rows, 4, "seed")
        changed = [{**row, "gold_route": "changed"} for row in rows]
        second = select_outcome_blind(changed, 4, "seed")
        self.assertEqual([r["submission_id"] for r in first], [r["submission_id"] for r in second])

    def test_selection_excludes_missing_adjudication(self):
        rows = [
            {"contest_id": "a", "submission_id": 1, "gold_route": None},
            {"contest_id": "a", "submission_id": 2, "gold_route": "STANDARD_REVIEW"},
        ]
        self.assertEqual([row["submission_id"] for row in select_outcome_blind(rows, 2, "seed")], [2])


if __name__ == "__main__":
    unittest.main()
