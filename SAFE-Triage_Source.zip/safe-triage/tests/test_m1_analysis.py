import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from run_strong_supervised import sigmoid
from analyse_m1 import decision_metrics


class StrongSupervisedTests(unittest.TestCase):
    def test_sigmoid_is_finite_and_monotone(self):
        values = sigmoid(np.asarray([-1000.0, 0.0, 1000.0]))
        self.assertTrue(np.isfinite(values).all())
        self.assertLess(values[0], values[1])
        self.assertLess(values[1], values[2])

    def test_cost_sensitivity_penalises_under_priority(self):
        rows = [
            {"gold_route": "PRIORITY_REVIEW", "prediction": "STANDARD_REVIEW"},
            {"gold_route": "STANDARD_REVIEW", "prediction": "PRIORITY_REVIEW"},
        ]
        result = decision_metrics(rows, "prediction")
        self.assertEqual(result["under_prioritised"], 1)
        self.assertGreater(result["cost_per_decision"]["under_20_over_1"], result["cost_per_decision"]["under_1_over_1"])


if __name__ == "__main__":
    unittest.main()
