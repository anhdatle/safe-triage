from pathlib import Path
import importlib.util
import unittest


SCRIPT = Path(__file__).parents[1] / "scripts" / "analyse_runs.py"
SPEC = importlib.util.spec_from_file_location("analyse_runs", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class AnalysisTests(unittest.TestCase):
    def test_zero_event_exact_requirements(self):
        self.assertEqual(MODULE.zero_event_projects_required(0.10), 29)
        self.assertEqual(MODULE.zero_event_projects_required(0.05), 59)
        self.assertGreater(MODULE.exact_upper(0, 28), 0.10)
        self.assertLessEqual(MODULE.exact_upper(0, 29), 0.10)

    def test_integrity_requires_cited_evidence_url(self):
        url = "https://github.com/org/repo/blob/" + "a" * 40 + "/A.sol#L1"
        case = {
            "report_text": f"Finding at {url}",
            "repository_slug": "org/repo",
            "evidence_url": url,
        }
        self.assertTrue(MODULE.integrity_pass(case))
        case["evidence_url"] = url.replace("A.sol", "B.sol")
        self.assertFalse(MODULE.integrity_pass(case))


if __name__ == "__main__":
    unittest.main()
