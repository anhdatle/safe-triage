from pathlib import Path
import importlib.util
import unittest


SCRIPT = Path(__file__).parents[1] / "scripts" / "sequential_monitor.py"
SPEC = importlib.util.spec_from_file_location("sequential_monitor", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class SequentialMonitorTests(unittest.TestCase):
    def test_zero_event_upper_decreases_with_more_projects(self):
        self.assertGreater(
            MODULE.upper_confidence_sequence(0, 10),
            MODULE.upper_confidence_sequence(0, 50),
        )

    def test_event_increases_upper_bound(self):
        self.assertGreater(
            MODULE.upper_confidence_sequence(1, 30),
            MODULE.upper_confidence_sequence(0, 30),
        )


if __name__ == "__main__":
    unittest.main()
