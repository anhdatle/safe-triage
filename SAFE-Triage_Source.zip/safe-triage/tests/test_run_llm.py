from pathlib import Path
import importlib.util
import unittest


SCRIPT = Path(__file__).parents[1] / "scripts" / "run_llm.py"
SPEC = importlib.util.spec_from_file_location("run_llm", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class RunSelectionTests(unittest.TestCase):
    def test_challenge_sampling_preserves_pairs(self):
        rows = []
        for base in ["a", "b"]:
            for condition in ["clean", "attack"]:
                rows.append({
                    "case_id": f"{base}::{condition}",
                    "base_case_id": base,
                    "condition": condition,
                    "platform": "P",
                    "split": "S",
                    "project_id": "project",
                    "evidence_available": 1,
                })
        selected = MODULE.choose(rows, {"P"}, {"S"}, True, 1)
        self.assertEqual(len(selected), 2)
        self.assertEqual(len({row["base_case_id"] for row in selected}), 1)
        self.assertEqual({row["condition"] for row in selected}, {"clean", "attack"})


if __name__ == "__main__":
    unittest.main()
